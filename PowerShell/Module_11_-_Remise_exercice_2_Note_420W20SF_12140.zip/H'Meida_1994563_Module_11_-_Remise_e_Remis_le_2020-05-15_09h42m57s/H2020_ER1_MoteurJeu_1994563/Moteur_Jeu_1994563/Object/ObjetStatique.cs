﻿using H2020_ER1_MoteurJeu_1994563.Geometrie;
using System;
using System.Collections.Generic;
using System.Text;

namespace H2020_ER1_MoteurJeu_1994563.Object
{
    public class ObjetStatique : ObjetJeu
    {
        public Point3D Position { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public Vecteur3D Direction { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}

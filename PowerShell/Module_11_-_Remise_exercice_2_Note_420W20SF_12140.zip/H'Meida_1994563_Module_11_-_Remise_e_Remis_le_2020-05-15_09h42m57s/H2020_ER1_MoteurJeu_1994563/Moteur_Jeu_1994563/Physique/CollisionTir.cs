﻿using System;
using System.Collections.Generic;
using System.Text;

namespace H2020_ER1_MoteurJeu_1994563.Physique
{
    public class CollisionTir:Collision
    {
        public double Degat { get; set; }
    }
}

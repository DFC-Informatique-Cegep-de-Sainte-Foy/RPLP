﻿using H2020_ER1_MoteurJeu_1994563.Sons;
using System;
using System.Collections.Generic;
using System.Text;

namespace H2020_ER1_MoteurJeu_1994563.Armes
{
   public class Stylo:Arme
    {
        public Stylo() : base(new Son("Tuctuctuctuc"), new Son("Crounch") )
        {
            ;
        }

        protected override double CalculerDegat()
        {
            return 1.0;
        }
    }
}

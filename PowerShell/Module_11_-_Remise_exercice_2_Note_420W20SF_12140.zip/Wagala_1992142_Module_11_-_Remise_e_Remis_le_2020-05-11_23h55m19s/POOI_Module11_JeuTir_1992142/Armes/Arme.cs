﻿using System;
using System.Collections.Generic;
using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Objet;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;
using POOI_Module11_JeuTir.Joueurs;

namespace POOI_Module11_JeuTir.Armes
{
    public class Arme
    {
        public int Temperature { get; private set; }
        public Son SonTir { get; private set; }
        public Son SonTropChaud { get; private set; }

        public Arme(Son p_sonTir, Son p_sonTropChaud)
        {
            if (p_sonTir.TexteDuSon == "" || p_sonTropChaud.TexteDuSon == "")
            {
                throw new ArgumentException("L'arme doit obligatoirement avoir un son");
            }

            if (p_sonTir.TexteDuSon == null|| p_sonTropChaud.TexteDuSon == null)
            {
                throw new ArgumentNullException("Le son de l'arme ne doit pas être nul");
            }
            this.SonTir = p_sonTir;
            this.SonTropChaud = p_sonTropChaud;
            this.Temperature = 20;
        }


        public virtual CollisionTir Tirer(Point3D p_positionArme, Vecteur3D p_direction, List<Joueur> p_joueurs)
        {
            if (p_positionArme == null || p_direction == null || p_joueurs == null)
            {
                throw new ArgumentNullException("L'arme doit obligatoirement pointer dans une directtion et avoir une position");
            }
            CollisionTir collisionTir = new CollisionTir();
            collisionTir.ObjetTouche = this.ObtenirCollision(p_positionArme, p_direction, p_joueurs);
            collisionTir.Degat = this.CalculerDegat();

            return collisionTir;
        }

        protected virtual double CalculerDegat()
        {
            throw new NotImplementedException();
        }

        private ObjetJeu ObtenirCollision(Point3D p_positionArme, Vecteur3D p_direction, List<Joueur> p_joueurs  )
        {
            ObjetJeu resultat = null;

            if (p_positionArme == null || p_direction == null || p_joueurs == null)
            {
                throw new ArgumentNullException("Il faut obligatoirement une position et une direction");
            }

            // trouvons l'équation de la direction du tire
            double coefficientDirecteur = (p_direction.Y - p_positionArme.Y) / (p_direction.X - p_positionArme.X);
            double ordonneAOrigine = (p_positionArme.Y - (coefficientDirecteur * p_positionArme.X));

            // Determine s'il ya un objet qui a été touché
            for (int i = 0; i < p_joueurs.Count; i++)
            {
                if ((ordonneAOrigine + (coefficientDirecteur * p_joueurs[i].Position.X)) == p_joueurs[i].Position.Y)
                {
                    resultat = p_joueurs[i];
                }
            }

            return resultat;
        }
    }
}
﻿using System;

namespace POOI_Module11_JeuTir.Sons
{
    public class MoteurSon
    {
        public void LireSon(Son p_son)
        {
            Console.Out.WriteLine(p_son.TexteDuSon);
        }
    }
}
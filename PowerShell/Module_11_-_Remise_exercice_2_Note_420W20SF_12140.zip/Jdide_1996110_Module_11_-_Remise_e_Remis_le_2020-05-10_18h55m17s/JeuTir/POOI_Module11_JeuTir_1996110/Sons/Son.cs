﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir.Sons
{
   public  class Son
    {
        public string TexteDuSon { get; set; }

       
    }
}

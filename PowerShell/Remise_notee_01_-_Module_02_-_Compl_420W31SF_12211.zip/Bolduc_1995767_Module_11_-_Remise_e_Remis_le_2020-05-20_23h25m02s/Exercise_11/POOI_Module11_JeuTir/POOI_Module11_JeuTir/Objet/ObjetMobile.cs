﻿using POOI_Module11_JeuTir.Objet;

namespace POOI_Module11_JeuTir.Joueurs
{
    public class ObjetMobile : ObjetJeu
    {
    }
}
﻿using System;

namespace POOI_Module11_JeuTir.Sons
{
    public class MoteurSon
    {
        public void LireSon(Son p_son)
        {
            if (p_son == null)
            {
                throw new ArgumentException("Le paramêtre ne peu être null", nameof(p_son));
            }
            Console.Out.WriteLine(p_son.TexteDuSon);
        }
    }
}

﻿using POOI_Module11_JeuTir.Objet;
using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir.Physique
{
    public class Collision
    {
        public ObjetJeu ObjetTouche { get; set; }
    }
}

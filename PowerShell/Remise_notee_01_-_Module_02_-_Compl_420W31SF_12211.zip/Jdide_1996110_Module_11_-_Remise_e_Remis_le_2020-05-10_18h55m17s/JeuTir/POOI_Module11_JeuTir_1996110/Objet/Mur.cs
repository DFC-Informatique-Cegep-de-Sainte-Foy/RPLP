﻿using POOI_Module11_JeuTir.Objet;
using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTi.Objet
{
    public class Mur : ObjetStatique
    {

    }
}

﻿namespace POOI_Module11_JeuTir.Geometrie
{
    public class Vecteur3D 
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Z { get; set; }
    }
}

﻿using System;

using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Objet;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;

namespace POOI_Module11_JeuTir.Armes
{
    public abstract class Arme
    {
        public int Temperature { get; private set; }
        public MoteurSon SonTir { get; private set; }
        public MoteurSon SonTropChaud { get; private set; }

        public Arme(MoteurSon p_sonTir, MoteurSon p_sonTropChaud)
        {
            if (String.IsNullOrWhiteSpace(p_sonTir.TexteDuSon))
            {
                throw new ArgumentNullException("Le son du tir ne peut pas être null", nameof(p_sonTir.TexteDuSon));
            }
            if (String.IsNullOrWhiteSpace(p_sonTropChaud.TexteDuSon))
            {
                throw new ArgumentNullException("Le son du tir trop chaud ne peut pas être null", nameof(p_sonTropChaud.TexteDuSon));
            }
            this.SonTir = p_sonTir;
            this.SonTropChaud = p_sonTropChaud;
            this.Temperature = 20;
        }

        public virtual CollisionTir TirerArme(Point3D p_positionArme, Vecteur3D p_direction)
        {
            throw new NotImplementedException();
        }  
        protected virtual ObjetJeu ObtenirCollision(Point3D p_positionArme, Vecteur3D p_direction)
        {
            throw new NotImplementedException();
        }
        protected virtual double CalculerDegat()
        {
            throw new NotImplementedException();
        }
    }
}

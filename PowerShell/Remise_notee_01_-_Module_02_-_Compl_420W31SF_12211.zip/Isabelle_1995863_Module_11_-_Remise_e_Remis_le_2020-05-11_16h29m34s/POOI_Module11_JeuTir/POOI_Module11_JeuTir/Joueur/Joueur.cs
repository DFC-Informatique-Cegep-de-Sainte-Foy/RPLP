﻿using System;
using System.Collections.Generic;

using POOI_Module11_JeuTir.Armes;
using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;

namespace POOI_Module11_JeuTir.Joueur
{
    public class Joueur : ObjetMobile
    {
        private List<Arme> m_listeArmes;
        public List<Arme> ListeArmes
        {
            get
            {
                return new List<Arme>(this.m_listeArmes);
            }
        }

        private Arme m_armeSelectionnee;
        public MoteurSon MoteurSon { get; private set; }

        public Joueur()
        {
            this.m_listeArmes = new List<Arme> { new Stylo() };
            this.m_armeSelectionnee = this.ListeArmes[0];
            this.Position = new Point3D() { X = 0, Y = 0, Z = 0 };
            this.Direction = new Vecteur3D() { X = 1, Y = 0, Z = 0 };
            this.MoteurSon = new MoteurSon();
        }

        public void RamasserArme(Arme p_arme)
        {            
            if (p_arme == null)
            {
                throw new ArgumentException("L'arme ne peut pas être null");
            }
            
            this.m_listeArmes.Add(p_arme);
        }
        public void TirerJoueur()
        {
            if (this.m_armeSelectionnee.Temperature < 250)
            {
                CollisionTir collisionTir = this.m_armeSelectionnee.TirerArme(this.Position, this.Direction);

                if (collisionTir != null)
                {
                    collisionTir.ObjetTouche.AppliquerDomage(collisionTir.Degat);
                }

                this.MoteurSon.LireSon(this.m_armeSelectionnee.SonTir);
            }

            else
            {
                this.MoteurSon.LireSon(this.m_armeSelectionnee.SonTropChaud);
            }
        }

        public void SelectionnerArme(int p_numeroArme)
        {
            if (p_numeroArme < 0)
            {
                throw new ArgumentException("Le numéro de l'arme ne peut pas être négatif");
            }

            if (p_numeroArme > this.ListeArmes.Count)
            {
                throw new ArgumentOutOfRangeException("Le numéro de l'arme ne peut pas dépasser la capacité de la liste");
            }

            this.m_armeSelectionnee = this.m_listeArmes[p_numeroArme];
        }
    }
}

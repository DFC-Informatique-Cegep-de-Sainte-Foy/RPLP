﻿namespace POOI_Module11_JeuTir.Sons
{
    public interface ISon
    {
        public void LireSon(MoteurSon p_son) 
        {
            ;
        }  
    }
}

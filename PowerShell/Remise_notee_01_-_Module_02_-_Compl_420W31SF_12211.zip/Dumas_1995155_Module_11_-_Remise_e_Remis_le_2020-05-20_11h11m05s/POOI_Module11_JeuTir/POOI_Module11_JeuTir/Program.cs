﻿using System;

namespace POOI_Module11_JeuTir
{
    class Program
    {
        static void Main(string[] args)
        {
            JouerJeuTir();
        }

        public static void JouerJeuTir()
        {
            Joueur.Joueur player1 = new Joueur.Joueur();

        }
    }    
}

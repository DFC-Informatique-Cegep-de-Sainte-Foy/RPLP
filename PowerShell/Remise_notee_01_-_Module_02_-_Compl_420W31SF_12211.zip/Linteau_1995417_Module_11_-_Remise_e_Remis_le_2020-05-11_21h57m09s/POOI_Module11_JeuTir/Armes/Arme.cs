﻿using System;

using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Objet;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;

namespace POOI_Module11_JeuTir.Armes
{
    public abstract class Arme
    {
        public int Temperature { get; private set; }
        public MoteurSon SonTir { get; private set; }
        public MoteurSon SonTropChaud { get; private set; }

        public Arme(MoteurSon p_sonTir, MoteurSon p_sonTropChaud)
        {
            if (String.IsNullOrWhiteSpace(p_sonTir.TexteDuSon))
            {
                throw new ArgumentNullException("Le son peut être nul ou remplis d'espace", nameof(p_sonTir.TexteDuSon));
            }
            else
            {
                this.SonTir = p_sonTir;
            }

            if (String.IsNullOrWhiteSpace(p_sonTropChaud.TexteDuSon))
            {
                throw new ArgumentNullException("Le son peut être nul ou remplis d'espace", nameof(p_sonTropChaud.TexteDuSon));
            }
            else
            {
                this.SonTropChaud = p_sonTropChaud;
            }
            
            this.Temperature = 20;
        }

        public virtual CollisionTir Tirer(Point3D p_positionArme, Vecteur3D p_direction)
        {
            throw new NotImplementedException();
        }

        protected virtual double CalculerDegat()
        {
            throw new NotImplementedException();
        }

        protected virtual ObjetJeu ObtenirCollision(Point3D p_positionArme, Vecteur3D p_direction)
        {
            throw new NotImplementedException();
        }
    }
}

﻿using POOI_Module11_JeuTir.Armes;
using System;

namespace POOI_Module11_JeuTir
{
    class Program
    {
        static void Main(string[] args)
        {
            Joueur.Joueur Steve = new Joueur.Joueur();
            Steve.RamasserArme(new PulverisateurCarottes());
            Steve.SelectionnerArme(1);
            Steve.Tirer();
            Steve.SelectionnerArme(0);
            Steve.Tirer();
            Steve.RamasserArme(new BalaiToilette());
            Steve.SelectionnerArme(2);
            Steve.Tirer();
        }
    }    
}

﻿using System;

namespace POOI_Module11_JeuTir.Sons
{
    public class MoteurSon
    {
        public string TexteDuSon { get; set; }
        
        //public void LireSon(Son p_son)
        public void LireSon(MoteurSon p_son)
        {
            Console.Out.WriteLine(p_son.TexteDuSon);
        }
    }
}

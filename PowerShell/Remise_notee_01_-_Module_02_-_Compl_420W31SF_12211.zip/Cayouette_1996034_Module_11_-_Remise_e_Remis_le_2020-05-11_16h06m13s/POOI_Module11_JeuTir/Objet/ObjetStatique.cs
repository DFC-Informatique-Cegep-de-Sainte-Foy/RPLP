﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir.Objet
{
    public class ObjetStatique : ObjetJeu
    {        
    }
}
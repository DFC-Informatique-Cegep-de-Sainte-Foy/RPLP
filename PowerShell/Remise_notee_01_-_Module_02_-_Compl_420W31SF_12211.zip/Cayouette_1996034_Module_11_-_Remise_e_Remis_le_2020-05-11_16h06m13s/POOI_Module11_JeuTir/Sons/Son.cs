﻿namespace POOI_Module11_JeuTir.Sons
{
    public class Son
    {
        public string TexteDuSon { get; set; }
    }
}
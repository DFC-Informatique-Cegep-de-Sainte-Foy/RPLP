﻿using POOI_Module11_JeuTir.Armes;
using POOI_Module11_JeuTir.Joueur;
using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir
{
    public class ExempleJoueur
    {
        public static void SousProgrammeJoueur()
        {
            int choixMenu = 0;
            List<Arme> uneListeArme = new List<Arme>();
            Joueur unJoueur = new Joueur(uneListeArme); //Je comprends pas, l'appel de classe devrait fonctionner...
            Arme balai = new BalaiToilette();
            Arme carotte = new PulverisateurCarottes();
            Arme stylo = new Stylo();
            


            while (choixMenu != 4)
            {
                AfficherMenu();
                choixMenu = ChoixMenu();

                switch (choixMenu)
                {
                    case 1:
                        unJoueur.RamasserArme(balai);
                        unJoueur.RamasserArme(carotte);
                        unJoueur.RamasserArme(stylo);
                        break;
                    case 2:
                        unJoueur.SelectionnerArme(1);
                        break;
                    case 3:
                        unJoueur.Tirer();
                        break;
                }
            }
        }

        public static void AfficherMenu()
        {
            Console.Out.WriteLine("1- Joueur voici les armes");
            Console.Out.WriteLine("2- Veuillez slectionner une arme svp.");
            Console.Out.WriteLine("3- Tirer");
            Console.Out.WriteLine("4- Quitter le jeu");
        }

        public static int ChoixMenu()
        {
            int choixMenu = 0;

            do
            {
                Console.Out.WriteLine("Quel est votre choix :");
                choixMenu = Console.In.ReadInt();
            } while (choixMenu < 1 || choixMenu > 5);

            return choixMenu;
        }
    }
}

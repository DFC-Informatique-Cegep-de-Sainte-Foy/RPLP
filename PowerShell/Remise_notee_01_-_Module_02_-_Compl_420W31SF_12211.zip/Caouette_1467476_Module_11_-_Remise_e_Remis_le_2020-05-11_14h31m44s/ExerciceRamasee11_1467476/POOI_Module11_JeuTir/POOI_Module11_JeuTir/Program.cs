﻿using System;

namespace POOI_Module11_JeuTir
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }    
}

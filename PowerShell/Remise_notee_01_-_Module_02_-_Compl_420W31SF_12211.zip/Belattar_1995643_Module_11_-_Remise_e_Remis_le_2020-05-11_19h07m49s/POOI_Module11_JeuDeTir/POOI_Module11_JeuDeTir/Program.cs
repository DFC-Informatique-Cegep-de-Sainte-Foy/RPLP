﻿using System;

namespace POOI_Module11_JeuTir
{
    public class Program
    {
        static void Main(string[] args)
        {
            GestionJoueur.GererMenu();
        }
    }
}

﻿namespace POOI_Module11_JeuTir.Geometrie
{
    public class Vecteur3D
    {
        public double X { get; private set; }
        public double Y { get; private set; }
        public double Z { get; private set; }

        public Vecteur3D(double p_X, double p_Y, double p_Z)
        {
            this.X = p_X;
            this.Y = p_Y;
            this.Z = p_Z;
        }
    }
}

﻿using POOI_Module11_JeuTir.Objet;

namespace POOI_Module11_JeuTir.Physique
{
    public class Collision
    {
        public ObjetJeu ObjetTouche { get; private set; }
        public void DefinirObjetTouche(ObjetJeu p_objetTouche)
        {
            this.ObjetTouche = p_objetTouche;
        }

    }
}

﻿using POOI_Module11_JeuTir.Armes;
using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Joueurs;
using POOI_Module11_JeuTir.Sons;
using System;
using System.Collections.Generic;

namespace POOI_Module11_JeuTir
{
    public class GestionJoueur
    {

        public static void GererMenu()
        {
            Joueur joueur = null;
            AfficherMenuPrincipal();
            int choixMenuUtilisateur = SaisirOptionMenuUtilisateur();

            while (choixMenuUtilisateur != 4)  //Quitter
            {
                switch (choixMenuUtilisateur)
                {
                    case 1:     //Création Joueur
                        joueur = CreationNouveauJoueur();
                        break;
                    case 2:     // Selectionner Arme
                        if (joueur != null)
                        {
                            int numeroArme = SaisirNumeroArme(joueur);

                            SelectionnerArmeJoueur(joueur, numeroArme);
                        }
                        else
                        {
                            Console.Out.WriteLine("Il n'y a pas de joueur existant !");
                        }
                        break;
                    case 3:     // Tirer
                        if (joueur != null)
                        {
                            EffectuerTir(joueur);
                        }
                        else
                        {
                            Console.Out.WriteLine("Il n'y a pas de joueur existant !");
                        }
                        break;


                    default:

                        break;

                }
                AfficherMenuPrincipal();
                choixMenuUtilisateur = SaisirOptionMenuUtilisateur();

            }


        }

        public static Joueur CreationNouveauJoueur()
        {
            Joueur joueur = new Joueur(
                new List<Arme>()
                {
                    new Stylo(70,new Son("Son Tir Stylo"),new Son("Son Tir Trop Chaud Stylo")),
                    new BalaiToilette(95,new Son("Son Tir BalaiToilette"),new Son("Son Tir BalaiToilette")),
                    new PulverisateurCarottes(50,new Son("Son Tir PulverisateurCarottes"),new Son("Son Tir PulverisateurCarottes"))
                },
                new Point3D(0, 0, 0),
                new Vecteur3D(1, 0, 0)
                );

            return joueur;
        }

        public static void SelectionnerArmeJoueur(Joueur p_joueur, int p_numeroArme)
        {
            if (p_joueur == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_joueur));
            }
            if (p_numeroArme < 0 || p_numeroArme >= p_joueur.Armes.Count)
            {
                throw new ArgumentException("Le numéro d'arme doit être présent dans les indices existants de la liste d'armes", nameof(p_numeroArme));
            }
            p_joueur.SelectionnerArme(p_numeroArme);

        }

        public static void EffectuerTir(Joueur p_joueur)
        {
            if (p_joueur == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_joueur));
            }
            p_joueur.Tirer();
        }

        public static int SaisirNumeroArme(Joueur p_joueur)
        {
            int numeroArme = 0;
            do
            {
                Console.Out.Write("Entre le numero de l'arme");
                numeroArme = Console.In.ReadInt();
            } while (numeroArme >= p_joueur.Armes.Count || numeroArme < 0);

            return numeroArme;
        }

        public static void AfficherMenuPrincipal()
        {
            Console.Out.WriteLine("----------------------------------------------");
            Console.Out.WriteLine("1. Création d'un Joueur");
            Console.Out.WriteLine("2. Selectionner une Arme Joueur");
            Console.Out.WriteLine("3. Effectuer un Tir");
            Console.Out.WriteLine("4. Quitter");
            Console.Out.WriteLine("----------------------------------------------");
        }
        public static int SaisirOptionMenuUtilisateur()
        {
            int choixUtilisateur = 0;

            do
            {
                Console.Out.Write("Entrez votre choix menu :");
                choixUtilisateur = Console.In.ReadInt();

            } while (choixUtilisateur > 4 || choixUtilisateur < 1);

            return choixUtilisateur;
        }
    }
}

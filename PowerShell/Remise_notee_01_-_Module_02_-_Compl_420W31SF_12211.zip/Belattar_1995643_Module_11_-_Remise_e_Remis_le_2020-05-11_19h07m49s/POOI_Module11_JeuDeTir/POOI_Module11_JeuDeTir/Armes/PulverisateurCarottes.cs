﻿using POOI_Module11_JeuTir.Sons;
using System;

namespace POOI_Module11_JeuTir.Armes
{
    public class PulverisateurCarottes : Arme
    {
        public PulverisateurCarottes(int p_temperature, Son p_sonTir, Son p_sonTropChaud) : base(p_temperature, p_sonTir, p_sonTropChaud)
        {
            ;
        }
        protected override double CalculerDegat()
        {
            return (new Random(DateTime.Now.Millisecond)).NextDouble() * 100;
        }
    }
}

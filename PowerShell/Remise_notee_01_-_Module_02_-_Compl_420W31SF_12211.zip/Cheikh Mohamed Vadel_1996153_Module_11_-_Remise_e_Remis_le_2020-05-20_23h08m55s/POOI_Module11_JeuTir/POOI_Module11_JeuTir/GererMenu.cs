﻿using System;
using System.Collections.Generic;
using System.Text;
using POOI_Module11_JeuTir.Joueur;
using POOI_Module11_JeuTir.Armes;
using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;

namespace POOI_Module11_JeuTir
{
    public class GererMenu
    {




        public static void AfficherChoixMenuUtilisateur()
        {
            Console.Out.WriteLine("Veuillez choisir l'une des options suivantes: ");

            Console.WriteLine("1.Selectionner Arme:");
            Console.WriteLine("2.Tirer:");
        }

        public static void GererMenu()
        {
            int reponseUtilisateur = 0;
            Joueur joueur = new Joueur();
            do
            {
                AfficherChoixMenuUtilisateur();
                reponseUtilisateur = ValiderChoixMenuUtilisateur();

                switch (reponseUtilisateur)

                {
                    case 1:
                        RamasserArme(joueur);
                        break;
                    case 2:
                        Tirer(joueur);
                        break;



                    default:
                        Console.WriteLine("Veuillez entrer un chiffre entre 0 et 4: ");
                        break;

                }

            } while (reponseUtilisateur != 0);
        }
        public static int ValiderChoixMenuUtilisateur()
        {
            int choixUtilisateur = 0;

            do
            {
                choixUtilisateur = Console.In.ReadInt();

            } while (choixUtilisateur < 0 || choixUtilisateur > 2);



            return choixUtilisateur;
        }


        public void RamasserArme(Joueur p_joueur)
        {
            if (p_joueur == null)
            {
                throw new ArgumentException("Le parametre ne doit pas être nul", nameof(p_joueur));
            }

            p_joueur.RamasserArme(new BalaiToilette());


        }



        public void Tirer(Joueur p_joueur)
        {
            if (p_joueur == null)
            {
                throw new ArgumentException("Le parametre ne doit pas être nul", nameof(p_joueur));
            }
            p_joueur.Tirer();
        }
    }
}

﻿using System;

namespace POOI_Module11_JeuTir.Sons
{
    public class Son
    {
        public string TexteDuSon { get; set; }

        public  Son(string p_texteDuson)
        {
            if (string.IsNullOrWhiteSpace(p_texteDuson))
            {
                { throw new ArgumentException("le texte pour le son ne peut pas etre null ou vide...", "p_texteDuson"); }
            }
            
            this.TexteDuSon = p_texteDuson;
        }






    }

}

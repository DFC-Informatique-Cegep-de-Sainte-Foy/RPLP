﻿using System;
using System.Collections.Generic;
using System.Text;
using POOI_Module11_JeuTir.Armes;
using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Joueur;
using POOI_Module11_JeuTir.Objet;
using POOI_Module11_JeuTir.Physique;

namespace POOI_Module11_JeuTir
{
    public class InterfaceUtilisateur
    {
        public static int SaisirChoixMenu()
        {
            int choix = 0;

            do
            {
                Console.WriteLine("Veuillez entrer votre choix ici : ");
                choix = Console.In.ReadInt();
            }
            while (choix < 0 || choix > 5);

            return choix;
        }
        public static int SaisirChoixArme(Joueur.Joueur p_joueur)
        {
            int choix = 0;

            Console.Out.WriteLine("Quelle arme voulez vous equiper?.");

            AfficherListeDarme(p_joueur);

            do
            {
                Console.WriteLine("Veuillez entrer votre choix ici : ");
                choix = Console.In.ReadInt();
            }
            while (choix < 0 || choix > (p_joueur.Armes.Count -1));

            return choix;
        }
        public static void AfficherListeDarme(Joueur.Joueur p_joueur)
        {
           for(int i = 0; i < p_joueur.Armes.Count; i++)
           {
                Console.Out.WriteLine(i + "." + p_joueur.Armes[i].GetType().Name);
           }
        }


        public static void Menu()
        {
            Console.Out.WriteLine("1.Cree un nouveau joueur.");
            Console.Out.WriteLine("2.Ramasser tous les armes.");
            Console.Out.WriteLine("3.Selectionner arme a equiper.");
            Console.Out.WriteLine("4.Faite un tir dessaie sur un mur.");
            Console.Out.WriteLine("0.Quitter. \n\r");
        }
        public static void ProgramJoueur()
        {
            Console.Out.WriteLine("Interface Joueur \n\r");

            int choixUtilisateur = 0;

            int choixDarme = 0;

            Joueur.Joueur nouveauJoueur = null;

            do
            {
                InterfaceUtilisateur.Menu();

                choixUtilisateur = InterfaceUtilisateur.SaisirChoixMenu();


                switch (choixUtilisateur)
                {
                    case 1:
                                                                                                                       
                        nouveauJoueur = new Joueur.Joueur();
                                               
                        break;

                    case 2:

                        if (nouveauJoueur == null)
                        {
                            Console.Out.WriteLine("VOus devez creer un joueur avant de pouvoir ramasser des armes....");
                        }
                        else {
                            nouveauJoueur.RamasserArme(new BalaiToilette());
                            nouveauJoueur.RamasserArme(new PulverisateurCarottes());
                        }
                       
                       
                        break;

                    case 3:

                        if(nouveauJoueur == null)
                        {
                            Console.Out.WriteLine("VOus devez creer un joueur avant de pouvoir choisir son arme a equiper....");
                        }
                        else
                        {
                            choixDarme = SaisirChoixArme(nouveauJoueur);

                            nouveauJoueur.SelectionnerArme(choixDarme);
                        }
                       
                        

                      break;

                    case 4:

                        if (nouveauJoueur == null)
                        {
                            Console.Out.WriteLine("Vous devez creer un joueur avant de pouvoir tirer avec une arme....");
                        }
                        else
                        {
                            nouveauJoueur.Tirer();
                        }

                       


                        break;


                }


            } while (choixUtilisateur != 0);
        }


    }




}


﻿using POOI_Module11_JeuTir.Sons;
using System;

namespace POOI_Module11_JeuTir.Armes
{
    public class PulverisateurCarottes : Arme
    {
        public PulverisateurCarottes()  // Jai fait des constructeur difference a chaque class fille car le son est different pour chaque arme
        {
            Son sonTir = new Son("BOOM!");
            Son sonTropchaud = new Son("CLICK!");

            base.SonTir = sonTir;
            base.SonTropChaud = sonTropchaud;
        }
        protected override double CalculerDegat()
        {
            return (new Random(DateTime.Now.Millisecond)).NextDouble() * 100;
        }
    }
}

﻿using POOI_Module11_JeuTir.Sons;
using System;

namespace POOI_Module11_JeuTir.Armes
{
    public class BalaiToilette : Arme
    {
        public BalaiToilette()                 // Jai fait des constructeur difference a chaque class fille car le son est different pour chaque arme
        {
            Son sonTir = new Son("FLAP!");
            Son sonTropchaud = new Son("BUP!");

            base.SonTir = sonTir;
            base.SonTropChaud = sonTropchaud;
        }


        protected override double CalculerDegat()
        {
            return (new Random(DateTime.Now.Millisecond)).NextDouble() * 40 + 10;
        }
    }
}

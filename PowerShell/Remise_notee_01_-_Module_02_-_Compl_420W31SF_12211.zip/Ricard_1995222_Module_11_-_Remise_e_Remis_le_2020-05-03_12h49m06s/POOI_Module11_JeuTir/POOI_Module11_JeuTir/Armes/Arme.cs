﻿using System;

using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Objet;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;

namespace POOI_Module11_JeuTir.Armes
{
    public abstract class Arme
    {
        public int Temperature { get; private set; }
        public Son SonTir { get; protected set; }
        public Son SonTropChaud { get; protected set; }



        public virtual CollisionTir Tirer(Point3D p_positionArme, Vecteur3D p_direction)
        {
            if (p_positionArme == null)
            {
                { throw new ArgumentException("La position de l'arme ne peux pas etre null ", "p_positionArme"); }
            }
            if (p_direction == null)
            {
                { throw new ArgumentException("La direction de l'arme ne peux pas etre null ", "p_direction"); }
            }

            CollisionTir collisionTir = new CollisionTir();
            collisionTir.ObjetTouche = this.ObtenirCollision(p_positionArme, p_direction);
            collisionTir.Degat = this.CalculerDegat();

            return collisionTir;
        }

        protected abstract double CalculerDegat();     //abstract
      

        private ObjetJeu ObtenirCollision(Point3D p_positionArme, Vecteur3D p_direction)
        {
            if (p_positionArme == null)
            {
                { throw new ArgumentException("La position de l'arme ne peux pas etre null ", "p_positionArme");}
            }
            if (p_direction == null)
            {
                { throw new ArgumentException("La direction de l'arme ne peux pas etre null ", "p_direction");}
            }

           

            return new Mur(); // Normalement un calcul ici
        }
    }
}

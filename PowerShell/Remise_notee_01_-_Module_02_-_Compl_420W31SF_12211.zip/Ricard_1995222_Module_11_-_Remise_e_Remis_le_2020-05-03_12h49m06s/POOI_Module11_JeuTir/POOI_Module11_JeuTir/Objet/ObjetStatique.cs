﻿using POOI_Module11_JeuTir.Geometrie;
using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir.Objet
{
    public abstract class ObjetStatique : ObjetJeu
    {
        public Point3D Position { get; set; }
        public Vecteur3D Direction { get; set; }

       

        public abstract void AppliquerDomage(double p_degat);
    }


}

﻿using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Objet;

namespace POOI_Module11_JeuTir.Joueur
{
    public abstract class ObjetMobile : ObjetJeu
    {
        public Point3D Position { get; set; }
        public Vecteur3D Direction { get; set; }

        public abstract void AppliquerDomage(double p_degat);
    }
}
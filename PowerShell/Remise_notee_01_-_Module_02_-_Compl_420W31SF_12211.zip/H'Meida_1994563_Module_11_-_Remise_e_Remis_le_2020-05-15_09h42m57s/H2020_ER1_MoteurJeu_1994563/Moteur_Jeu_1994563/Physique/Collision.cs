﻿using H2020_ER1_MoteurJeu_1994563.Object;
using System;
using System.Collections.Generic;
using System.Text;

namespace H2020_ER1_MoteurJeu_1994563.Physique
{
   public class Collision
    {
        public ObjetJeu ObjetTouche { get; set; }
    }
}

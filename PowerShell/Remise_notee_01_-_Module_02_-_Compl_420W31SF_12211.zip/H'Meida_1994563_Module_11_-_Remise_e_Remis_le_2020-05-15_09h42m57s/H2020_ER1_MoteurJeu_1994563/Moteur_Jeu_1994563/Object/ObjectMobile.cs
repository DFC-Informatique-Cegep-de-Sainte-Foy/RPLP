﻿using H2020_ER1_MoteurJeu_1994563.Armes;
using H2020_ER1_MoteurJeu_1994563.Geometrie;
using H2020_ER1_MoteurJeu_1994563.Object;
using H2020_ER1_MoteurJeu_1994563.Physique;
using H2020_ER1_MoteurJeu_1994563.Sons;
using System;
using System.Collections.Generic;
using System.Text;

namespace H2020_ER1_MoteurJeu_1994563
{
    public class ObjectMobile : ObjetJeu
    {
        Point3D ObjetJeu.Position { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        Vecteur3D ObjetJeu.Direction { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
    }
}

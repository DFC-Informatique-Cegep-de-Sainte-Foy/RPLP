﻿using H2020_ER1_MoteurJeu_1994563.Geometrie;
using System;
using System.Collections.Generic;
using System.Text;

namespace H2020_ER1_MoteurJeu_1994563.Object
{
   public interface ObjetJeu
    {
        // ...
        public Point3D Position { get; set; }
        public Vecteur3D Direction { get; set; }

        public virtual void AppliquerDomage(double p_degat)
        {

        }

    }
}


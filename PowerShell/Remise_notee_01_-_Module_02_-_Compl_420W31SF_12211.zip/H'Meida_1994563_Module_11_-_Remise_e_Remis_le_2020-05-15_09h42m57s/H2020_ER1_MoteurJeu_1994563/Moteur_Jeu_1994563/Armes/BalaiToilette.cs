﻿using H2020_ER1_MoteurJeu_1994563.Sons;
using System;
using System.Collections.Generic;
using System.Text;

namespace H2020_ER1_MoteurJeu_1994563.Armes
{
    public class BalaiToilette : Arme
    {


       public BalaiToilette():base( new Son("tuctuc"),new Son("Booom"))
        {

        }
        protected override double CalculerDegat()
        {
            return (new Random(DateTime.Now.Millisecond)).NextDouble() * 40 + 10;

        }
    }
}

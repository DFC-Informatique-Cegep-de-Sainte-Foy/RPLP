﻿using POOI_Module11_JeuTir.Objet;

namespace POOI_Module11_JeuTir.Joueur
{
    public class ObjetMobile : ObjetJeu
    {
    }
}
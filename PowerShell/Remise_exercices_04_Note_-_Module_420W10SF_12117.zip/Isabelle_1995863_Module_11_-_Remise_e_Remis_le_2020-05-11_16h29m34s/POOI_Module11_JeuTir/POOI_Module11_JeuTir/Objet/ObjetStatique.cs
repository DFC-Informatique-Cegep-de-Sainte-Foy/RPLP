﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir.Objet
{
    public class ObjetStatique : ObjetJeu
    {
        public override void AppliquerDomage(double p_degat)
        {
            if (p_degat < 0)
            {
                throw new ArgumentException("Les dégats ne peuvent pas être négatif");
            }
            throw new NotImplementedException();
        }
    }
}

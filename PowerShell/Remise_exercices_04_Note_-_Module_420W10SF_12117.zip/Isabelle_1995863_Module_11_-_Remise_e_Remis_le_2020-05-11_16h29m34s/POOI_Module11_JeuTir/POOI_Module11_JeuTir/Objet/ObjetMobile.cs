﻿using POOI_Module11_JeuTir.Objet;
using System;

namespace POOI_Module11_JeuTir.Joueur
{
    public class ObjetMobile : ObjetJeu
    {
        public override void AppliquerDomage(double p_degat)
        {
            if (p_degat < 0)
            {
                throw new ArgumentException("Les dégats ne peuvent pas être négatif");
            }
            throw new NotImplementedException();
        }
    }
}
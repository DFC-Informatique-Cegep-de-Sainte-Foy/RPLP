﻿using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Objet;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;
using System;

namespace POOI_Module11_JeuTir.Armes
{
    public class BalaiToilette : Arme
    {
        public BalaiToilette() : base(new MoteurSon() { TexteDuSon = "BloupBloup" }, new MoteurSon() { TexteDuSon = "Gloupeufpeufpeuf" })
        {
            ;
        }
        public override CollisionTir TirerArme(Point3D p_positionArme, Vecteur3D p_direction)
        {
            if (p_positionArme == null)
            {
                throw new ArgumentException("La position de l'arme ne peut pas être null");
            }
            if (p_direction == null)
            {
                throw new ArgumentException("La direction ne peut pas être null");
            }

            CollisionTir collisionTir = new CollisionTir
            {
                ObjetTouche = ObtenirCollision(p_positionArme, p_direction),
                Degat = CalculerDegat()
            };

            return collisionTir;
        }
        protected override ObjetJeu ObtenirCollision(Point3D p_positionArme, Vecteur3D p_direction)
        {
            if (p_positionArme == null)
            {
                throw new ArgumentException("La position de l'arme ne peut pas être null");
            }
            if (p_direction == null)
            {
                throw new ArgumentException("La direction ne peut pas être null");
            }

            return new Mur(); // Normalement un calcul ici
        }
        protected override double CalculerDegat()
        {
            return (new Random(DateTime.Now.Millisecond)).NextDouble() * 40 + 10;
        }
    }
}

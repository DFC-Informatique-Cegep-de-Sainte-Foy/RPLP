﻿using System;

namespace POOI_Module11_JeuTir.Sons
{
    public class MoteurSon : ISon
    {
        public string TexteDuSon { get; set; }

        public void LireSon(MoteurSon p_son)
        {
            if (String.IsNullOrWhiteSpace(p_son.TexteDuSon))
            {
                throw new ArgumentNullException("Le texte du son ne peut pas être null ou rempli d'espace vide", nameof(p_son.TexteDuSon));
            }
            Console.Out.WriteLine(p_son.TexteDuSon);
        }
    }
}

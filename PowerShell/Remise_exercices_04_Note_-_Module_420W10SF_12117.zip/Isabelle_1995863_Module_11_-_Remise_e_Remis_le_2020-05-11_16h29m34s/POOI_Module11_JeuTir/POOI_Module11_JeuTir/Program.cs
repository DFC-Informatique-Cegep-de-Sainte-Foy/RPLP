﻿using POOI_Module11_JeuTir.Armes;
using System;
using System.Collections.Generic;

namespace POOI_Module11_JeuTir
{
    class Program
    {
        static void Main(string[] args)
        {
            DemarrerProgramme();            
        }
        public static void DemarrerProgramme()
        {
            Joueur.Joueur nouveauJoueur = new Joueur.Joueur();
            nouveauJoueur.RamasserArme(new BalaiToilette());
            nouveauJoueur.RamasserArme(new PulverisateurCarottes());

            for(int index = 0; index< nouveauJoueur.ListeArmes.Count; index++)
            {
                nouveauJoueur.SelectionnerArme(index);
                nouveauJoueur.TirerJoueur();
            }            
        }
    }    
}

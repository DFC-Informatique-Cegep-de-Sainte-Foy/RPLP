﻿using POOI_Module11_JeuTir.Objet;

namespace POOI_Module11_JeuTir.Physique
{
    public class CollisionTir : ICollision
    {
        public ObjetJeu ObjetTouche { get; set; }
        public double Degat { get; set; }
    }
}

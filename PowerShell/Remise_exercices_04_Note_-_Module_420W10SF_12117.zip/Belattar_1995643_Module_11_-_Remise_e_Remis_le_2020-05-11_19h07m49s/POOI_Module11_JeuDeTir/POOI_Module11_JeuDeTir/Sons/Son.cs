﻿using System;

namespace POOI_Module11_JeuTir.Sons
{
    public class Son
    {
        public string TexteDuSon { get; set; } = "Test Réussi";

        public Son(string p_son)
        {
            if (string.IsNullOrWhiteSpace(p_son))
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_son));
            }

            this.TexteDuSon = p_son;
        }
    }
}

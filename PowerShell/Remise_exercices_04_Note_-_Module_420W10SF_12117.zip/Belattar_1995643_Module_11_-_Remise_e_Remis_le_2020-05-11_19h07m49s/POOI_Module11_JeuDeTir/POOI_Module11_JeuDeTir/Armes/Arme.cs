﻿using System;

using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Joueurs;
using POOI_Module11_JeuTir.Objet;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;

namespace POOI_Module11_JeuTir.Armes
{
    public abstract class Arme
    {
        public int Temperature { get; private set; }
        public Son SonTir { get; private set; }
        public Son SonTropChaud { get; private set; }

        public Arme(int p_temperature, Son p_sonTir, Son p_sonTropChaud)
        {
            if (p_sonTir == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_sonTir));
            }
            if (p_sonTropChaud == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_sonTropChaud));
            }

            this.Temperature = p_temperature;
            this.SonTir = p_sonTir;
            this.SonTropChaud = p_sonTropChaud;

        }

        public virtual CollisionTir Tirer(Point3D p_positionArme, Vecteur3D p_direction)
        {
            if (p_positionArme == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_positionArme));
            }
            if (p_direction == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_direction));
            }

            CollisionTir collisionTir = new CollisionTir();
            collisionTir.DefinirObjetTouche(this.ObtenirCollision(p_positionArme, p_direction));
            collisionTir.DefinirDegat(this.CalculerDegat());

            return collisionTir;
        }

        protected virtual double CalculerDegat()
        {
            throw new NotImplementedException();
        }

        private ObjetJeu ObtenirCollision(Point3D p_positionArme, Vecteur3D p_direction)
        {
            if (p_positionArme == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_positionArme));
            }
            if (p_direction == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_direction));
            }

            return new ObjetMobile(); // Normalement un calcul ici
        }
    }
}

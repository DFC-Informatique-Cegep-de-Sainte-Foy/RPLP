﻿using System;
using System.Collections.Generic;

using POOI_Module11_JeuTir.Armes;
using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;

namespace POOI_Module11_JeuTir.Joueurs
{
    public class Joueur : ObjetMobile
    {
        private Arme m_armeSelectionnee;
        private Vecteur3D m_directionRegard;
        private Point3D m_position;
        private List<Arme> m_armes;

        public List<Arme> Armes
        {
            get
            {
                return new List<Arme>(this.m_armes);
            }
        }
        public MoteurSon MoteurSon { get; private set; } 

        public Joueur(List<Arme> p_listeArme, Point3D p_position, Vecteur3D p_directionRegard)
        {
            if (p_listeArme == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_listeArme));
            }
            if (p_position == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_position));
            }
            if (p_directionRegard == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_directionRegard));
            }
            this.m_armes = p_listeArme;
            this.m_armeSelectionnee = this.m_armes[0];
            this.m_position = p_position;
            this.m_directionRegard = p_directionRegard;
            this.MoteurSon = new MoteurSon();
        }

        public void RamasserArme(Arme p_arme)
        {
            if (p_arme == null)
            {
                throw new ArgumentException("Le paramètre ne peut pas être null", nameof(p_arme));
            }

            this.m_armes.Add(p_arme);
        }

        public void Tirer()
        {
            if (this.m_armeSelectionnee.Temperature < 250)
            {
                CollisionTir col = this.m_armeSelectionnee.Tirer(this.m_position, this.m_directionRegard);
                if (col != null)
                {
                    col.ObjetTouche.AppliquerDomage(col.Degat);
                }
                this.MoteurSon.LireSon(this.m_armeSelectionnee.SonTir);
            }
            else
            {
                this.MoteurSon.LireSon(this.m_armeSelectionnee.SonTropChaud);
            }
        }

        public void SelectionnerArme(int p_numeroArme)
        {
            if (p_numeroArme < 0 || p_numeroArme >= this.m_armes.Count)
            {
                throw new ArgumentException("Le numéro d'arme doit être présent dans les indices existants de la liste d'armes",nameof(p_numeroArme));
            }

            this.m_armeSelectionnee = this.m_armes[p_numeroArme];
        }
    }
}

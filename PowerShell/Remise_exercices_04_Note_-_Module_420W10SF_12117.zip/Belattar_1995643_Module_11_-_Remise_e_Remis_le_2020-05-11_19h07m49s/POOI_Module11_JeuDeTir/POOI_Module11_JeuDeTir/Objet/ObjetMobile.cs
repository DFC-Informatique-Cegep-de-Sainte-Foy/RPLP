﻿using POOI_Module11_JeuTir.Objet;

namespace POOI_Module11_JeuTir.Joueurs
{
    public class ObjetMobile : ObjetJeu
    {

        public override void AppliquerDomage(double p_degat)
        {
            ;
        }

    }
}
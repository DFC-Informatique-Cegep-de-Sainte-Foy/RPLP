﻿using H2020_ER1_MoteurJeu_1994563;
using H2020_ER1_MoteurJeu_1994563.Armes;
using H2020_ER1_MoteurJeu_1994563.Joueur;
using System;
using System.Collections.Generic;

namespace Moteur_Jeu_1994563
{
    class Program
    {
        static void Main(string[] args)
        {
            GestionJeuConsole.Jouer();
        }
    }
}

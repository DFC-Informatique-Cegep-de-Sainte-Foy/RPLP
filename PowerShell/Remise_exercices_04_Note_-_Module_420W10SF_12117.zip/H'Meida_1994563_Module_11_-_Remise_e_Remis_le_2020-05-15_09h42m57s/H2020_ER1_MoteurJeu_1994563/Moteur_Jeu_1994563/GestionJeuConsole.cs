﻿using H2020_ER1_MoteurJeu_1994563;
using H2020_ER1_MoteurJeu_1994563.Armes;
using H2020_ER1_MoteurJeu_1994563.Joueur;
using H2020_ER1_MoteurJeu_1994563.Sons;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Moteur_Jeu_1994563
{

   public  class GestionJeuConsole
    {
        public static void MenuJeu()
        {
            Console.Out.WriteLine("1-Ajouter un arme");
            Console.Out.WriteLine("2-Selectionner un arme");
            Console.Out.WriteLine("3-Tirer Son arme");
            Console.Out.WriteLine("4 Quitter");
        }
        public static int  ChoixJoueur()
        {
            int choixJoueur = 0;
            do
            {
                Console.Out.WriteLine();
                choixJoueur = Console.In.ReadInt();
            } while (choixJoueur<1 || choixJoueur>5);
            return choixJoueur;
        }
        public static void Jouer()
        { 
            int choix = 0;
            List<Arme> armes = new List<Arme>();
            Arme armeSelectionner1 = new Stylo();
            Arme armeSelectionner2= new PulverisateurCarottes();
            Arme armeSelectionner3= new BalaiToilette();
            Joueur joueur1 = new Joueur(armes);
            do
            {
                MenuJeu();
                choix = ChoixJoueur();
                
                switch (choix)
                {
                    case 1:
                        joueur1.RamasserArme(armeSelectionner1);
                        joueur1.RamasserArme(armeSelectionner2);
                        
                        break;
                    case 2:
                        joueur1.SelectionnerArme(1);
                        Console.Out.WriteLine();
                        break;
                    case 3:
                        joueur1.Tirer();
                        break;
                    case 4:
                        Console.Out.WriteLine("Choix invalide ");
                        break;
                }

            } while (choix!=5);
           
        }
    }

}


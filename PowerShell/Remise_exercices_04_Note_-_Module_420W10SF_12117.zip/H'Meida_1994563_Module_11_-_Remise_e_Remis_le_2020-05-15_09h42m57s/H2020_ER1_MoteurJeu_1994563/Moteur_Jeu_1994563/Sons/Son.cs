﻿using System;
using System.Collections.Generic;
using System.Text;

namespace H2020_ER1_MoteurJeu_1994563.Sons
{
    public class Son
    {
        public string TexteDuSon { get; set; }

        public Son(string p_texteDuSon)
        {
            this.TexteDuSon = p_texteDuSon;
        }

    }
}

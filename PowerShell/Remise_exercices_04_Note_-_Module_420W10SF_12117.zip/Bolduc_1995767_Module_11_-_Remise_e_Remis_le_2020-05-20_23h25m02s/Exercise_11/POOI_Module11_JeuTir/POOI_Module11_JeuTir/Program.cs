﻿using POOI_Module11_JeuTir.Armes;
using POOI_Module11_JeuTir.Joueurs;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;
using System;

namespace POOI_Module11_JeuTir
{
    class Program
    {
        static void Main(string[] args)
        {
            TestJeux();
        }

        public static void TestJeux()
        {
            Joueur joueur = new Joueur();
            string son = "";
            int indexChoixMenu = 0;
            
            Console.Out.WriteLine("Veuillez entrer votre nom");
            string nomJoueur = Console.In.ReadLine();

            Console.Out.WriteLine(nomJoueur.ToString() + ", choisi ton arme");
            Console.Out.WriteLine("(1) Le Balai Toilette");
            Console.Out.WriteLine("(2) Le Puvérisateur Carotte");
            Console.Out.WriteLine("(3) Le Stylo");
            indexChoixMenu = Console.In.ReadInt();

            switch (indexChoixMenu)
            {
                case 1:
                    {
                        BalaiToilette balaiToilette = new BalaiToilette();
                        joueur.RamasserArme(balaiToilette);
                        son = "Chplouf";


                    } break;

                case 2:
                    {
                        PulverisateurCarottes pulverisateurCarottes = new PulverisateurCarottes();
                        joueur.RamasserArme(pulverisateurCarottes);
                        son = "GloupGloup";
                    } break;

                case 3:
                    {
                        Stylo stylo = new Stylo();
                        joueur.RamasserArme(stylo);
                        son = "Tuctuctuctuc";
                    } break;
            }

            Console.Out.WriteLine("Commande:(1) Attaquer, (0) Quiter");
            indexChoixMenu = Console.In.ReadInt();
            while (indexChoixMenu != 0)
            {
                if(indexChoixMenu == 1)
                {
                    //joueur.Tirer(); //Je n'ai pas travailler le code pour pouvoir tiré
                    Console.Out.WriteLine(son.ToString());

                }
                indexChoixMenu = Console.In.ReadInt();
            }


        }
    }    
}

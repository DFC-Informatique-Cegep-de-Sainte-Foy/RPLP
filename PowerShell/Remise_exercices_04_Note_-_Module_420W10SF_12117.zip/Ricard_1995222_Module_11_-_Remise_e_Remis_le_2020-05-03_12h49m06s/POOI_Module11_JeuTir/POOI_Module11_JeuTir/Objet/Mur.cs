﻿using POOI_Module11_JeuTir.Geometrie;
using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir.Objet
{
    public class Mur : ObjetStatique
    {
            
        public override void AppliquerDomage(double p_degat)
        {
            if (p_degat < 1)
            {
                { throw new ArgumentException("Les degats ne peuvent pas etre negatif", "p_degat"); }
            }

            // aurait un calcul si l'objet avait de lenergie...
        }
    }
}

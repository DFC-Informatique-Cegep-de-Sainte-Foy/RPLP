﻿using POOI_Module11_JeuTir.Sons;

namespace POOI_Module11_JeuTir.Armes
{
    public class Stylo : Arme
    {

        public Stylo() : base()      // Jai fait des constructeur difference a chaque class fille car le son est different pour chaque arme
        {
            Son sonTir = new Son("FLIP!");
            Son sonTropchaud = new Son("CRACK!");

            base.SonTir = sonTir;
            base.SonTropChaud = sonTropchaud;
        }
        protected override double CalculerDegat()
        {
            return 1.0;
        }
    }
}

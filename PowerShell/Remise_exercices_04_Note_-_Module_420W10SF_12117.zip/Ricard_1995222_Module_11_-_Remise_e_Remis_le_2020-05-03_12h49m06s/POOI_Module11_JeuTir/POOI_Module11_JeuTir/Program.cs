﻿using POOI_Module11_JeuTir.Joueur;
using System;
using POOI_Module11_JeuTir.Armes;
using POOI_Module11_JeuTir.Sons;

namespace POOI_Module11_JeuTir
{
    class Program
    {
        static void Main(string[] args)
        {

            InterfaceUtilisateur.ProgramJoueur();



        }
    }
       
}

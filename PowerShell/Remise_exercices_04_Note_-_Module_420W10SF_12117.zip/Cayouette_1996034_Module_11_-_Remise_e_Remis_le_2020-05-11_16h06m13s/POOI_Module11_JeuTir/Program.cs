﻿using POOI_Module11_JeuTir.Joueur;
using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Objet;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;
using System;

namespace POOI_Module11_JeuTir
{
     class Program
    {
        static void Main(string[] args)
        {
            Joueur.Joueur frank = new Joueur.Joueur();
            frank.RamasserArme(new Armes.PulverisateurCarottes());
            frank.SelectionnerArme(1);
            frank.Tirer();
        }
    }
}

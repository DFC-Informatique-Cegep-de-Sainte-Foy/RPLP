﻿using POOI_Module11_JeuTir.Objet;

namespace POOI_Module11_JeuTir.Physique
{
    
    //public class ICollision
    public interface ICollision
    {
        //public ObjetJeu ObjetTouche { get; set; }
    }
}

﻿using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Objet;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;
using System;

namespace POOI_Module11_JeuTir.Armes
{
    public class PulverisateurCarottes : Arme
    {
        public PulverisateurCarottes() : base(new MoteurSon() { TexteDuSon = "GloupGloup" }, new MoteurSon() { TexteDuSon = "Gloupeufpeufpeuf" })
        {
            ;
        }


        public override CollisionTir Tirer(Point3D p_positionArme, Vecteur3D p_direction)
        {
            if (p_positionArme.X < 0)
            {
                throw new ArgumentException("La position du X dans le Point3D ne peut être négatif", nameof(p_positionArme.X));
            }

            if (p_positionArme.Y < 0)
            {
                throw new ArgumentException("La position du Y dans le Point3D ne peut être négatif", nameof(p_positionArme.Y));
            }
            if (p_positionArme.Z < 0)
            {
                throw new ArgumentException("La position du Z dans le Point3D ne peut être négatif", nameof(p_positionArme.Z));
            }

            if (p_direction.X < 0)
            {
                throw new ArgumentException("La position du X dans le Vecteur3D ne peut être négatif", nameof(p_direction.X));
            }

            if (p_direction.Y < 0)
            {
                throw new ArgumentException("La position du Y dans le Vecteur3D ne peut être négatif", nameof(p_direction.Y));
            }
            if (p_direction.Z < 0)
            {
                throw new ArgumentException("La position du Z dans le Vecteur3D ne peut être négatif", nameof(p_direction.Z));
            }
            CollisionTir collisionTir = new CollisionTir
            {
                ObjetTouche = ObtenirCollision(p_positionArme, p_direction),
                Degat = CalculerDegat()
            };

            return collisionTir;
        }

        protected override ObjetJeu ObtenirCollision(Point3D p_positionArme, Vecteur3D p_direction)
        {
            return new Mur(); // Normalement un calcul ici
        }
        protected override double CalculerDegat()
        {
            return (new Random(DateTime.Now.Millisecond)).NextDouble() * 100;
        }

    }
}

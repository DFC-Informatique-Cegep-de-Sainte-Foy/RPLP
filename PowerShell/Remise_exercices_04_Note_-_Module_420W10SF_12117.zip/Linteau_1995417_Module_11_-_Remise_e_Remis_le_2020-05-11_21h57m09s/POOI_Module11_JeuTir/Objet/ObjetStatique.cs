﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir.Objet
{
    public class ObjetStatique : ObjetJeu
    {
        public override void AppliquerDomage(double p_degat)
        {
            if (p_degat < 0)
            {
                throw new ArgumentException("La valeur du dégât ne peut être négative", nameof(p_degat));
            }
            //throw new NotImplementedException();
        }
    }
}

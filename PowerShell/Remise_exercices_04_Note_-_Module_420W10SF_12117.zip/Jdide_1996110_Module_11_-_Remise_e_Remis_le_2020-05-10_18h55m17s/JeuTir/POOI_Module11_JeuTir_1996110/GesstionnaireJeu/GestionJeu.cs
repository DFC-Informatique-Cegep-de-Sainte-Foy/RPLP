﻿using POOI_Module11_JeuTir.Armes;
using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Sons;
using POOI_Module11_JeuTir_1996110.Joueur;
using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir.GesstionnaireJeu
{
    public class GestionJeu
    {
        public static void GererJeuTir()
        {
            Joueurs joueur1 = null;
            int choixUtilisateur = 0;
            do
            {
                AfficherMenuJeu();
                choixUtilisateur = ValiderChoixMenuUtilisateur();
                switch (choixUtilisateur)
                {
                    case 1:
                        joueur1 = CreerJoueur();
                        break;
                    case 2:
                        if (joueur1 != null)
                        {
                            RamasserArme(joueur1);
                        }
                        else
                        {
                            Console.WriteLine("Le Joueur est vide");
                        }
                        break;
                    case 3:
                        if (joueur1 != null)
                        {
                            SelectionnerArme(joueur1);
                        }
                        else
                        {
                            Console.WriteLine("Le Joueur  est vide");
                        }
                        break;
                    case 4:
                        if (joueur1 != null)
                        {
                            Tirer(joueur1);
                        }
                        else
                        {
                            Console.WriteLine("Le joueur est vide");
                        }
                        break;
                    case 5:
                        choixUtilisateur = 5;

                        break;

                    default:
                        break;
                }

            } while (choixUtilisateur != 5);
        }
        private static void AfficherMenuJeu()
        {
            Console.Out.WriteLine("1.Créer joueur ");
            Console.Out.WriteLine("2.Ramasser arme arme  ");
            Console.Out.WriteLine("3.Sélectionner arme  ");
            Console.Out.WriteLine("4.Tirer arme ");
            Console.Out.WriteLine("5.Quitter ");
        }
        private static int ValiderChoixMenuUtilisateur()
        {
            int choixUtilisateur = 0;
            do
            {
                Console.Out.WriteLine("Votre choix ");
                Console.Out.Write("?");
                choixUtilisateur = Console.In.ReadInt();

            } while (choixUtilisateur < 1 || choixUtilisateur > 5);
            return choixUtilisateur;
        }
        private static void Tirer(Joueurs p_joueur)
        {
            if (p_joueur == null)
            {
                throw new ArgumentOutOfRangeException("Le joueur ne doit pas être nul", nameof(p_joueur));
            }

            p_joueur.Tirer();
        }
        private static void RamasserArme(Joueurs p_joueur)
        {
            if (p_joueur == null)
            {
                throw new ArgumentOutOfRangeException("Le joueur ne doit pas être nul", nameof(p_joueur));
            }
            ////Son son1 = new Son("hop");
            ////Son son2 = new Son("so");
            ////Son son3 = new Son("to");
            ////Son son4 = new Son("hoho");
            ////Son son5 = new Son("ton");
            Arme arme1 = new BalaiToilette(300);
            Arme arme2 = new Stylo(50);
            Arme arme3 = new PulverisateurCarottes(100);



            Point3D point3D = new Point3D();
            Vecteur3D vecteur3D = new Vecteur3D();
            p_joueur.RamasserArme(arme1);
            p_joueur.RamasserArme(arme2);
            p_joueur.RamasserArme(arme3);
        }

        private static void SelectionnerArme(Joueurs p_joueur)
        {
            if (p_joueur == null)
            {
                throw new ArgumentOutOfRangeException("Le joueur ne doit pas être nul", nameof(p_joueur));
            }
            int numeroArme = 0;
            Console.Out.WriteLine("Saisi le numéro de l'arme entre 0 et " + p_joueur.Armes.Count);
            numeroArme = Console.In.ReadInt();
            if (numeroArme <= p_joueur.Armes.Count)
            {
                p_joueur.SelectionnerArme(numeroArme);

            }
            else
            {
                Console.WriteLine("L'index de l'arme n'existe pas veuillez choisir un autre ");
            }
        }
        private static Joueurs CreerJoueur()
        {
            Joueurs joueur = new Joueurs();
            return joueur;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir.Sons
{
   public  class MoteurSon
    {
        public void LireSon(Son p_son)
        {
            if (p_son==null)
            {
                throw new ArgumentOutOfRangeException("Le son ne doit pas être nul",nameof(p_son));
            }
            Console.Out.WriteLine(p_son.TexteDuSon);
        }
    }
}

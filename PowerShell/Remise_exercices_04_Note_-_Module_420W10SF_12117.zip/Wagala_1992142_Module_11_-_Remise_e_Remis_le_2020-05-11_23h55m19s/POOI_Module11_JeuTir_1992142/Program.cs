﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POOI_Module11_JeuTir.Geometrie;
using POOI_Module11_JeuTir.Objet;
using POOI_Module11_JeuTir.Physique;
using POOI_Module11_JeuTir.Sons;
using POOI_Module11_JeuTir.Joueurs;
using POOI_Module11_JeuTir.Armes;

namespace POOI_Module11_JeuTir
{
    class Program
    {
        static void Main(string[] args)
        {
            Joueur momo = new Joueur();
            Joueur jacques = new Joueur();
            jacques.Position = new Point3D { X = 1, Y = 0, Z = 0 };
            

            BalaiToilette balaiMagique = new BalaiToilette();
            momo.RamasserArme(balaiMagique);

            momo.SelectionnerArme(1);
            momo.Tirer();


            


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POOI_Module11_JeuTir.Sons
{
    public class Son
    {
        public string TexteDuSon { get; set; }
    }
}

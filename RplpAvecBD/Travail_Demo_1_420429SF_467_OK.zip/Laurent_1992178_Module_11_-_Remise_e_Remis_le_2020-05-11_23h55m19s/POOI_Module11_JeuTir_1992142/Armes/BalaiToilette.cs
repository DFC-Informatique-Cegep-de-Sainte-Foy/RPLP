﻿using System;
using POOI_Module11_JeuTir.Sons;

namespace POOI_Module11_JeuTir.Armes
{
    public class BalaiToilette : Arme
    {
        public BalaiToilette() : base(new Son() { TexteDuSon = "TchaTcha" }, new Son() { TexteDuSon = "TchaPoooo" })
        {
            ;
        }
        protected override double CalculerDegat()
        {
            return (new Random(DateTime.Now.Millisecond)).NextDouble() * 40 + 10;
        }
    }
}

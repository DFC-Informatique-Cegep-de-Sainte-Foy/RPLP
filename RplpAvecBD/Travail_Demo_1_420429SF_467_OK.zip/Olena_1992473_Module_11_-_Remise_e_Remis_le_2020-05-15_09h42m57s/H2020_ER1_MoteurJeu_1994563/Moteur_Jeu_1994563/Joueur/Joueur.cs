﻿using H2020_ER1_MoteurJeu_1994563.Armes;
using H2020_ER1_MoteurJeu_1994563.Geometrie;
using H2020_ER1_MoteurJeu_1994563.Physique;
using H2020_ER1_MoteurJeu_1994563.Sons;
using System;
using System.Collections.Generic;
using System.Text;

namespace H2020_ER1_MoteurJeu_1994563.Joueur
{
   public class Joueur:ObjectMobile
    {
        private List<Arme> m_armes;
        public List<Arme> Armes
        {
            get
            {
                return new List<Arme>(this.m_armes);
            }
        }

        private Arme m_armeSelectionnee;
        private Vecteur3D m_directionRegard;
        private Point3D m_position;

        public MoteurSon MoteurSon { get; private set; }

        public Joueur( List<Arme> p_armes)
        {
            this.MoteurSon = new MoteurSon();
            this.m_armes =p_armes;
            this.m_position = new Point3D() { CoordonneX = 0, CoordonneY = 0, CoordonneZ = 0 };
            this.m_directionRegard = new Vecteur3D() { CoordonneX = 1, CoordonneY = 0, CoordonneZ = 0 };
        }

        public void RamasserArme(Arme p_arme)
        {
            if (p_arme==null)
            {
                throw new ArgumentNullException("l'arme ne doit pas être null",nameof(p_arme));
            }
            this.m_armes.Add(p_arme);
        }

        public void Tirer()
        {
            if (this.m_armeSelectionnee.Temperature < 250)
            {
                CollisionTir col = this.m_armeSelectionnee.Tirer(this.m_position, this.m_directionRegard);
                if (col != null)
                {
                    col.ObjetTouche.AppliquerDomage(col.Degat);
                }
                this.MoteurSon.LireSon(this.m_armeSelectionnee.SonTir);
            }
            else
            {
                this.MoteurSon.LireSon(this.m_armeSelectionnee.SonTropChaud);
            }
        }

        public void SelectionnerArme(int p_numeroArme)
        {
            if (p_numeroArme<0)
            {
                throw new ArgumentOutOfRangeException("Le numero de l'arme ne doit pas être négative",nameof(p_numeroArme));
            }
            this.m_armeSelectionnee = this.m_armes[p_numeroArme];
        }
    }
}

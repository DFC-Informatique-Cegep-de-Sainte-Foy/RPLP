﻿using System;
using System.Collections.Generic;
using System.Text;

namespace H2020_ER1_MoteurJeu_1994563
{
   public class Point3D
    {
        public double CoordonneX { get; set; }
        public double CoordonneY { get; set; }
        public double CoordonneZ { get; set; }
    }
}

﻿using POOI_Module11_JeuTir.InterfaceUtilisateur;
using System;

namespace POOI_Module11_JeuTir
{
    class Program
    {
        static void Main(string[] args)
        {
            UI_Principal.ProgrammePrincipal();
        }
    }    
}

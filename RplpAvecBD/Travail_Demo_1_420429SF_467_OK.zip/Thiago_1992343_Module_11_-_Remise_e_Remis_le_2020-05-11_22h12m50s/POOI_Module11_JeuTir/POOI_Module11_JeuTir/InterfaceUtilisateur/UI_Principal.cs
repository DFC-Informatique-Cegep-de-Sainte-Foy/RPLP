﻿using POOI_Module11_JeuTir.Joueur;
using System;
using System.Collections.Generic;
using System.Text;
using POOI_Module11_JeuTir.InterfaceUtilisateur;

namespace POOI_Module11_JeuTir.InterfaceUtilisateur
{
    class UI_Principal
    {
        public static void ProgrammePrincipal()
        {
            Joueurs joueur1 = new Joueurs();

            AfficherMenuInitial();
            int choixMenu = SaisirOptionMenu();

            while (choixMenu != 3)
            {
                switch (choixMenu)
                {
                    case 1:
                        Console.Clear();
                        AfficherSousMenuArme();
                        
                        int choixArme = 0;
                        choixArme = SaisirChoixArme();
                        joueur1.SelectionnerArme(choixArme);
                        break;
                    case 2:
                        joueur1.Tirer();
                        break;
                }

                AfficherMenuInitial();
                choixMenu = SaisirOptionMenu();
            }

        }

        private static void AfficherMenuInitial()
        {
            Console.Clear();
            Console.Out.WriteLine("********* MENU ININIAL *********");
            Console.Out.WriteLine("* 1 - SELECTIONNER UNE ARME    *");
            Console.Out.WriteLine("* 2 - TIRER                    *");
            Console.Out.WriteLine("* 3 - QUITTER                  *");
            Console.Out.WriteLine("********************************");
        }

        private static void AfficherSousMenuArme()
        {
            Console.Clear();
            Console.Out.WriteLine("******** SOUS MENU ARME ********");
            Console.Out.WriteLine("* 0 - BALAI TOILETTE           *");
            Console.Out.WriteLine("* 1 - PULVERISATEUR CAROTTES   *");
            Console.Out.WriteLine("* 2 - STYLO                    *");
            Console.Out.WriteLine("********************************");
        }

        private static int SaisirOptionMenu()
        {
            int choix = 0;
            do
            {
                Console.Write("? ");
                choix = Console.In.ReadInt();

            } while (choix < 1 || choix > 3);

            return choix;
        }

        private static int SaisirChoixArme()
        {
            int choix = 0;
            do
            {
                Console.Write("? ");
                choix = Console.In.ReadInt();

            } while (choix < 0 || choix > 2);

            return choix;
        }
    }
}

﻿namespace POOI_Module11_JeuTir.Armes
{
    public class Stylo : Arme
    {
        protected override double CalculerDegat()
        {
            return 1.0;
        }
    }
}

﻿namespace POOI_Module11_JeuTir.Physique
{
    public class CollisionTir : Collision
    {
        public double Degat { get; set; }
    }
}

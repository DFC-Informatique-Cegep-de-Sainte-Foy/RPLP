﻿using POOI_Module11_JeuTir.Geometrie;
using System;
using System.Collections.Generic;
using System.Text;

namespace POOI_Module11_JeuTir.Objet
{
    public interface IObjetJeu
    {
        // ...
        Point3D Position { get; set; }
        Vecteur3D Direction { get; set; }

        void AppliquerDomage(double p_degat);
    }
}

﻿using POOI_Module11_JeuTir.GesstionnaireJeu;
using System;

namespace POOI_Module11_JeuTir_1996110
{
    class Program
    {
        static void Main(string[] args)
        {
            GestionJeu.GererJeuTir();
        }
    }
}

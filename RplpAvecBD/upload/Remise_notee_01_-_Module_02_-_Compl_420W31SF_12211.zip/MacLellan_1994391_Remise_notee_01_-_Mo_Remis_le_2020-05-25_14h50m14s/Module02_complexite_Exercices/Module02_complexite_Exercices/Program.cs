﻿using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Module02_complexite_Exercices
{
    class Program
    {
        static void Main(string[] args)
        {
            //Exercice 3 1)
            List<int> p_valeurs = new List<int>() { 12, 45, 64, 23, 12, 8, 7, 6, 23 };
            int valeurMin = RechercheValeurMinimal(p_valeurs);
            int valeurMin2 = RechercheValeurMinimalAvecListeTrie(p_valeurs);

            Console.Write("Voici la liste: ");
            foreach (int valeur in p_valeurs)
            {
                Console.Write(" " + valeur);
            }
            Console.WriteLine();
            Console.WriteLine("Min (liste pas triee): {0}", valeurMin);

            Console.WriteLine();
            Console.WriteLine("Min (liste triee): {0}", valeurMin2);
        }

        //Exercice 3 
        // 1)
        public static TypeElement RechercheValeurMinimal<TypeElement>(List<TypeElement> p_valeurs)
            where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null) { throw new ArgumentNullException(nameof(p_valeurs)); }
            TypeElement valeurMin = p_valeurs[0];
            for (int indiceListe = 0; indiceListe < p_valeurs.Count; indiceListe++)
            {
                if (p_valeurs[indiceListe].CompareTo(valeurMin) < 0)
                {
                    valeurMin = p_valeurs[indiceListe];
                }
            }
            return valeurMin;
        }
        // Type de complexite : O(n) lineaire

        // 2)
        public static TypeElement RechercheValeurMinimalAvecListeTrie<TypeElement>(List<TypeElement> p_valeurs)
            where TypeElement : IComparable<TypeElement>
        {
            TypeElement valeurMin = p_valeurs[0];
            List<TypeElement> listeTriee = TriABulle(p_valeurs);

            valeurMin = listeTriee[0];

            return valeurMin;
        }

        public static List<TypeElement> CopierTableau<TypeElement>(List<TypeElement> p_valeurs)
        {
            if (p_valeurs == null) { throw new ArgumentNullException(nameof(p_valeurs)); }

            List<TypeElement> copieListe = new List<TypeElement>(p_valeurs.Count);

            for (int indiceListe = 0; indiceListe < p_valeurs.Count - 1; indiceListe++)
            {
                copieListe.Add(p_valeurs[indiceListe]);
            }

            return copieListe;
        }

        public static List<TypeElement> TriABulle<TypeElement>(List<TypeElement> p_valeurs)
            where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null) { throw new ArgumentNullException(nameof(p_valeurs)); }

            TypeElement ancienneValeur = default(TypeElement);
            bool permutationAuDernierTour = true;
            int indiceMax = p_valeurs.Count - 1;
            List<TypeElement> valeursCopiees = CopierTableau(p_valeurs);

            while (permutationAuDernierTour)
            {
                permutationAuDernierTour = false;
                for (int indiceCourant = 0; indiceCourant < indiceMax - 1; indiceCourant++)
                {
                    if (valeursCopiees[indiceCourant + 1].CompareTo(valeursCopiees[indiceCourant]) < 0)
                    {
                        ancienneValeur = valeursCopiees[indiceCourant + 1];
                        valeursCopiees[indiceCourant + 1] = valeursCopiees[indiceCourant];
                        valeursCopiees[indiceCourant] = ancienneValeur;
                        permutationAuDernierTour = true;
                    }
                }
                indiceMax = indiceMax - 1;
            }
            return valeursCopiees;
        }
        // type de complexite : O(n) meilleur des cas
        //                      O(n^2)  pire des cas
        //                      O(n^2)  moyenne


        // 3)

        // La recherche du minimum sans le tri est la plus efficace car elle est lineaire. La recherche du minimum avec une liste triee est moins efficace car elle varie (au pire des cas O(n^2)
        // et dans le meilleur des cas O(n). 
    }
}

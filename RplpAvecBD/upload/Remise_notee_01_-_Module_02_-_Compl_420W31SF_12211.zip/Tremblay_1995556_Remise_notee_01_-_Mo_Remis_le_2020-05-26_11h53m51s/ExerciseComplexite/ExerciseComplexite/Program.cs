﻿using System;
using System.Collections.Generic;

namespace ExerciseComplexite
{
    class Program
    {
        static void Main(string[] args)
        {
         
        }

        //exercise1

        public TypeElement RenvoiType<TypeElement>(List<TypeElement> p_liste)
            where TypeElement : IComparable<TypeElement>
        {
            TypeElement valeur = p_liste[0];

            for (int indice = 1; indice < p_liste.Count; indice++)
            {
                if (p_liste[indice].CompareTo(valeur) < 0)
                {
                    valeur = p_liste[indice];
                }             
            }
            return valeur;
        }

        //exercise2

        public static List<TypeElement> CopierListe<TypeElement>(List<TypeElement> p_valeurs)
        {
            List<TypeElement> listeCopiee = new List<TypeElement>();
            for (int indice = 0; indice < p_valeurs.Count; indice++)
            {
                listeCopiee[indice] = p_valeurs[indice];
            }

            return listeCopiee;
        }

        public TypeElement TriRenvoiMinimum<TypeElement>(List<TypeElement> p_liste)
            where TypeElement : IComparable<TypeElement>
        {

            List<TypeElement> listeTrie = new List<TypeElement>();

            if (p_liste == null)
            {
                throw new ArgumentNullException(nameof(p_liste));
            }

            TypeElement ancienneValeur;
            bool permutationDernierTour = true;
            int indiceMax = p_liste.Count- 1;
            listeTrie = CopierListe(p_liste);

            while (permutationDernierTour)
            {
                permutationDernierTour = false;

                for (int indiceCourant = 0; indiceCourant < indiceMax; indiceCourant++)
                {
                    if (listeTrie[indiceCourant + 1].CompareTo(listeTrie[indiceCourant]) > 1)
                    {
                        ancienneValeur = listeTrie[indiceCourant + 1];
                        listeTrie[indiceCourant + 1] = listeTrie[indiceCourant];
                        listeTrie[indiceCourant] = ancienneValeur;
                        permutationDernierTour = true;
                    }
                }
                indiceMax = indiceMax - 1;
            }
            return listeTrie[0];         
        }

        /*exercise3
        l'exercise 1 a une compléxité algorithmique de 0(n)
        l'exercise 2 a une compléxité algorithmique de 0(N2) dans le pire des cas et le meilleur cas O(N) et le retour sera toujours le premier de la liste car nous commencons par la trier.
        Avec le tri a bulle l'exercise 2 est moins efficace que l'exercise 1.
        */
    }
}

using System;
using Xunit;
using Exercice3;
using System.Collections.Generic;

namespace TestsExercice3
{
    public class TestsFonctions
    {
        [Fact]
        public void FonctionTrouverMinDansUneListeTriee_ListeNull_Exception()
        {
            List<int> ListeInitiale = null;
            Assert.Throws<ArgumentNullException>(() => { Fonctions.TrouverLaValeurMinimaleDansUneListeTriee(ListeInitiale); });
        }


        [Fact]
        public void FonctionTrouverMinDansUneListeNonTriee_ListeNull_Exception()
        {
            List<int> ListeInitiale = null;
            Assert.Throws<ArgumentNullException>(() => { Fonctions.TrouverLaValeurMinimaleDansUneListeNonTriee(ListeInitiale); });
        }

        [Fact]
        public void FonctionTrouverMinDansUneListeTriee_ListeVide_Exception()
        {

            //Arranger
            List<int> ListeInitiale = new List<int>() { };

            Assert.Throws<ArgumentNullException>(() => { Fonctions.TrouverLaValeurMinimaleDansUneListeTriee(ListeInitiale); });

        }

        [Fact]
        public void FonctionTrouverMinDansUneListeNonTriee_ListeVide_Exception()
        {

            //Arranger
            List<int> ListeInitiale = new List<int>() { };

            Assert.Throws<ArgumentNullException>(() => { Fonctions.TrouverLaValeurMinimaleDansUneListeNonTriee(ListeInitiale); });

        }

        [Fact]
        public void FonctionTrouverMinDansUneListeNonTriee_Valeur_UneValeur()
        {
            //Arranger
            List<int> ListeInitiale = new List<int>() { 0 };
            int minAttendue= 0;

            //Agir
            int minCalcule = Fonctions.TrouverLaValeurMinimaleDansUneListeNonTriee(ListeInitiale);

            //Auditer

            Assert.Equal(minAttendue, minCalcule);
        }

        [Fact]
        public void FonctionTrouverMinDansUneListeTriee_Valeur_UneValeur()
        {
            //Arranger
            List<int> ListeInitiale = new List<int>() { 0 };
            int minAttendue = 0;

            //Agir
            int minCalcule = Fonctions.TrouverLaValeurMinimaleDansUneListeTriee(ListeInitiale);

            //Auditer

            Assert.Equal(minAttendue, minCalcule);
        }

        [Fact]
        public void FonctionTrouverMinDansUneListeNonTriee_DeuxValeurs_UneValeurMinimale()
        {
            //Arranger
            List<int> ListeInitiale = new List<int>() { 100,-2 };
            int minAttendue = -2;

            //Agir
            int minCalcule = Fonctions.TrouverLaValeurMinimaleDansUneListeNonTriee(ListeInitiale);

            //Auditer

            Assert.Equal(minAttendue, minCalcule);
        }

        [Fact]
        public void FonctionTrouverMinDansUneListeTriee_DeuxValeurs_UneValeurMinimale()
        {
            //Arranger
            List<int> ListeInitiale = new List<int>() { 100, -2 };
            int minAttendue = -2;

            //Agir
            int minCalcule = Fonctions.TrouverLaValeurMinimaleDansUneListeTriee(ListeInitiale);

            //Auditer

            Assert.Equal(minAttendue, minCalcule);
        }

        [Fact]
        public void FonctionTrouverMinDansUneListeNonTriee_troisValeurs_UneValeurMinimale()
        {
            //Arranger
            List<int> ListeInitiale = new List<int>() { 100, -2,0 };
            int minAttendue = -2;

            //Agir
            int minCalcule = Fonctions.TrouverLaValeurMinimaleDansUneListeNonTriee(ListeInitiale);

            //Auditer

            Assert.Equal(minAttendue, minCalcule);
        }

        [Fact]
        public void FonctionTrouverMinDansUneListeTriee_troisValeurs_UneValeurMinimale()
        {
            //Arranger
            List<int> ListeInitiale = new List<int>() { 100, -2, 0 };
            int minAttendue = -2;

            //Agir
            int minCalcule = Fonctions.TrouverLaValeurMinimaleDansUneListeTriee(ListeInitiale);

            //Auditer

            Assert.Equal(minAttendue, minCalcule);
        }

        [Fact]
        public void CopierListe_Null_Exception()
        {
            List<int> ListeInitiale = null;
            Assert.Throws<ArgumentNullException>(() => { Fonctions.CopierListe(ListeInitiale); });
        }

        [Fact]
        public void CopierListe_Valeur_Vide()

        {
            //Arranger
            List<int> ListeDepart = new List<int>() { };
            List<int> ListeAttendue = new List<int>() { };

            //Agir
            List<int> ListeCopie = Fonctions.CopierListe(ListeDepart);


            //Auditer
            Assert.Equal(ListeAttendue, ListeCopie);
            Assert.Equal(ListeDepart, ListeAttendue);
            Assert.NotSame(ListeDepart, ListeCopie);
        }
        [Fact]
        public void CopierListe_Valeur_UneValeur()
        {
            //Arranger
            List<int> ListeInitiale = new List<int>() { 0 };
            List<int> ListeAttendue = new List<int>() { 0 };

            //Agir
            List<int> ListeCopie = Fonctions.CopierListe(ListeInitiale);


            //Auditer
            Assert.Equal(ListeAttendue, ListeCopie);
            Assert.Equal(ListeInitiale, ListeAttendue);
            Assert.NotSame(ListeInitiale, ListeCopie);
        }
        [Fact]
        public void CopierListe_Valeur_DeuxValeurs()
        {

            //Arranger
            List<int> ListeInitiale = new List<int>() { 0, 1000 };
            List<int> ListeAttendue = new List<int>() { 0, 1000 };

            //Agir
            List<int> ListeCopie = Fonctions.CopierListe(ListeInitiale);


            //Auditer
            Assert.Equal(ListeAttendue, ListeCopie);
            Assert.Equal(ListeInitiale, ListeAttendue);
            Assert.NotSame(ListeInitiale, ListeCopie);
        }

        [Fact]
        public void CopierListe_Valeur_TroisValeurs()
        {
            //Arranger
            List<int> ListeInitiale = new List<int>() { -5, 57, 110 };
            List<int> ListeAttendue = new List<int>() { -5, 57, 110 };

            //Agir
            List<int> ListeCopie = Fonctions.CopierListe(ListeInitiale);


            //Auditer
            Assert.Equal(ListeAttendue, ListeCopie);
            Assert.Equal(ListeInitiale, ListeAttendue);
            Assert.NotSame(ListeInitiale, ListeCopie);
        }


    }
}

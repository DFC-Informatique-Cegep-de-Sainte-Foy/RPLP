﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;


namespace Exercice3
{
    public class Fonctions
    {

        //Question 1:
        public static TypeElement TrouverLaValeurMinimaleDansUneListeNonTriee<TypeElement>(List<TypeElement> p_listeDesValeurs) where TypeElement : IComparable<TypeElement>
        {
            if (p_listeDesValeurs == null)
            {
                throw new ArgumentNullException("La liste ne peut pas etre null");
            }

            if (p_listeDesValeurs.Count == 0)
            {
                throw new ArgumentNullException("La liste ne peut pas etre vide");
            }


            TypeElement valeurMinimale = p_listeDesValeurs[0];

            for (int indiceListe = 1; indiceListe < p_listeDesValeurs.Count; indiceListe++)
            {
                if (valeurMinimale.CompareTo(p_listeDesValeurs[indiceListe]) > 0)
                {
                    valeurMinimale = p_listeDesValeurs[indiceListe];
                }
            }

            return valeurMinimale;

        }






        //Question 2:


        public static List<TypeElement> CopierListe<TypeElement>(List<TypeElement> p_valeurs)
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException(nameof(p_valeurs));
            }

            return p_valeurs.Select(e => e).ToList();
        }



        public static TypeElement TrouverLaValeurMinimaleDansUneListeTriee<TypeElement>(List<TypeElement> p_listeDesValeurs) where TypeElement : IComparable<TypeElement>
        {
            if (p_listeDesValeurs == null)
            {
                throw new ArgumentNullException("La liste ne peut pas etre null");
            }

            if (p_listeDesValeurs.Count == 0)
            {
                throw new ArgumentNullException("La liste ne peut pas etre vide");
            }


            List<TypeElement> listeCopie = CopierListe(p_listeDesValeurs);



            TypeElement ancienneValeur = default(TypeElement);
            bool permutationAuDernierTour = true;
            int indiceMax = listeCopie.Count - 1;
           

            while (permutationAuDernierTour)
            {
                permutationAuDernierTour = false;
                for (int indiceCourant = 0; indiceCourant <= indiceMax - 1; ++indiceCourant)
                {
                    if (listeCopie[indiceCourant + 1].CompareTo(listeCopie[indiceCourant]) < 0) 
                    {
                        ancienneValeur = listeCopie[indiceCourant + 1];
                        listeCopie[indiceCourant + 1] =listeCopie[indiceCourant];
                        listeCopie[indiceCourant] = ancienneValeur;
                        permutationAuDernierTour = true;
                    }
                }
                indiceMax = indiceMax - 1;
            }

            TypeElement valeurMinimale = listeCopie[0];

            return valeurMinimale;

        }


        //Question3:

        //Explication:
           //Dans la premiere fonction,on execute n-1 tests de comparaison.La compléxité est donc T(n) => O(n)
          // Dans la deuxieme fonction on a utilisé une fonction de tri a bulles qui va trier la liste avec un ordre croissant pour trouver la veul minimale .La compléxité de ce type de tri est donc T(n) => O(n*n)
         //pour la fonction de copie ,T(n) =O(n),et l'affectation simple T(n)=1.
        //Alors, dans ce cas ,le premier algorithme est plus efficace.
    }
}

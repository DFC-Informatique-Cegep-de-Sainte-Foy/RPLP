﻿using System;
using System.Linq;
using System.Collections.Generic;


namespace Exercice3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> listeDesEntiers = new List<int>() { 5, 10, 100, -2 };

            //int valeurMinimale = Fonctions.TrouverLaValeurMinimaleDansUneListeNonTriee(listeDesEntiers);
            //Console.Out.WriteLine(valeurMinimale);


             int valeurMin = Fonctions.TrouverLaValeurMinimaleDansUneListeTriee(listeDesEntiers);
             Console.Out.WriteLine(valeurMin);
        }
    }
}

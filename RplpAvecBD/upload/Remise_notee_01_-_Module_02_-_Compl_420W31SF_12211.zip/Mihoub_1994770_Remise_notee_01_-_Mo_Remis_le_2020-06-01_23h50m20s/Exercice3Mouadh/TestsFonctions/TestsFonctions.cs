using System;
using Xunit;
using Exercice3Mouadh;
using System.Linq;
using System.Collections.Generic;


namespace TestsExercice3
{
    public class TestsExercice3
    {
        public class TestsFonctions
        {
            [Fact]
            public void ChercherMinimumDansUneListeTriee_ListeVide_Exception()
            {

                //Arranger
                List<int> ListeInitiale = new List<int>() { };

                Assert.Throws<ArgumentNullException>(() => { Fonctions.ChercherMinimumDansUneListeTriee(ListeInitiale); });

            }

            [Fact]
            public void ChercherMinimumDansUneListeNonTriee_ListeVide_Exception()
            {

                //Arranger
                List<int> ListeInitiale = new List<int>() { };

                Assert.Throws<ArgumentNullException>(() => { Fonctions.ChercherMinimumDansUneListeNonTriee(ListeInitiale); });
            }

            [Fact]
            public void ChercherMinimumDansUneListeNonTriee_Valeur_UneSeuleValeur()
            {
                //Arranger
                List<int> ListeInitiale = new List<int>() { 1 };
                int minAttendue = 1;

                //Agir
                int minCalcule = Fonctions.ChercherMinimumDansUneListeNonTriee(ListeInitiale);

                //Auditer

                Assert.Equal(minAttendue, minCalcule);
            }

            [Fact]
            public void ChercherMinimumDansUneListeTriee_Valeur_UneValeur()
            {
                //Arranger
                List<int> ListeInitiale = new List<int>() { 4 };
                int minAttendue = 4;

                //Agir
                int minCalcule = Fonctions.ChercherMinimumDansUneListeTriee(ListeInitiale);

                //Auditer

                Assert.Equal(minAttendue, minCalcule);
            }
            [Fact]
            public void ChercherMinimumDansUneListeTriee_ListeNull_Exception()
            {
                List<int> ListeInitiale = null;
                Assert.Throws<ArgumentNullException>(() => { Fonctions.ChercherMinimumDansUneListeTriee(ListeInitiale); });
            }
            [Fact]
            public void ChercherMinimumDansUneListeNonTriee_ListeNull_Exception()
            {
                List<int> ListeInitiale = null;
                Assert.Throws<ArgumentNullException>(() => { Fonctions.ChercherMinimumDansUneListeNonTriee(ListeInitiale); });
            }
            [Fact]
            public void ChercherMinimumDansUneListeNonTriee_DeuxValeurs_UneValeurMinimale()
            {
                //Arranger
                List<int> ListeInitiale = new List<int>() { 6, 1 };
                int minAttendue = 1;

                //Agir
                int minCalcule = Fonctions.ChercherMinimumDansUneListeNonTriee(ListeInitiale);

                //Auditer

                Assert.Equal(minAttendue, minCalcule);
            }

            [Fact]
            public void ChercherMinimumDansUneListeTriee_DeuxValeurs_UneValeurMinimale()
            {
                //Arranger
                List<int> ListeInitiale = new List<int>() { -111, -1 };
                int minAttendue = -111;

                //Agir
                int minCalcule = Fonctions.ChercherMinimumDansUneListeTriee(ListeInitiale);

                //Auditer

                Assert.Equal(minAttendue, minCalcule);
            }

            [Fact]
            public void ChercherMinimumDansUneListeNonTriee_4Valeurs_UneValeurMinimale()
            {
                //Arranger
                List<int> ListeInitiale = new List<int>() { 5, -22, 100, -512 };
                int minAttendue = -512;

                //Agir
                int minCalcule = Fonctions.ChercherMinimumDansUneListeNonTriee(ListeInitiale);

                //Auditer

                Assert.Equal(minAttendue, minCalcule);
            }

            [Fact]
            public void ChercherMinimumDansUneListeTriee_troisValeurs_UneValeurMinimale()
            {
                //Arranger
                List<int> ListeInitiale = new List<int>() { -12, -10, 10 };
                int minAttendue = -12;

                //Agir
                int minCalcule = Fonctions.ChercherMinimumDansUneListeTriee(ListeInitiale);

                //Auditer

                Assert.Equal(minAttendue, minCalcule);
            }

            [Fact]
            public void CopierListe_Null_Exception()
            {
                List<int> ListeInitiale = null;
                Assert.Throws<ArgumentNullException>(() => { Fonctions.CopierListe(ListeInitiale); });
            }

            [Fact]
            public void CopierListe_Valeur_Vide()

            {
                //Arranger
                List<int> ListeDepart = new List<int>() { };
                List<int> ListeAttendue = new List<int>() { };

                //Agir
                List<int> ListeCopie = Fonctions.CopierListe(ListeDepart);


                //Auditer
                Assert.Equal(ListeAttendue, ListeCopie);
                Assert.Equal(ListeDepart, ListeAttendue);
                Assert.NotSame(ListeDepart, ListeCopie);
            }
            [Fact]
            public void CopierListe_Valeur_UneValeur()
            {
                //Arranger
                List<int> ListeInitiale = new List<int>() { 3 };
                List<int> ListeAttendue = new List<int>() { 3 };

                //Agir
                List<int> ListeCopie = Fonctions.CopierListe(ListeInitiale);


                //Auditer
                Assert.Equal(ListeAttendue, ListeCopie);
                Assert.Equal(ListeInitiale, ListeAttendue);
                Assert.NotSame(ListeInitiale, ListeCopie);
            }


            [Fact]
            public void CopierListe_Valeur_4Valeurs()
            {
                //Arranger
                List<int> ListeInitiale = new List<int>() { -157, -2, 33, 111 };
                List<int> ListeAttendue = new List<int>() { -157, -2, 33, 111 };

                //Agir
                List<int> ListeCopie = Fonctions.CopierListe(ListeInitiale);


                //Auditer
                Assert.Equal(ListeAttendue, ListeCopie);
                Assert.Equal(ListeInitiale, ListeAttendue);
                Assert.NotSame(ListeInitiale, ListeCopie);
            }
        }
    }
}

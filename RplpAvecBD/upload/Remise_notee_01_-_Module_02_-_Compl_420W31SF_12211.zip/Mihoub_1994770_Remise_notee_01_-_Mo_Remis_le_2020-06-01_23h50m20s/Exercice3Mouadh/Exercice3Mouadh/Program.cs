﻿using System;
using System.Linq;
using System.Collections.Generic;

namespace Exercice3Mouadh
{
    class Program
    {
        static void Main(string[] args)
        {

            //Réponse Question 3 : Dans le cas de la recherche du minimum, l'exécution est linéaire dans le temps: 
            //ce qui donne T(n)=O(n).
            //La compléxité du tris rapide est par contre = à O(nlog(n)), ce qui est plus complexe que le 1er cas. Donc le 1er 
            //algorithme est plus efficace

        }
    }
}

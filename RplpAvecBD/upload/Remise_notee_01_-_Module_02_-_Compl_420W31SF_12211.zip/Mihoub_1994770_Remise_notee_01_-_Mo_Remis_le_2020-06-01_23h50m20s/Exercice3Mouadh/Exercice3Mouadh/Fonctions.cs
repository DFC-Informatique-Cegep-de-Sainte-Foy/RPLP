﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Exercice3Mouadh
{
    public class Fonctions
    {

        /*Partie1:*/
        public static TypeElement ChercherMinimumDansUneListeNonTriee<TypeElement>(List<TypeElement> p_listeValeurs) where TypeElement : IComparable<TypeElement>
        {
            if (p_listeValeurs == null)
            {
                throw new ArgumentNullException("La liste est invalide");
            }

            if (p_listeValeurs.Count == 0)
            {
                throw new ArgumentNullException("La liste est  vide");
            }


            TypeElement minimum = p_listeValeurs[0];

            for (int indice = 1; indice < p_listeValeurs.Count; indice++)
            {
                if (minimum.CompareTo(p_listeValeurs[indice]) > 0)
                {
                    minimum = p_listeValeurs[indice];
                }
            }

            return minimum;

        }

        /*Partie2*/


        public static List<TypeElement> CopierListe<TypeElement>(List<TypeElement> p_valeurs)
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException(nameof(p_valeurs));
            }

            return p_valeurs.Select(e => e).ToList();
        }

        private static void TriRapide<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier) where TypeElement : IComparable<TypeElement>
        {
            int indicePivot = 0;
            if (p_indicePremier < p_indiceDernier)
            {
                indicePivot = ChoixPivot(p_valeurs, p_indicePremier, p_indiceDernier);
                indicePivot = Partitionner(p_valeurs, p_indicePremier, p_indiceDernier, indicePivot);
                TriRapide(p_valeurs, p_indicePremier, indicePivot - 1);
                TriRapide(p_valeurs, indicePivot + 1, p_indiceDernier);
            }
        }

        private static int ChoixPivot<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier)
        {
            return p_indicePremier;
        }

        private static int Partitionner<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier, int p_indicePivot) where TypeElement : IComparable<TypeElement>
        {

            TypeElement ancienneValeur = default(TypeElement);
            int futurIndicePivot = p_indicePremier;

            ancienneValeur = p_valeurs[p_indicePivot];
            p_valeurs[p_indicePivot] = p_valeurs[p_indiceDernier];
            p_valeurs[p_indiceDernier] = ancienneValeur;

            for (int indiceValeurARanger = p_indicePremier; indiceValeurARanger <= p_indiceDernier - 1; ++indiceValeurARanger)
            {
                if (p_valeurs[indiceValeurARanger].CompareTo(p_valeurs[p_indiceDernier]) <= 0)
                {
                    ancienneValeur = p_valeurs[futurIndicePivot];
                    p_valeurs[futurIndicePivot] = p_valeurs[indiceValeurARanger];
                    p_valeurs[indiceValeurARanger] = ancienneValeur;

                    futurIndicePivot = futurIndicePivot + 1;
                }
            }
            ancienneValeur = p_valeurs[futurIndicePivot];
            p_valeurs[futurIndicePivot] = p_valeurs[p_indiceDernier];
            p_valeurs[p_indiceDernier] = ancienneValeur;

            return futurIndicePivot;
        }

        public static TypeElement ChercherMinimumDansUneListeTriee<TypeElement>(List<TypeElement> p_listeDesValeurs) where TypeElement : IComparable<TypeElement>
        {
            if (p_listeDesValeurs == null)
            {
                throw new ArgumentNullException("La liste ne peut pas etre null");
            }

            if (p_listeDesValeurs.Count == 0)
            {
                throw new ArgumentNullException("La liste ne peut pas etre vide");
            }

            List<TypeElement> listeCopie = CopierListe(p_listeDesValeurs);

            TriRapide(listeCopie, 0, listeCopie.Count - 1);
            TypeElement minimum = listeCopie[0];

            return minimum;

        }

    }
}

using ALG_AVANCE_Module_02_Complexite;
using System;
using System.Collections.Generic;
using Xunit;

namespace TEST_ALG_AVANCE_MODULE02
{
    public class TestFonction
    {
        [Fact]
        public void RechercherMinimum_CasNull_Exception()
        {
            // Arranger
            List<int> listEntiers = null;
            // Agir && Auditer
            Assert.Throws<NullReferenceException>(
            () =>
            {
                int valeurChercher = Fonctions.RechercherMinimum(listEntiers);
            });
        }
        [Fact]
        public void RechercherMinimum_CasVide_Exception()
        {
            // Arranger
            List<int> listEntiers = new List<int>();
            // Agir && Auditer
            Assert.Throws<ArgumentException>(
            () => {
                int valeurChercher = Fonctions.RechercherMinimum(listEntiers);
            });
        }
        [Fact]
        public void RechercherMinimum_DeuxiemeEtQuatriemeEstMin_Retouner_valeurAttendu()
        {
            //Arranger
            List<int> entiersPositifs = new List<int> { -5, -11, 4, -11, 30, -10 };
            int valeurAttendu = -11;
            //Agir
            int minimumCalculer = Fonctions.RechercherMinimum(entiersPositifs);
            //Auditer
            Assert.Equal(valeurAttendu, minimumCalculer);
        }

        [Fact]
        public void RechercherMinimumParTrieRapide_CasNull_Exception()
        {
            // Arranger
            List<int> listEntiers = null;
            // Agir && Auditer
            Assert.Throws<NullReferenceException>(
            () =>
            {
                int valeurChercher = Fonctions.RechercherMinimumParTrieRapide(listEntiers);
            });
        }
        [Fact]
        public void RechercherMinimumParTrieRapide_CasVide_Exception()
        {
            // Arranger
            List<int> listEntiers = new List<int>();
            // Agir && Auditer
            Assert.Throws<ArgumentException>(
            () => {
                int valeurChercher = Fonctions.RechercherMinimumParTrieRapide(listEntiers);
            });
        }
        [Fact]
        public void RechercherMinimumParTrieRapide_DeuxiemeEtQuatriemeEstMin_Retouner_valeurAttendu()
        {
            //Arranger
            List<int> entiersPositifs = new List<int> { -5, -11, 4, -11, 30, -10 };
            int valeurAttendu = -11;
            //Agir
            int minimumCalculer = Fonctions.RechercherMinimumParTrieRapide(entiersPositifs);
            //Auditer
            Assert.Equal(valeurAttendu, minimumCalculer);
        }

        [Fact]
        public void RechercherMinimumParTrieRapide_elementInitial_minimumAttendue()
        {
            //Arranger
            List<decimal> elementInitial = new List<decimal>() { 2.4m, 0m, 17m, 4.7m, -8.9m, -17.4m, 20m };
            decimal minimumAttendue = -17.4m;
            //Agir
            decimal minimum = Fonctions.RechercherMinimumParTrieRapide(elementInitial);
            //Auditer
            Assert.Equal(minimum,minimumAttendue );
        }

        [Fact]
        public void CopierList_CasNull_Exception()
        {
            // Arranger
            List<int> listEntiers = null;
            // Agir && Auditer
            Assert.Throws<ArgumentException>(
            () =>
            {
                List<int> copieElement = Fonctions.CopierList(listEntiers);
            });
        }
        [Fact]
        public void CopierList_CasVide_Exception()
        {
            // Arranger
            List<int> listEntiers = new List<int>();
            // Agir && Auditer
            Assert.Throws<ArgumentException>(
            () => {
                List<int> copieElement = Fonctions.CopierList(listEntiers);
            });
        }

        [Fact]
        public void CopierList_elementInitial_elementCopie()
        {
            //Arranger
            List<int> elementInitial = new List<int>() { -17, 20, 2, 4, -8, 0, 17 };
            //Agir
            List<int> elementCopie = Fonctions.CopierList(elementInitial);
            //Auditer
            Assert.Equal(elementInitial, elementCopie);
        }
        [Fact]
        public void CopierList_elementInitial_DifferentReference()
        {
            //Arranger
            List<double> elementInitial = new List<double>() { -17, 20, 2, 4, -8, 0, 17 };
            //Agir
            List<double> elementCopie = Fonctions.CopierList(elementInitial);
            //Auditer
            Assert.NotSame(elementInitial, elementCopie);
        }




    }
}

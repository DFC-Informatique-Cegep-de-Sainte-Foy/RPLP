﻿using System;

namespace ALG_AVANCE_Module_02_Complexite
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ALG_AVANCE_Module_02_Complexite
{
    public class Fonctions
    {
        /*
        * Exercice 1 - Recherche
        1. Calculer la complexité de la recherche d'une valeur dans une liste  :   O(n)
        2. Essayer de recalculer la complexité de la recherche dichotomique    : O(log2(n))


            */
        public static bool RechercheSimple<TypeElement>(List<TypeElement> p_collection, TypeElement p_valeurAChercher)
        {
            if (p_collection == null || p_collection.Count == 0)
            {
                throw new ArgumentException("La liste ne doit pas être nul ou vide", "p_collection");
            }
            bool estTrouvee = false;
            int indiceValerCourante = 0;
            while (!estTrouvee && indiceValerCourante < p_collection.Count)          // les pires des cas on va parcourir toute les elements 
            {                                                                        //dans la liste   O(n)
                if (p_collection[indiceValerCourante].Equals(p_valeurAChercher))
                {
                    estTrouvee = true;

                }
                indiceValerCourante++;
            }

            return estTrouvee;
        }

        public static bool RechercherValeurDichotomie<TypeElement>(List<TypeElement> p_valeurs, TypeElement p_valeurAChercher)
        where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException(nameof(p_valeurs));
            }

            bool estTrouvee = false;
            int indicePremier = 0;
            int indiceDernier = p_valeurs.Count - 1;
            int indiceMilieu = 0;

            while (!estTrouvee && indicePremier <= indiceDernier)               // 1  tour   n donne 
            {                                                                   // 2 tour  n/2 donne
                indiceMilieu = (indicePremier + indiceDernier) / 2;             // 3 tour  n/4 donne 
                if (p_valeurs[indiceMilieu].Equals(p_valeurAChercher))          // log2(n)   O(log2(n))
                {
                    estTrouvee = true;
                }
                else if (p_valeurs[indiceMilieu].CompareTo(p_valeurAChercher) < 0)
                {
                    indicePremier = indiceMilieu + 1;
                }
                else
                {
                    indiceDernier = indiceMilieu - 1;
                }
            }

            return estTrouvee;
        }
        /*
        * Exercice 2 - Tris
        * 1. Calculez la complexité du tri à bulles O(n2)  
        */
        public static List<TypeElement> TriBulles<TypeElement>(List<TypeElement> p_valeurs)
        where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null || p_valeurs.Count == 0)
            {
                throw new ArgumentException(nameof(p_valeurs));
            }
            TypeElement ancienneValeur = default(TypeElement);
            bool permutationAuDernierTour = true;
            int indiceMax = p_valeurs.Count - 1;
            List<TypeElement> valeursCopiees = CopierList<TypeElement>(p_valeurs);

            while (permutationAuDernierTour)                                                  //2 boucle imbrique 
            {                                                                                 // 1 boucle execute n fois
                permutationAuDernierTour = false;                                             // 2 boucle exucuter n fois
                for (int indiceCourant = 0; indiceCourant < indiceMax; indiceCourant++)       //  O(n2) 
                {
                    if (valeursCopiees[indiceCourant + 1].CompareTo(valeursCopiees[indiceCourant]) < 0)
                    {
                        ancienneValeur = valeursCopiees[indiceCourant + 1];
                        valeursCopiees[indiceCourant + 1] = valeursCopiees[indiceCourant];
                        valeursCopiees[indiceCourant] = ancienneValeur;
                        permutationAuDernierTour = true;
                    }
                }
                indiceMax = indiceMax - 1;
            }
            return valeursCopiees;
        }
        public static List<TypeElement> CopierList<TypeElement>(List<TypeElement> p_list)
        {
            if (p_list == null || p_list.Count == 0)
            {
                throw new ArgumentException(nameof(p_list));
            }
            return p_list.Select(element => element).ToList();
        }
        /*
        * 2. Calculez la complexité du tri rapide dans le meilleur des cas : division en deux du tableau à chaque itération
        */
        public static List<TypeElement> TriRapide<TypeElement>(List<TypeElement> p_valeurs)
        where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null || p_valeurs.Count == 0)
            {
                throw new ArgumentException(nameof(p_valeurs));
            }
            List<TypeElement> valeursCopiees = CopierList(p_valeurs);
            TriRapide_rec<TypeElement>(valeursCopiees, 0, valeursCopiees.Count - 1);
            return valeursCopiees;
        }
        public static void TriRapide_rec<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier)
        where TypeElement : IComparable<TypeElement>
        {
            int indicePivot = 0;
            if (p_indicePremier < p_indiceDernier)
            {
                indicePivot = ChoixPivot(p_valeurs, p_indicePremier, p_indiceDernier);  
                indicePivot = Partitionner(p_valeurs, p_indicePremier, p_indiceDernier, indicePivot);
                TriRapide_rec(p_valeurs, p_indicePremier, indicePivot - 1);
                TriRapide_rec(p_valeurs, indicePivot + 1, p_indiceDernier);
            }

        }
        public static int ChoixPivot<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier)
        {
            return p_indicePremier;
        }

        public static int Partitionner<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier, int p_indicePivot)
        where TypeElement : IComparable<TypeElement>
        {
            TypeElement ancienneValeur = default(TypeElement);
            int futurIndicePivot = p_indicePremier;

            ancienneValeur = p_valeurs[p_indicePivot];
            p_valeurs[p_indicePivot] = p_valeurs[p_indiceDernier];
            p_valeurs[p_indiceDernier] = ancienneValeur;
            for (int indiceValeurARanger = p_indicePremier; indiceValeurARanger < p_indiceDernier; indiceValeurARanger++) //1tour n donee
            {
                if (p_valeurs[indiceValeurARanger].CompareTo(p_valeurs[p_indiceDernier]) <= 0)                           //  
                {                                                                                
                    ancienneValeur = p_valeurs[futurIndicePivot];
                    p_valeurs[futurIndicePivot] = p_valeurs[indiceValeurARanger];
                    p_valeurs[indiceValeurARanger] = ancienneValeur;
                    futurIndicePivot = futurIndicePivot + 1;
                }
            }
            ancienneValeur = p_valeurs[futurIndicePivot];
            p_valeurs[futurIndicePivot] = p_valeurs[p_indiceDernier];
            p_valeurs[p_indiceDernier] = ancienneValeur;
            return futurIndicePivot;
        }

        /*
            *3.  Calculez la complexité du tri rapide dans le pire : tableau trié en ordre croissant ou décroissant et 
            * donc partitionnement qui ne partitionne pas vraiment:
            * on divise les element du liste a chaque tour de boucle  t(n)*log2(n)  =  O(nlog2(n))
            */




        /*
            * Exercice 3 - Recherche du minimum
            * 1. Écrivez une fonction qui renvoie la valeur minimale d'une liste générique en utilisant 
            *    CompareTo : utilisez l'algorithme classique qui parcours un fois la liste
            */
        public static TypeElement RechercherMinimum<TypeElement>(List<TypeElement> p_elements)
        where TypeElement:IComparable<TypeElement>
        {
            if (p_elements.Count==0 )
            {
                throw new ArgumentException(nameof(p_elements));
            }
            if (p_elements == null)
            {
                throw new ArgumentNullException(nameof(p_elements));
            }
            TypeElement valeurMinimum =p_elements[0];
            foreach (TypeElement element in p_elements)
            {
                if (element.CompareTo(valeurMinimum)<0)
                {
                    valeurMinimum = element;
                }
            }
            return valeurMinimum;
        }
        /*2. Écrivez une fonction qui renvoie la valeur minimale d'une liste générique en utilisant CompareTo : pour cette version, 
         * débutez par un tri de la liste. (le minimum est donc le ???ième élément)
         */
        public static TypeElement RechercherMinimumParTrieRapide<TypeElement>(List<TypeElement> p_elements)
        where TypeElement:IComparable<TypeElement>
        {
            if (p_elements.Count == 0)
            {
                throw new ArgumentException(nameof(p_elements));
            }
            if (p_elements == null)
            {
                throw new ArgumentNullException(nameof(p_elements));
            }
            List<TypeElement> p_elementsTriee = TriRapide(p_elements);
            TypeElement valeurMinimum = p_elementsTriee[0];
            return valeurMinimum;
        }

        /*
         *3.  Calculez la complexité des algorithmes avec ou dans tri. Lequel est le plus efficace ? 
         * Dans la fonction RechercherMinimum dans les pire des on va faire une tour de boucle donc la complexité t(n)=constant + t(n) =O(n)
         * par contre dans la fonction trie rapide la compléxite dans le meilleur cas  O(nlog2(n)) et dans le pire des cas compléxite O(n^2)
         * le plus efficace  l'algorithme cest  fonction RechercherMinimum .
         */


    }
}

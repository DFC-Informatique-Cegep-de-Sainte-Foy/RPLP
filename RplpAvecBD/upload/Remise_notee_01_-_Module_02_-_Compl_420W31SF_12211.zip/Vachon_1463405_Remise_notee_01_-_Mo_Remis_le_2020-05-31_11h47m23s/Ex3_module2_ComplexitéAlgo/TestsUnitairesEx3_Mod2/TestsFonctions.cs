using System;
using Xunit;
using System.Collections.Generic;
using Ex3_module2_Complexit�Algo;

namespace TestsUnitairesEx3_Mod2
{
    public class TestsFonctions
    {
        // Recherche SANS TRI
        [Fact]
        public void RechercherPlusPetitElement_listeEntiersPositifs_Succes()
        {
            // Arranger
            List<int> listeTest = new List<int>() { 4, 2, 6, 2, 7, 1, 5, 7 };
            int attendu = 1;

            // Agir
            int obtenu = Fonctions.RecherchePlusPetitElement(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElement_listeEntiersNegatifs_Succes()
        {
            // Arranger
            List<int> listeTest = new List<int>() { -4, -2, -6, -2, -7, -1, -5, -7 };
            int attendu = -7;

            // Agir
            int obtenu = Fonctions.RecherchePlusPetitElement(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElement_listeEntiersMelanges_Succes()
        {
            // Arranger
            List<int> listeTest = new List<int>() { -4, 2, 6, 2, -7, 1, 5, 7 };
            int attendu = -7;

            // Agir
            int obtenu = Fonctions.RecherchePlusPetitElement(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElement_listeDoublesPositifs_Succes()
        {
            // Arranger
            List<double> listeTest = new List<double>() { 4.1, 2.5, 6.0, 2.1, 7.2, 1.2, 5.5, 7.0 };
            double attendu = 1.2;

            // Agir
            double obtenu = Fonctions.RecherchePlusPetitElement(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElement_listeDoublesNegatifs_Succes()
        {
            // Arranger
            List<double> listeTest = new List<double>() { -4.1, -2.5, -6.0, -2.1, -8.2, -1.2, -5.5, -7.0 };
            double attendu = -8.2;

            // Agir
            double obtenu = Fonctions.RecherchePlusPetitElement(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }


        [Fact]
        public void RechercherPlusPetitElement_listeDoublesMelanges_Succes()
        {
            // Arranger
            List<double> listeTest = new List<double>() { -4.1, 2.5, 6.0, 2.1, -7.2, 1.2, 5.5, 7.0 };
            double attendu = -7.2;

            // Agir
            double obtenu = Fonctions.RecherchePlusPetitElement(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElement_listeDeStrings_Succes()
        {
            // Arranger
            List<string> listeTest = new List<string>() { "chat", "chien", "autruche", "colombe", "boeuf", "antilope", "z�bre" };
            string attendu = "antilope";

            // Agir
            string obtenu = Fonctions.RecherchePlusPetitElement(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElement_listeNulle_ArgumentNullException()
        {
            // Arranger
            List<int> listeNulle = null;

            // Agir et Auditer
            Assert.Throws<ArgumentNullException>(() => Fonctions.RecherchePlusPetitElement(listeNulle));
        }

        [Fact]
        public void RechercherPlusPetitElement_listeVide_ArgumentException()
        {
            // Arranger
            List<int> listeVide = new List<int>();

            // Agir et Auditer
            Assert.Throws<ArgumentException>(() => Fonctions.RecherchePlusPetitElement(listeVide));
        }

        // Recherche AVEC TRI
        [Fact]
        public void RechercherPlusPetitElementViaTri_listeEntiersPositifs_Succes()
        {
            // Arranger
            List<int> listeTest = new List<int>() { 4, 2, 6, 2, 7, 1, 5, 7 };
            int attendu = 1;

            // Agir
            int obtenu = Fonctions.RecherchePlusPetitViaTri(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElementViaTri_listeEntiersNegatifs_Succes()
        {
            // Arranger
            List<int> listeTest = new List<int>() { -4, -2, -6, -2, -17, -1, -5, -7 };
            int attendu = -17;

            // Agir
            int obtenu = Fonctions.RecherchePlusPetitViaTri(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElementViaTri_listeEntiersMelanges_Succes()
        {
            // Arranger
            List<int> listeTest = new List<int>() { -4, 2, 6, 2, -7, 1, 5, 7 };
            int attendu = -7;

            // Agir
            int obtenu = Fonctions.RecherchePlusPetitViaTri(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElementViaTri_listeDoublesPositifs_Succes()
        {
            // Arranger
            List<double> listeTest = new List<double>() { 4.1, 2.5, 6.0, 2.1, 7.2, 1.2, 5.5, 7.0 };
            double attendu = 1.2;

            // Agir
            double obtenu = Fonctions.RecherchePlusPetitViaTri(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElementViaTri_listeDoublesNegatifs_Succes()
        {
            // Arranger
            List<double> listeTest = new List<double>() { -4.1, -2.5, -6.0, -2.1, -8.2, -1.2, -5.5, -7.0 };
            double attendu = -8.2;

            // Agir
            double obtenu = Fonctions.RecherchePlusPetitViaTri(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }


        [Fact]
        public void RechercherPlusPetitElementViaTri_listeDoublesMelanges_Succes()
        {
            // Arranger
            List<double> listeTest = new List<double>() { -4.1, 2.5, 6.0, 2.1, -7.2, 1.2, 5.5, 7.0 };
            double attendu = -7.2;

            // Agir
            double obtenu = Fonctions.RecherchePlusPetitViaTri(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElementViaTri_listeDeStrings_Succes()
        {
            // Arranger
            List<string> listeTest = new List<string>() { "chat", "chien", "autruche", "colombe", "boeuf", "antilope", "z�bre" };
            string attendu = "antilope";

            // Agir
            string obtenu = Fonctions.RecherchePlusPetitViaTri(listeTest);

            // Auditer
            Assert.Equal(attendu, obtenu);
        }

        [Fact]
        public void RechercherPlusPetitElementViaTri_listeNulle_ArgumentNullException()
        {
            // Arranger
            List<int> listeNulle = null;

            // Agir et Auditer
            Assert.Throws<ArgumentNullException>(() => Fonctions.RecherchePlusPetitElement(listeNulle));
        }

        [Fact]
        public void RechercherPlusPetitElementViaTri_listeVide_ArgumentException()
        {
            // Arranger
            List<int> listeVide = new List<int>();

            // Agir et Auditer
            Assert.Throws<ArgumentException>(() => Fonctions.RecherchePlusPetitViaTri(listeVide));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ex3_module2_ComplexitéAlgo
{
    public class Fonctions
    {
        // ---- Recherche du minimum ---- COMPLEXITÉ: O(n)
        public static TypeElement RecherchePlusPetitElement<TypeElement>(List<TypeElement> p_listeAVerifier)
            where TypeElement : IComparable<TypeElement>
        {
            if(p_listeAVerifier == null)
            {
                throw new ArgumentNullException("p_listeAVerifier", "La liste n'existe pas.");
            }
            else if(p_listeAVerifier.Count == 0)
            {
                throw new ArgumentException("p_listeAVerifier", "La liste ne contient aucun element.");
            }

            TypeElement plusPetitElement = p_listeAVerifier[0];

            p_listeAVerifier.ForEach(element =>
            {
                if (element.CompareTo(plusPetitElement) < 0)
                {
                    plusPetitElement = element;
                }
            });

            return plusPetitElement;
        }

        // ---- Recherche minimum via un tri ---- COMPLEXITÉ: O(n log(n)) meilleur cas ou O(n^2) pire cas
        public static TypeElement RecherchePlusPetitViaTri<TypeElement>(List<TypeElement> p_listeAVerifier)
            where TypeElement : IComparable<TypeElement>
        {
            if (p_listeAVerifier == null)
            {
                throw new ArgumentNullException("p_listeAVerifier", "La liste n'existe pas");
            }
            else if(p_listeAVerifier.Count == 0)
            {
                throw new ArgumentException("p_listeAVerifier", "La liste est vide, impossible de la trier");
            }
            List<TypeElement> p_listeTriee = TriRapide(p_listeAVerifier);
            TypeElement plusPetitElement = p_listeTriee[0];

            return plusPetitElement;
        }


        //
        // La recherche du minimum sans tri est la plus efficace. O(n) est beaucoup plus simple que O(n log(n)) ou encore O(n^2)
        //


        // methodes pour tri rapide et utilitaires ( testées au préalable dans mon autre projet )
        private static void TriRapide_rec<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier) where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException("p_valeurs", "La liste n'existe pas");
            }
            else if (p_valeurs.Count == 0)
            {
                throw new ArgumentException("p_valeurs", "La liste est vide, impossible de la trier");
            }
            int indicePivot = 0;
            if (p_indicePremier.CompareTo(p_indiceDernier) < 0)
            {
                indicePivot = ChoixPivot(p_valeurs, p_indicePremier, p_indiceDernier);
                indicePivot = Partitionner(p_valeurs, p_indicePremier, p_indiceDernier, indicePivot);
                TriRapide_rec(p_valeurs, p_indicePremier, p_indiceDernier - 1);
                TriRapide_rec(p_valeurs, indicePivot + 1, p_indiceDernier);
            }
        }
        private static int Partitionner<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier, int p_indicePivot) where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException("p_valeurs", "La liste n'existe pas");
            }
            else if (p_valeurs.Count == 0)
            {
                throw new ArgumentException("p_valeurs", "La liste est vide, impossible de la trier");
            }
            TypeElement ancienneValeur;
            int futurIndicePivot = p_indicePremier;
            ancienneValeur = p_valeurs[p_indicePivot];
            p_valeurs[p_indicePivot] = p_valeurs[p_indiceDernier];
            p_valeurs[p_indiceDernier] = ancienneValeur;

            for (int indiceValeurARanger = p_indicePremier; indiceValeurARanger < p_indiceDernier - 1; indiceValeurARanger++)
            {
                if (p_valeurs[indiceValeurARanger].CompareTo(p_valeurs[p_indiceDernier]) < 0)
                {
                    ancienneValeur = p_valeurs[futurIndicePivot];
                    p_valeurs[futurIndicePivot] = p_valeurs[indiceValeurARanger];
                    p_valeurs[indiceValeurARanger] = ancienneValeur;
                    ++futurIndicePivot;
                }
            }

            ancienneValeur = p_valeurs[futurIndicePivot];
            p_valeurs[futurIndicePivot] = p_valeurs[p_indiceDernier];
            p_valeurs[p_indiceDernier] = ancienneValeur;

            return futurIndicePivot;
        }
        private static List<TypeElement> TriRapide<TypeElement>(List<TypeElement> p_valeurs) where TypeElement : IComparable<TypeElement> // COMPLEXITÉ : O(2n) // meilleur cas O(n * logbase2(n)) // Pire Cas  O(n^2)
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException("p_valeurs", "La liste n'existe pas");
            }
            else if (p_valeurs.Count == 0)
            {
                throw new ArgumentException("p_valeurs", "La liste est vide, impossible de la trier");
            }
            List<TypeElement> listeCopiees = CopierListe(p_valeurs);
            TriRapide_rec(listeCopiees, 0, listeCopiees.Count - 1);

            return listeCopiees;
        }

        private static List<TypeElement> CopierListe<TypeElement>(List<TypeElement> p_listeACopier)
        {
            if (p_listeACopier == null)
            {
                throw new ArgumentNullException("p_listeACopier", "La liste n'existe pas");
            }
            else if (p_listeACopier.Count == 0)
            {
                throw new ArgumentException("p_listeACopier", "La liste est vide, impossible de la trier");
            }
            List<TypeElement> listeCopiee = new List<TypeElement>();
            foreach (TypeElement ElementActuel in p_listeACopier)
            {
                listeCopiee.Add(ElementActuel);
            }

            return listeCopiee;
        }

        private static int ChoixPivot<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier) where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException("p_valeurs", "La liste n'existe pas");
            }
            else if (p_valeurs.Count == 0)
            {
                throw new ArgumentException("p_valeurs", "La liste est vide, elle n'a pas indice(s)");
            }
            return p_indicePremier;
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace Ex3_module2_ComplexitéAlgo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Liste de base pour tester
            List<int> maListeDeInts = new List<int>() { -3, 2, 6, 7, 1, -3, 15, -4, 12, -7 };

            // Recherche plus petit Element sans tri
            int intPlusPetit = Fonctions.RecherchePlusPetitElement(maListeDeInts);
            Console.WriteLine(intPlusPetit);

            // Recherche plus petit element via tri
            int intPlusPetitTri = Fonctions.RecherchePlusPetitViaTri(maListeDeInts);
            Console.WriteLine(intPlusPetitTri);
        }
    }
}

using AA_Module2_Complexite_Exercice3;
using System;
using System.Collections.Generic;
using Xunit;

namespace Test_AA_Module2_Complexite_Exercice3
{
    public class Test_RechercheMinimum
    {
        [Fact]
        public void RechercherValeurMinimum_ListeMotsVide_Exeption()
        {
            // Arranger
            List<String> listeMot = null;

            //Agir & Auditer
            Assert.Throws<ArgumentNullException>(() => { string valeurAttendu = RechercheMinimum.RechercherValeurMinimum(listeMot); });
        }

        [Fact]
        public void RechercherValeurMinimum_ListeMotsPremiereValeur_ListeAttendu()
        {
            // Arranger
            List<String> listeMot = new List<String>() { "banane", "orange", "patate", "pomme", "carotte" };
            string valeurRechercher = null;
            string valeurAttendu = "banane";

            //Agir 
            valeurRechercher = RechercheMinimum.RechercherValeurMinimum(listeMot);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void RechercherValeurMinimum_ListeMotsSecondeValeur_ListeAttendu()
        {
            // Arranger
            List<String> listeMot = new List<String>() { "orange", "banane", "patate", "pomme", "carotte" };
            string valeurRechercher = null;
            string valeurAttendu = "banane";

            //Agir 
            valeurRechercher = RechercheMinimum.RechercherValeurMinimum(listeMot);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void RechercherValeurMinimum_ListeMotsDerniereValeur_ListeAttendu()
        {
            // Arranger
            List<String> listeMot = new List<String>() { "orange", "carotte", "patate", "pomme", "banane" };
            string valeurRechercher = null;
            string valeurAttendu = "banane";

            //Agir 
            valeurRechercher = RechercheMinimum.RechercherValeurMinimum(listeMot);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void RechercherValeurMinimum_ListeMotsAvecDoublons_ListeAttendu()
        {
            // Arranger
            List<String> listeMot = new List<String>() { "patate", "orange", "banane", "banane", "carotte" };
            string valeurRechercher = null;
            string valeurAttendu = "banane";

            //Agir 
            valeurRechercher = RechercheMinimum.RechercherValeurMinimum(listeMot);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void RechercherValeurMinimum_ListeNombreEntierPremiereValeur_ListeAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { 1, 8, 25, 6, 15 };
            int valeurRechercher = 0;
            int valeurAttendu = 1;

            //Agir 
            valeurRechercher = RechercheMinimum.RechercherValeurMinimum(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void RechercherValeurMinimum_ListeNombreEntierDeuxiemeValeur_ListeAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { 8, 1, 25, 6, 15 };
            int valeurRechercher = 0;
            int valeurAttendu = 1;

            //Agir 
            valeurRechercher = RechercheMinimum.RechercherValeurMinimum(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void RechercherValeurMinimum_ListeNombreEntierDeriereValeur_ListeAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { 15, 8, 25, 6, 1 };
            int valeurRechercher = 0;
            int valeurAttendu = 1;

            //Agir 
            valeurRechercher = RechercheMinimum.RechercherValeurMinimum(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void RechercherValeurMinimum_ListeNombreN�gatif_ListeAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { -5, -8, -18, -6, -15 };
            int valeurRechercher = 0;
            int valeurAttendu = -18;

            //Agir 
            valeurRechercher = RechercheMinimum.RechercherValeurMinimum(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void RechercherValeurMinimum_ListeMeleanger_ListeAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { -5, 8, -1, 6, -15, 18 };
            int valeurRechercher = 0;
            int valeurAttendu = -15;

            //Agir 
            valeurRechercher = RechercheMinimum.RechercherValeurMinimum(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void RechercherValeurMinimum_ListeAvecDoublons_ListeAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { -5, 8, -1, -15, -15, 18 };
            int valeurRechercher = 0;
            int valeurAttendu = -15;

            //Agir 
            valeurRechercher = RechercheMinimum.RechercherValeurMinimum(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeMotsVide_Exeption()
        {
            // Arranger
            List<String> listeMot = null;

            //Agir & Auditer
            Assert.Throws<ArgumentNullException>(() => { string valeurAttendu = RechercheMinimum.TrierEtRetournePremiereValeur(listeMot); });
        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeMotsPremiereValeur_ValeurAttendu()
        {
            // Arranger
            List<String> listeMot = new List<String>() { "banane", "orange", "patate", "pomme", "carotte" };
            string valeurRechercher = null;
            string valeurAttendu = "banane";

            //Agir 
            valeurRechercher = RechercheMinimum.TrierEtRetournePremiereValeur(listeMot);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeMotsDeuxiemeValeur_ValeurAttendu()
        {
            // Arranger
            List<String> listeMot = new List<String>() { "orange", "banane", "patate", "pomme", "carotte" };
            string valeurRechercher = null;
            string valeurAttendu = "banane";

            //Agir 
            valeurRechercher = RechercheMinimum.TrierEtRetournePremiereValeur(listeMot);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeMotsDerniereValeur_ValeurAttendu()
        {
            // Arranger
            List<String> listeMot = new List<String>() { "orange", "carotte", "patate", "pomme", "banane" };
            string valeurRechercher = null;
            string valeurAttendu = "banane";

            //Agir 
            valeurRechercher = RechercheMinimum.TrierEtRetournePremiereValeur(listeMot);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeMotsAvecDoublons_ValeurAttendu()
        {
            // Arranger
            List<String> listeMot = new List<String>() { "patate", "orange", "banane", "banane", "carotte" };
            string valeurRechercher = null;
            string valeurAttendu = "banane";

            //Agir 
            valeurRechercher = RechercheMinimum.TrierEtRetournePremiereValeur(listeMot);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeNombreEntierPremiereValeur_ValeurAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { 1, 8, 25, 6, 15 };
            int valeurRechercher = 0;
            int valeurAttendu = 1;

            //Agir 
            valeurRechercher = RechercheMinimum.TrierEtRetournePremiereValeur(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeNombreEntierDeuxiemeValeur_ValeurAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { 8, 1, 25, 6, 15 };
            int valeurRechercher = 0;
            int valeurAttendu = 1;

            //Agir 
            valeurRechercher = RechercheMinimum.TrierEtRetournePremiereValeur(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeNombreEntierDerniereiereValeur_ValeurAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { 15, 8, 25, 6, 1 };
            int valeurRechercher = 0;
            int valeurAttendu = 1;

            //Agir 
            valeurRechercher = RechercheMinimum.TrierEtRetournePremiereValeur(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeNombreN�gatif_ValeurAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { -5, -8, -18, -6, -15 };
            int valeurRechercher = 0;
            int valeurAttendu = -18;

            //Agir 
            valeurRechercher = RechercheMinimum.TrierEtRetournePremiereValeur(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeNombreMeleanger_ValeurAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { -5, 8, -1, 6, -15, 18 };
            int valeurRechercher = 0;
            int valeurAttendu = -15;

            //Agir 
            valeurRechercher = RechercheMinimum.TrierEtRetournePremiereValeur(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }

        [Fact]
        public void TrierEtRetournePremiereValeurDansListeTrier_ListeNombreAvecDoublons_ValeurAttendu()
        {
            // Arranger
            List<int> listeNombre = new List<int>() { -5, 8, -1, -15, -15, 18 };
            int valeurRechercher = 0;
            int valeurAttendu = -15;

            //Agir 
            valeurRechercher = RechercheMinimum.TrierEtRetournePremiereValeur(listeNombre);

            //Auditer
            Assert.Equal(valeurAttendu, valeurRechercher);

        }
    }
}

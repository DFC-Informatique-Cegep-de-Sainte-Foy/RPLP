using AA_Module2_Complexite_Exercice3;
using System;
using System.Collections.Generic;
using Xunit;

namespace Test_AA_Module2_Complexite_Exercice3
{
    public class Test_Fonctions
    {
        [Fact]
        public void TriRapide_ListeNull_Exception()
        {
            // Arranger
            List<int> listeInitiale = null;

            //Agir & Auditer

            Assert.Throws<ArgumentNullException>(() => { List<int> TriRapide = Fonctions.TriRapide(listeInitiale); });

        }

        [Fact]
        public void TriRapide_ListeVide_ListeAttendu()
        {
            // Arranger
            List<int> listeInitiale = new List<int>() { };
            List<int> listeTrier = null;
            List<int> listeAttendu = new List<int>() { };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.Equal(listeAttendu.Count, listeTrier.Count);
            Assert.NotSame(listeAttendu, listeTrier);
        }

        [Fact]
        public void TriRapide_ListeUneValeur_ListeAttendu()
        {
            // Arranger
            List<int> listeInitiale = new List<int>() { 0 };
            List<int> listeTrier = null;
            List<int> listeAttendu = new List<int>() { 0 };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListePlusieursValeur_ListeAttendu()
        {
            // Arranger
            List<int> listeInitiale = new List<int>() { 10, 0, 15, 22, 4, 40, 18 };
            List<int> listeTrier = null;
            List<int> listeAttendu = new List<int>() { 0, 4, 10, 15, 18, 22, 40 };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListeValeurNegative_ListeAttendu()
        {
            // Arranger
            List<int> listeInitiale = new List<int>() { 10, 0, 15, -22, 4, -40, 18 };
            List<int> listeTrier = null;
            List<int> listeAttendu = new List<int>() { -40, -22, 0, 4, 10, 15, 18 };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListeValeurDoublon_ListeAttendu()
        {
            // Arranger
            List<int> listeInitiale = new List<int>() { 10, 10, 15, -22, 4, -40, 18 };
            List<int> listeTrier = null;
            List<int> listeAttendu = new List<int>() { -40, -22, 4, 10, 10, 15, 18 };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListeValeurNegativeUniquement_ListeAttendu()
        {
            // Arranger
            List<int> listeInitiale = new List<int>() { -10, -10, -15, -22, -4, -40, -18 };
            List<int> listeTrier = null;
            List<int> listeAttendu = new List<int>() { -40, -22, -18, -15, -10, -10, -4 };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListeVideDecimale_ListeAttendu()
        {
            // Arranger
            List<decimal> listeInitiale = new List<decimal>() { };
            List<decimal> listeTrier = null;
            List<decimal> listeAttendu = new List<decimal>() { };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);

        }

        [Fact]
        public void TriRapide_ListeUneValeurDecimale_ListeAttendu()
        {
            // Arranger
            List<decimal> listeInitiale = new List<decimal>() { 0 };
            List<decimal> listeTrier = null;
            List<decimal> listeAttendu = new List<decimal>() { 0 };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListePlusieursValeurDecimale_ListeAttendu()
        {
            // Arranger
            List<decimal> listeInitiale = new List<decimal>() { 10.25m, 0, 15.87m, 22.57m, 4.84m, 40.63m, 18.45m };
            List<decimal> listeTrier = null;
            List<decimal> listeAttendu = new List<decimal>() { 0, 4.84m, 10.25m, 15.87m, 18.45m, 22.57m, 40.63m };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListeValeurNegativeDecimale_ListeAttendu()
        {
            // Arranger
            List<decimal> listeInitiale = new List<decimal>() { 10.25m, 0, 15.87m, -22.57m, 4.84m, -40.63m, 18.45m };
            List<decimal> listeTrier = null;
            List<decimal> listeAttendu = new List<decimal>() { -40.63m, -22.57m, 0, 4.84m, 10.25m, 15.87m, 18.45m };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListeValeurDoublonDecimale_ListeAttendu()
        {
            // Arranger
            List<decimal> listeInitiale = new List<decimal>() { 10.25m, 10.25m, 15.87m, -22.57m, 4.84m, -40.63m, 18.45m };
            List<decimal> listeTrier = null;
            List<decimal> listeAttendu = new List<decimal>() { -40.63m, -22.57m, 4.84m, 10.25m, 10.25m, 15.87m, 18.45m };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListeValeurNegativeUniquementDecimale_ListeAttendu()
        {
            // Arranger
            List<decimal> listeInitiale = new List<decimal>() { -10.25m, -10.25m, -15.87m, -22.57m, -4.84m, -40.63m, -18.45m };
            List<decimal> listeTrier = null;
            List<decimal> listeAttendu = new List<decimal>() { -40.63m, -22.57m, -18.45m, -15.87m, -10.25m, -10.25m, -4.84m };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListeVideSting_ListeAttendu()
        {
            // Arranger
            List<String> listeInitiale = new List<String>() { };
            List<String> listeTrier = null;
            List<String> listeAttendu = new List<String>() { };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);

        }

        [Fact]
        public void TriRapide_ListeUnMot_ListeAttendu()
        {
            // Arranger
            List<String> listeInitiale = new List<String>() { "Patate" };
            List<String> listeTrier = null;
            List<String> listeAttendu = new List<String>() { "Patate" };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListePlusieursMotCommenceParMajuscule_ListeAttendu()
        {
            // Arranger
            List<String> listeInitiale = new List<String>() { "Patate", "Pomme", "Banane", "Orange", "Carotte" };
            List<String> listeTrier = null;
            List<String> listeAttendu = new List<String>() { "Banane", "Carotte", "Orange", "Patate", "Pomme" };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListeMelangerMots_ListeAttendu()
        {
            // Arranger
            List<String> listeInitiale = new List<String>() { "patate", "pomme", "banane", "orange", "carotte" };
            List<String> listeTrier = null;
            List<String> listeAttendu = new List<String>() { "banane", "carotte", "orange", "patate", "pomme" };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListePlusieurMotsMinuscule_ListeAttendu()
        {
            // Arranger
            // Arranger
            List<String> listeInitiale = new List<String>() { "patate", "pomme", "banane", "orange", "carotte" };
            List<String> listeTrier = null;
            List<String> listeAttendu = new List<String>() { "banane", "carotte", "orange", "patate", "pomme" };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }

        [Fact]
        public void TriRapide_ListeMotsAvecDoublons_ListeAttendu()
        {
            // Arranger
            List<String> listeInitiale = new List<String>() { "patate", "orange", "banane", "orange", "carotte" };
            List<String> listeTrier = null;
            List<String> listeAttendu = new List<String>() { "banane", "carotte", "orange", "orange", "patate" };

            //Agir 

            listeTrier = Fonctions.TriRapide(listeInitiale);

            //Auditer

            Assert.Equal(listeAttendu, listeTrier);
            Assert.NotSame(listeInitiale, listeTrier);
            Assert.Equal(listeInitiale.Count, listeTrier.Count);

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AA_Module2_Complexite_Exercice3
{
    public class Fonctions
    {

        public static List<TypeElement> TriRapide<TypeElement>(List<TypeElement> p_valeurs)
        where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException("Le paramètre ne peut pas être null" + "p_valeurs");
            }

            List<TypeElement> valeursCopiees = CopierListe(p_valeurs);
            TriRapide_rec(valeursCopiees, 0, valeursCopiees.Count - 1);


            return valeursCopiees;
        }

        private static void TriRapide_rec<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier)
        where TypeElement : IComparable<TypeElement>
        {
            int indicePivot = 0;

            if (p_indicePremier < p_indiceDernier)
            {
                indicePivot = ChoixPivot(p_valeurs, p_indicePremier, p_indiceDernier);
                indicePivot = Partitionner(p_valeurs, p_indicePremier, p_indiceDernier, indicePivot);
                TriRapide_rec(p_valeurs, p_indicePremier, indicePivot - 1);
                TriRapide_rec(p_valeurs, indicePivot + 1, p_indiceDernier);

            }
        }

        private static int ChoixPivot<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier)
        {
            return p_indicePremier;
        }

        private static int Partitionner<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier, int p_indicePivot)
        where TypeElement : IComparable<TypeElement>
        {
            TypeElement ancienneValeur = default(TypeElement);
            int futurIndicePivot = p_indicePremier;

            ancienneValeur = p_valeurs[p_indicePivot];
            p_valeurs[p_indicePivot] = p_valeurs[p_indiceDernier];
            p_valeurs[p_indiceDernier] = ancienneValeur;

            for (int indiceValeurARanger = p_indicePremier; indiceValeurARanger <= p_indiceDernier - 1; indiceValeurARanger++)
            {
                if (p_valeurs[indiceValeurARanger].CompareTo(p_valeurs[p_indiceDernier]) <= 0)
                {
                    ancienneValeur = p_valeurs[futurIndicePivot];
                    p_valeurs[futurIndicePivot] = p_valeurs[indiceValeurARanger];
                    p_valeurs[indiceValeurARanger] = ancienneValeur;
                    futurIndicePivot = futurIndicePivot + 1;
                }

            }

            ancienneValeur = p_valeurs[futurIndicePivot];
            p_valeurs[futurIndicePivot] = p_valeurs[p_indiceDernier];
            p_valeurs[p_indiceDernier] = ancienneValeur;


            return futurIndicePivot;
        }

        private static bool EstListeTrie<TypeElement>(List<TypeElement> p_valeurs)
        where TypeElement : IComparable<TypeElement>
        {
            bool estTrie = true;

            for (int compteurIndice = 0; compteurIndice < p_valeurs.Count - 1; compteurIndice++)
            {
                if (p_valeurs[compteurIndice].CompareTo(p_valeurs[compteurIndice + 1]) < 0)
                {
                    estTrie = true;
                }
                if (p_valeurs[compteurIndice].CompareTo(p_valeurs[compteurIndice + 1]) > 0)
                {
                    estTrie = false;
                }
            }

            return estTrie;
        }

        private static List<TypeElement> CopierListe<TypeElement>(List<TypeElement> p_listeATrier)
        {
            List<TypeElement> copieListe = new List<TypeElement>(p_listeATrier.Count);

            foreach (TypeElement element in p_listeATrier)
            {
                copieListe.Add(element);
            }

            return copieListe;

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AA_Module2_Complexite_Exercice3
{
    public class RechercheMinimum
    {
        // exercice 3.1
        public static TypeElement RechercherValeurMinimum<TypeElement>(List<TypeElement> p_liste)
        where TypeElement : IComparable<TypeElement>
        {
            if (p_liste == null)
            {
                throw new ArgumentNullException("Le paramètre ne peut pas être null", nameof(p_liste));
            }

            if (p_liste.Count <= 0)
            {
                throw new ArgumentOutOfRangeException("La liste doit contenir des éléments.", nameof(p_liste));
            }

            TypeElement valeurMinimum = p_liste[0];

            for(int compteurListe = 1; compteurListe < p_liste.Count; compteurListe++)
            {
                if(p_liste[compteurListe].CompareTo(valeurMinimum) < 0)
                {
                    valeurMinimum = p_liste[compteurListe];
                }
            }

            return valeurMinimum;
        }


        // exercice 3.2
        public static TypeElement TrierEtRetournePremiereValeur<TypeElement>(List<TypeElement> p_liste)
        where TypeElement : IComparable<TypeElement>
        {
            if (p_liste == null)
            {
                throw new ArgumentNullException("Le paramètre ne peut pas être null", nameof(p_liste));
            }

            if (p_liste.Count <= 0)
            {
                throw new ArgumentOutOfRangeException("La liste doit contenir des éléments.", nameof(p_liste));
            }

            List<TypeElement> listeTrier = new List<TypeElement>();

            listeTrier = Fonctions.TriRapide(p_liste);

            TypeElement valeurMinimum = listeTrier[0];

            return valeurMinimum;
        }

        // exercice 3.3
        /*
            Question: Calculez la complexité des algorithmes avec ou dans tri. Lequel est le plus efficace ?
            
            Réponse:
            Pour l'algorithme sans tri (RechercherValeurMinimum), nous utilisons une boucle "for" qui a un temps linéaire et
            à l'intérieur de cette boucle, nous y retrouvons une seul intrusion qui a un temps constant. Le résultat de la complexité
            est donc un temps linéaire, soit O(n). 

            Pour l'algorithme avec tri (TrierEtRetournePremiereValeur), nous avons dans le pire des cas un algorithme déjà trié (en ordre
            croissant ou décroissant) pour lequel le temps est quadratique, soit O(n^2) car nous passons deux fois chaque valeur.
            Dans le meileur des cas l'algoritme n'est pas trier et nous avons donc un temps logarithmique, soit O(nlog2(n)) car a chaque passage, 
            nous divisons la liste en deux sections. 

            En comparant les résultats des deux algorithmes, on voit qu'avec peut de donnée le temps est presque similaire mais dès que 
            le nombre de donnée augmenter, on voit que le temps de l'algorithme avec tri (TrierEtRetournePremiereValeur) augmenter rapidement. 
            Donc, l'algorithmes le plus efficace est celui sans tri, soit <RechercherValeurMinimum>.
            
            Voir dernière diapo du cours Module02_Complexite, fourni par Pierre-François Léon. 
            https://github.com/PiFou86/420-W31-SF/blob/master/Module02_Complexite/Module02_Complexite.pdf

        */
    }
}

﻿using System;
using System.Collections.Generic;

namespace AA_Module2_Complexite_Exercice3
{
    public class Program
    {
        public static void Main(string[] args)
        {
            List<int> listeNombreEntier = new List<int>() {25, 4, 8, 1, 7, 12 };
            int valeurMinimum = 0;

            valeurMinimum = RechercheMinimum.RechercherValeurMinimum(listeNombreEntier);

            valeurMinimum = RechercheMinimum.TrierEtRetournePremiereValeur(listeNombreEntier);

            Console.Out.WriteLine(valeurMinimum.ToString());

        }
    }
}

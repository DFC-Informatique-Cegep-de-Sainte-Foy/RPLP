using System;
using System.Collections.Generic;
using System.Linq;
using Xunit;
using minimum;

namespace TestUnitaireMinimum
{
    public class TestUnitaireTrisABull
    {
        [Fact]
        public void TrisABull_VerificationListeVide_Erreur()
        {
           //arranger
           //agir
           //auditer
            Assert.Equal(new List<int>(), TrisABull.TrisAbull(new List<int>()));
            
        }
        [Fact]
        public void TrisABull_VerificationListeSiElleEstPArailler_Erreur()
        {
            //arranger
            char[] patate = "bagcSdfWe23658".ToArray();
            //agir
            //auditer
            Assert.NotSame(patate, TrisABull.TrisAbull(patate));

        }
        [Fact]
        public void TrisABull_VerificationListeAvec1EllementetRevientTrier_Erreur()
        {
            //arranger
            //agir
            //auditer
            Assert.Equal(new List<int>() { 1 }, TrisABull.TrisAbull(new List<int>() { 1 }));

        }
        [Fact]
        public void TrisABull_VerificationListeAvec2EllementTrier_Ok()
        {
            //arranger
            //agir
            //auditer
            Assert.Equal(new List<int>() { 1, 2 }, TrisABull.TrisAbull(new List<int>() { 1, 2 }));

        }
        [Fact]
        public void TrisABull_VerificationListeAvec2EllementNonTrier_Ok()
        {
            //arranger
            //agir
            //auditer
            Assert.Equal(new List<int>() { 1, 2 }, TrisABull.TrisAbull(new List<int>() { 2, 1 }));
           
        } 
        [Fact]
        public void TrisABull_VerificationListeAvec3EllementNonTrierEnlevers_Ok()
        {
            //arranger
            //agir
            //auditer
            Assert.Equal(new List<int>() { 1, 2, 3 }, TrisABull.TrisAbull(new List<int>() { 3, 2, 1 }));

        } 
        [Fact]
        public void TrisABull_VerificationListeAvec3EllementNonTrierMelanger_Ok()
        {
            //arranger
            //agir
            //auditer
            Assert.Equal(new List<int>() { 1, 2, 3 }, TrisABull.TrisAbull(new List<int>() { 2, 3, 1 }));

        } 
        [Fact]
        public void TrisABull_VerificationListeAvecLettreTrierMelanger_Ok()
        {
            //arranger
            //agir
            //auditer
            Assert.Equal("abcdefg".ToArray(), TrisABull.TrisAbull("bagcdfe".ToArray()));

        }
        [Fact]
        public void TrisABull_VerificationListeAvecLettreEtChiffreTrierMelanger_Ok()
        {
            //arranger
            //agir
            //auditer
            Assert.Equal("23568abcdefg".ToArray(), TrisABull.TrisAbull("bagcdfe23658".ToArray()));

        }
        [Fact]
        public void TrisABull_VerificationListeAvecLettreEtChiffreEtMajusculleTrierMelanger_Ok()
        {
            //arranger
            //agir
            //auditer
            Assert.Equal("23568SWabcdefg".ToArray(), TrisABull.TrisAbull("bagcSdfWe23658".ToArray()));


        }
        [Fact]
        public void TrisABull_VerificationListeAvec3EllementTrier_Ok()
        {
            //arranger
            //agir
            //auditer
            Assert.Equal(new List<int>() { 1, 2, 3 }, TrisABull.TrisAbull(new List<int>() { 1, 2, 3 }));           
                            
            
        }

    }
}




﻿using System;
using System.Collections.Generic;
using System.Text;

namespace minimum
{
    class Fonction
    {
        public static int TrouverMinimume(List<int> p_nombreListInt)
        {
            int nombreMinimum = p_nombreListInt[0];
            for (int compteurListe = 1; compteurListe < p_nombreListInt.Count; compteurListe++)
            {
                if (p_nombreListInt[compteurListe].CompareTo(nombreMinimum) < 0)
                {
                    nombreMinimum = p_nombreListInt[compteurListe];
                }
            }

            return nombreMinimum;
        }
    }
}


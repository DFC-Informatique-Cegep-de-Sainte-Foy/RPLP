﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;

namespace minimum
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> nombreListInt = new List<int>() { 5, 6, 7, 3, 4, 6, 10, 1 };
            AffichageMinimumcs.AfficherMinimue(nombreListInt);
            AffichageMinimumcs.AfficherAvecTrisABullMinimue(nombreListInt);
        }

    

    

        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace minimum
{
    class AffichageMinimumcs
    {
        public static void AfficherMinimue(List<int> p_nombreListInt)
        {
            int nombreMinimum = Fonction.TrouverMinimume(p_nombreListInt);
            Console.WriteLine(nombreMinimum);
        }
        public static void AfficherAvecTrisABullMinimue(List<int> p_nombreListInt)
        {
            int nombreMinimum = TrisABull.TrisAbull(p_nombreListInt)[0];
            Console.WriteLine(nombreMinimum);
        }
    }
}

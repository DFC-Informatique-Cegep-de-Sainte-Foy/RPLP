﻿using System;
using System.Collections.Generic;
using System.Text;

namespace minimum
{
    public class TrisABull
    {
        public static IList<TypeElement> TrisAbull<TypeElement>(IList<TypeElement> p_listeInt)
    where TypeElement : IComparable<TypeElement>
        {
            TypeElement[] listeInt = new TypeElement[p_listeInt.Count];
            p_listeInt.CopyTo(listeInt, 0);
            TypeElement temporaire = default(TypeElement);
            int courente = 0;
            bool echange = false;


            do
            {
                echange = false;
                courente = 0;

                while (courente + 1 < listeInt.Length)
                {
                    if (listeInt[courente].CompareTo(listeInt[courente + 1]) > 0)
                    {
                        temporaire = listeInt[courente];
                        listeInt[courente] = listeInt[courente + 1];
                        listeInt[courente + 1] = temporaire;
                        echange = true;

                    }
                    courente++;

                }
            }

            while (echange == true);
            /// S'il y a un changement dans la liste la valeur
            /// va être vrai donc il va recommencer la liste encore une fois
            /// jusqu'a tent que la liste soit mis en ordre
            /// donc faire un max et de le diminuer avec le courent 
            return listeInt;
        }
    }
}

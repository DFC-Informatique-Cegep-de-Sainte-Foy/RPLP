﻿using System;
using System.Collections.Generic;

namespace Exercice2Algo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }

        public TypeElement ValeurMinimumListe<TypeElement>(List<TypeElement> p_liste)
            where TypeElement : IComparable<TypeElement>
        {
            TypeElement minimum = default(TypeElement);
            minimum = p_liste[0];

            for (int indiceListe = 0; indiceListe < p_liste.Count; indiceListe++)
            {
                if (p_liste[indiceListe].CompareTo(minimum) < 0)
                {
                    minimum = p_liste[indiceListe];
                }
            }

            return minimum;
        }

        public static TypeElement[] CopierTableau<TypeElement>(TypeElement[] p_valeurs)
        {
            TypeElement[] listeCopiee = new TypeElement[p_valeurs.Length];
            for (int indice = 0; indice < p_valeurs.Length - 1; indice++)
            {
                listeCopiee[indice] = p_valeurs[indice];
            }

            return listeCopiee;
        }

        public static TypeElement[] TriBulles<TypeElement>(TypeElement[] p_valeur)
            where TypeElement : IComparable<TypeElement>
        {
            TypeElement ancienneValeur;
            bool permutationAuDernierTour = true;
            int indiceMax = p_valeur.Length;
            TypeElement[] valeursCopiees = CopierTableau(p_valeur);

            while (permutationAuDernierTour)
            {
                permutationAuDernierTour = false;
                for (int indiceCourant = 0; indiceCourant < indiceMax - 1; indiceCourant++)
                {
                    if (valeursCopiees[indiceCourant + 1].CompareTo(valeursCopiees[indiceCourant]) < 0)
                    {
                        ancienneValeur = valeursCopiees[indiceCourant + 1];
                        valeursCopiees[indiceCourant + 1] = valeursCopiees[indiceCourant];
                        valeursCopiees[indiceCourant] = ancienneValeur;
                        permutationAuDernierTour = true;
                    }
                }
                indiceMax = indiceMax - 1;
            }

            return valeursCopiees;
        }

        public static TypeElement ValeurMinimumAvecTri<TypeElement>(TypeElement[] p_tableau)
            where TypeElement : IComparable<TypeElement>
        {
            TypeElement[] valeurCopieeTrier = TriBulles(p_tableau);

            TypeElement minimum = default(TypeElement);
            minimum = p_tableau[0];


            if (p_tableau[0].CompareTo(p_tableau[1]) < 0)
            {
                minimum = p_tableau[0];
            }


            return minimum;

        }

        // complexité pour le 3-1) O(n)
        // Complexité pour le 3-2) nlog n
    }
}

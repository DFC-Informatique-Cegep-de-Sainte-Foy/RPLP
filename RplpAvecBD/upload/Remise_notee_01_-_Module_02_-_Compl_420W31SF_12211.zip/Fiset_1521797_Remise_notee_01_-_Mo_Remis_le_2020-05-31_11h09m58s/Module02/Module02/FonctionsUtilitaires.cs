﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Module02
{
    public static class FonctionsUtilitaires
    {
        public static List<int> CreerListeEntierAleatoire(int p_capacite, int p_valeurMin, int p_valeurMax) 
        {
            List<int> listeEntiersAleatoire = new List<int>(p_capacite) { };
            Random nombreAleatoire = new Random();
            int nombreGenere = 0;

            for (int indiceListeValeur = 0; indiceListeValeur < p_capacite -1; indiceListeValeur++)
            {
                nombreGenere = nombreAleatoire.Next(p_valeurMin, p_valeurMax + 1);
                listeEntiersAleatoire.Add(nombreGenere);
            }

            return listeEntiersAleatoire;
        }

        public static List<TypeElement> CopierTableau<TypeElement>(List<TypeElement> p_valeurs) where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)  // O(1) --> temps constant car condition si
            {
                throw new ArgumentNullException(nameof(p_valeurs));
            }
            return p_valeurs.Select(element => element).ToList();   // O(1) --> temps constant car enchaînement d'affectations
        }

        public static bool EstTableauTrie<TypeElement>(List<TypeElement> p_valeurs) where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException(nameof(p_valeurs));
            }

            bool estTrie = true;

            for (int indiceValeurTableau = 1; indiceValeurTableau < p_valeurs.Count; indiceValeurTableau++)
            {
                if (p_valeurs[indiceValeurTableau - 1].CompareTo(p_valeurs[indiceValeurTableau]) > 0)
                {
                    estTrie = false;
                }
            }
            return estTrie;
        }

        public static void AfficherCollectionEtIndice<TypeElement>(this List<TypeElement> p_valeurs, string p_titre)
        {
            if (p_valeurs == null)
            {
                throw new ArgumentException("Le tableau ne doit pas être nul", "p_tableauAAfficher");
            }
            string affichage = "\n" + p_titre + "\n";
            foreach (TypeElement element in p_valeurs)
            {
                affichage = affichage + string.Format("indice {0, -5}", p_valeurs.IndexOf(element));
            }

            affichage = affichage + "\n";

            foreach (TypeElement element in p_valeurs)
            {
                affichage = affichage + AfficherUnElement(element);
            }
            affichage = affichage + "\n";
            Console.Out.Write(affichage);
        }

        public static string AfficherUnElement<TypeElement>(this TypeElement p_element)
        {
            string affichage = "";
            affichage = string.Format("valeur {0, -5}", p_element);
            return affichage;
        }
    }
}


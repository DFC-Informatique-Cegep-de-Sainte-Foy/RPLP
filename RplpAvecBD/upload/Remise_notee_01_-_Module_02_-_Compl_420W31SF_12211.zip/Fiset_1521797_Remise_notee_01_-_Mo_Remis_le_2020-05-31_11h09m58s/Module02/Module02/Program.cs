﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Module02
{
    class Program
    {
        static void Main(string[] args)
        {
            var watch = new System.Diagnostics.Stopwatch();

            List<int> listeAleatoire = FonctionsUtilitaires.CreerListeEntierAleatoire(5, 1, 200);
            listeAleatoire.AfficherCollectionEtIndice("Liste crée de façon aléatoire");

            watch.Start();
            int minimumTrouve = Recherche.RechercherMinimum(listeAleatoire);
            watch.Stop();

            Console.WriteLine("\nLe minimum est " + minimumTrouve);
            Console.WriteLine($"RechercherMinimum: {watch.ElapsedMilliseconds} ms");

            watch.Reset();

            watch.Start();
            int minimumTrouveAvecTriRapide = Recherche.RechercheMinimumAvecTriRapide(listeAleatoire);
            watch.Stop();

            Console.WriteLine("\nLe minimum trouvé avec le tri rapide est : " + minimumTrouveAvecTriRapide);
            Console.WriteLine($"RechercherMinimumEtTri: {watch.ElapsedMilliseconds} ms");
            
        }
    }
}

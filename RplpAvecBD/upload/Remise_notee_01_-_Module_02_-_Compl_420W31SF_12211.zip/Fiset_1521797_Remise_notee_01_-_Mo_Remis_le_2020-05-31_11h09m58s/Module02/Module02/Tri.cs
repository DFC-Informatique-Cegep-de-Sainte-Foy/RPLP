﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Module02
{
    public static class Tri
    {
        public static List<TypeElement> TriRapide<TypeElement>(List<TypeElement> p_listeATrier) where TypeElement : IComparable<TypeElement>
        {
            if (p_listeATrier is null)  // O(1) --> temps constant car condition si
            {
                throw new ArgumentNullException(nameof(p_listeATrier)); 
            }
            List<TypeElement> valeursCopiees = default;  // O(1) --> temps constant car affectation
            if (p_listeATrier.Count != 0)   // O(1) --> temps constant car condition si
            {
                valeursCopiees = FonctionsUtilitaires.CopierTableau<TypeElement>(p_listeATrier);    // O(1) --> temps constant car enchaînement d'affectations
                TriRapide_rec<TypeElement>(valeursCopiees, 0, valeursCopiees.Count);                // Pire cas --> O(n) et meilleur cas --> O(log(n))
            }            
            return valeursCopiees;  // Complexité de O(n^2) pour le pire cas et O(nlog(n)) pour le meilleur cas
        }

        public static void TriRapide_rec<TypeElement>(List<TypeElement> p_valeurs, int p_premierIndice, int p_dernierIndice) where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs is null)  // O(1) --> temps constant car condition si
            {
                throw new ArgumentNullException(nameof(p_valeurs));
            }
            else if (p_valeurs.Count == 0)
            {
                throw new ArgumentOutOfRangeException(nameof(p_valeurs));
            }

            if (p_premierIndice < 0 || p_dernierIndice > p_valeurs.Count) // O(1) --> temps constant car condition si
            {
                throw new ArgumentOutOfRangeException();
            }
            int indicePivot = 0;    // O(1) --> temps constant car affectation
            if (p_premierIndice < p_dernierIndice)  // O(1) --> temps constant car condition si
            {
                indicePivot = ChoixPivot<TypeElement>(p_valeurs, p_premierIndice, p_dernierIndice); // O(1) --> voir le calcul plus bas
                indicePivot = Partitionner<TypeElement>(p_valeurs, p_premierIndice, p_dernierIndice, indicePivot); // O(n) --> voir le calcul plus bas
                //Le meilleur cas est lorsqu'on partitionne la liste et que le pivot divise la liste en deux sous-liste de taille presque qu'équivalente. Alors on fait la récursivité en 2 fois moins de temps --> O(log(n))
                //Le pire cas est lorsqu'on partitionne la liste et que le pivot choisi est toujours la valeur la plus grande ou la plus petite.
                //Cela va diviser la liste de façon à ce qu'une des sous-listes aura une taille de 1 et l'autre de taille n-1. Il va falloir faire l'appel récursif le même nombre de fois que la capacité de la liste --> O(n)
                TriRapide_rec<TypeElement>(p_valeurs, p_premierIndice, indicePivot - 1);
                TriRapide_rec<TypeElement>(p_valeurs, indicePivot + 1, p_dernierIndice);
            }
        }

        public static int ChoixPivot<TypeElement>(List<TypeElement> p_valeurs, int p_premierIndice, int p_dernierIndice)
        {
            if (p_valeurs is null)  // O(1) --> temps constant car condition si
            {
                throw new ArgumentNullException(nameof(p_valeurs));
            }
            int premierIndice = default;    // O(1) --> temps constant car affectation
            if (p_valeurs.Count != 0)  // O(1) --> temps constant car condition si
            {
                if (p_premierIndice < 0 || p_dernierIndice > p_valeurs.Count)   // O(1) --> temps constant car condition si
                {
                    throw new ArgumentOutOfRangeException();
                }
                premierIndice = p_premierIndice;    // O(1) --> temps constant car affectation
            }
            return premierIndice;   // Complexité de O(1)
        }

        public static int Partitionner<TypeElement>(List<TypeElement> p_valeurs, int p_premierIndice, int p_dernierIndice, int p_indicePivot) where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs is null)  // O(1) --> temps constant car condition si
            {
                throw new ArgumentNullException(nameof(p_valeurs));
            }
            TypeElement ancienneValeur = default;   // O(1) --> temps constant car affectation
            int futurIndicePivot = 0;
            if (p_valeurs.Count !=0)    // O(1) --> temps constant car condition si
            {
                if (p_premierIndice < 0 || p_dernierIndice > p_valeurs.Count)   // O(1) --> temps constant car condition si
                {
                    throw new ArgumentOutOfRangeException();
                }
                if (p_indicePivot < 0 || p_indicePivot >= p_valeurs.Count)  // O(1) --> temps constant car condition si
                {
                    throw new ArgumentOutOfRangeException(nameof(p_indicePivot));
                }
                if (p_valeurs.Count != 0)   // O(1) --> temps constant car condition si
                {
                    // O(1) --> temps constant car affectation
                    futurIndicePivot = p_premierIndice;         
                    int dernierIndice = p_dernierIndice - 1;

                    ancienneValeur = p_valeurs[p_indicePivot];
                    p_valeurs[p_indicePivot] = p_valeurs[dernierIndice];
                    p_valeurs[dernierIndice] = ancienneValeur;

                    for (int indiceListeValeur = p_premierIndice; indiceListeValeur < p_valeurs.Count; indiceListeValeur++) // O(n) --> temps linéaire car boucle for
                    {
                        if (p_valeurs[indiceListeValeur].CompareTo(p_valeurs[dernierIndice]) < 0)   // O(1) --> temps constant car condition si
                        {
                            // O(1) --> temps constant car affectation
                            ancienneValeur = p_valeurs[futurIndicePivot];
                            p_valeurs[futurIndicePivot] = p_valeurs[indiceListeValeur];
                            p_valeurs[indiceListeValeur] = ancienneValeur;
                            futurIndicePivot = futurIndicePivot + 1;
                        }
                    }
                    // O(1) --> temps constant car affectation
                    ancienneValeur = p_valeurs[futurIndicePivot];
                    p_valeurs[futurIndicePivot] = p_valeurs[dernierIndice];
                    p_valeurs[dernierIndice] = ancienneValeur;
                }
            }
            return futurIndicePivot; // Complexité de O(n) 
        }
    }
}

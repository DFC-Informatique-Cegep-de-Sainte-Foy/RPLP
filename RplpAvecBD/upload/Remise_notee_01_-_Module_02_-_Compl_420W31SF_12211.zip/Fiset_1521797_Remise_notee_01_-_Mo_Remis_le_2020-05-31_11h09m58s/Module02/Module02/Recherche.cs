﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Linq;
using System.Diagnostics;

namespace Module02
{
    public static class Recherche
    {
        public static TypeElement RechercherMinimum<TypeElement>(List<TypeElement> p_liste) where TypeElement : IComparable<TypeElement>
        {
            if (p_liste is null) // O(1) --> temps constant car condition si
            {
                throw new ArgumentNullException(nameof(p_liste));
            }
            TypeElement valeurMinimale = default;

            if (p_liste.Count != 0) // O(1) --> temps constant car condition si 
            {
                valeurMinimale = p_liste[0]; // O(1) --> temps constant car affectation

                for (int indiceValeurListe = 1; indiceValeurListe < p_liste.Count; indiceValeurListe++) // O(n) --> temps linéaire car boucle for
                {
                    if (p_liste[indiceValeurListe].CompareTo(valeurMinimale) < 0)   // O(1) --> temps constant car condition si et simple comparaison
                    {
                        valeurMinimale = p_liste[indiceValeurListe];                // O(1) --> temps constant car affectation
                    }
                }
            }
            return valeurMinimale;  // O(1*n) --> Temps d'exécution O(n)
        }

        public static TypeElement RechercheMinimumAvecTriRapide<TypeElement>(List<TypeElement> p_liste) where TypeElement : IComparable<TypeElement>
        {
            if(p_liste is null) // O(1) --> temps constant car condition si
            {
                throw new ArgumentNullException(nameof(p_liste));
            }
            TypeElement valeurMinimale = default;                       // O(1) --> temps constant car affectation
            if (p_liste.Count != 0)                                     // O(1) --> temps constant car condition si
            {
                List<TypeElement> listeTriee = Tri.TriRapide(p_liste);  // O(n^2) --> temps constant car affectation
                valeurMinimale = listeTriee[0];                         // O(1) --> temps constant car affectation

                for (int indiceValeurListe = 1; indiceValeurListe < p_liste.Count; indiceValeurListe++) // O(n) --> temps linéaire car boucle for
                {
                    if (listeTriee[indiceValeurListe].CompareTo(valeurMinimale) < 0) // O(1) --> temps constant car condition si et simple comparaison
                    {
                        valeurMinimale = listeTriee[indiceValeurListe];                 // O(1) --> temps constant car affectation
                    }
                }
            }
            return valeurMinimale;
        }
    }
}

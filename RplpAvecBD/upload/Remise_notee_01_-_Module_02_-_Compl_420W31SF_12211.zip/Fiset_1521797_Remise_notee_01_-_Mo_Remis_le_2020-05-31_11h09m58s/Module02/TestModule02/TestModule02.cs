using System;
using System.Collections.Generic;
using Xunit;
using Module02;

namespace TestModule02
{
    public class TestModule02
    {
        [Fact]
        public void RechercherMinimum_CasUnMinimum_ValeurMinimum()
        {
            //Arranger
            List<int> listeAttendue = new List<int>() { 13, 22, 3, 50, 40 };
            int valeurMinimaleAttendue = 3;

            //Agir
            int valeurCalculee = Recherche.RechercherMinimum(listeAttendue);

            //Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurCalculee);
        }

        [Fact]
        public void RechercherMinimum_ListeNulle_Exception()
        {
            //Arranger
            List<int> collectionNulle = null;

            //Agir & auditer
            Assert.Throws<ArgumentNullException>(() => { Recherche.RechercherMinimum(collectionNulle); });
        }

        [Fact]
        public void RechercherMinimum_ListeCapaciteZero_ValeurNulle()
        {
            //Arranger
            List<int> listeAttendue = new List<int>() { };
            int valeurMinimaleAttendue = default;

            //Agir
            int valeurCalculee = Recherche.RechercherMinimum(listeAttendue);

            //Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurCalculee);
        }


        [Fact]
        public void RechercherMinimum_ValeurChercheeAIndiceZero_MinimumAIndiceZero()
        {
            //Arranger
            List<int> listeAttendue = new List<int>() { 1, 22, 3, 50, 40 };
            int valeurMinimaleAttendue = 1;

            //Agir
            int valeurCalculee = Recherche.RechercherMinimum(listeAttendue);

            //Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurCalculee);
        }

        [Fact]
        public void RechercherMinimum_ValeurChercheeADernierIndice_MinimumADernierIndice()
        {
            //Arranger
            List<int> listeAttendue = new List<int>() { 15, 22, 33, 50, 4 };
            int valeurMinimaleAttendue = 4;

            //Agir
            int valeurCalculee = Recherche.RechercherMinimum(listeAttendue);

            //Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurCalculee);
        }

        [Fact]
        public void RechercherMinimum_ValeurChercheeDouble_MinimumADernierIndice()
        {
            //Arranger
            List<double> listeAttendue = new List<double>() { 15, 22, 33, 50, 4 };
            double valeurMinimaleAttendue = 4;

            //Agir
            double valeurCalculee = Recherche.RechercherMinimum(listeAttendue);

            //Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurCalculee);
        }

        [Fact]
        public void TriRapide_ValeurDejaTrie_BonResultat()
        {
            //Arranger
            List<int> listeATrier = new List<int>() { 13, 22, 3, 50, 40 };
            List<int> listeAttendue = new List<int>() { 3, 13, 22, 40, 50 };

            //Agir
            List<int> listeTrieeCalculee = Tri.TriRapide(listeATrier);
            listeTrieeCalculee.AfficherUnElement();

            //Auditer

            Assert.Equal(listeAttendue, listeTrieeCalculee);
            //Assert.NotSame(listeAttendue, listeTrieeCalculee);
        }

        [Fact]
        public void TriRapide_ListeNulle_Exception()
        {
            //Arranger
            List<int> collectionNulle = null;

            //Agir & auditer
            Assert.Throws<ArgumentNullException>(() => { Tri.TriRapide(collectionNulle); });
        }

        [Fact]
        public void TriRapide_ListeCapaciteZero_ValeurNulle()
        {
            //Arranger
            List<int> listeATrier = new List<int>() { };
            List<int> listeAttendue = default;

            //Agir
            List<int> listeTrieeCalculee = Tri.TriRapide(listeATrier);

            //Auditer
            Assert.Equal(listeAttendue, listeTrieeCalculee);
        }

        [Fact]
        public void ChoixPivot_ListeCapaciteZero_ValeurNulle()
        {
            //Arranger
            List<int> listeATrier = new List<int>();
            int premierIndice = default;
            int dernierIndice = default;
            int pivotAttendu = default;

            //Agir
            int pivotCalcule = Tri.ChoixPivot(listeATrier, premierIndice, dernierIndice);

            //Auditer
            Assert.Equal(pivotAttendu, pivotCalcule);
        }

        [Fact]
        public void ChoixPivot_PremierIndiceHorsBorne_Exception()
        {
            //Arranger
            List<int> listeATrier = new List<int>() { 52 };
            int premierIndice = -1;
            int dernierIndice = default;

            //Agir & auditer
            Assert.Throws<ArgumentOutOfRangeException>(() => { Tri.ChoixPivot(listeATrier, premierIndice, dernierIndice); });
        }

        [Fact]
        public void ChoixPivot_DernierIndiceHorsBorne_Exception()
        {
            //Arranger
            List<int> listeATrier = new List<int>() { 52 };
            int premierIndice = 0;
            int dernierIndice = 2;

            //Agir & auditer
            Assert.Throws<ArgumentOutOfRangeException>(() => { Tri.ChoixPivot(listeATrier, premierIndice, dernierIndice); });
        }


        [Fact]
        public void Partitionner_ListeNulle_Erreur()
        {
            //Arranger
            List<int> listeATrier = null;
            int premierIndice = 0;
            int dernierIndice = 2;
            int indicePivot = 1;

            //Agir & auditer
            Assert.Throws<ArgumentNullException>(() => { Tri.Partitionner(listeATrier, premierIndice, dernierIndice, indicePivot); });
        }

        [Fact]
        public void Partitionner_ListeCapaciteZero_ValeurNulle()
        {
            //Arranger
            List<int> listeATrier = new List<int>() { };
            int premierIndice = 0;
            int dernierIndice = 0;
            int indicePivot = 0;
            int futurIndicePivotAttendu = 0;

            //Agir
            int futurIndicePivotCalcule = Tri.Partitionner(listeATrier, premierIndice, dernierIndice, indicePivot);

            //Auditer
            Assert.Equal(futurIndicePivotAttendu, futurIndicePivotCalcule);
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace Exercice03Complexite
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            List<int> listeInitial = new List<int>() { 200, 4, 1, 90, 46, 20 };
            List<int> listeCopiee = new List<int>();

            listeCopiee = Fonction.TriRapide1(listeInitial);

            for (int indexListe = 0; indexListe < listeCopiee.Count; indexListe++)
            {
                Console.WriteLine(listeCopiee[indexListe]);
            }
        }
    }
}

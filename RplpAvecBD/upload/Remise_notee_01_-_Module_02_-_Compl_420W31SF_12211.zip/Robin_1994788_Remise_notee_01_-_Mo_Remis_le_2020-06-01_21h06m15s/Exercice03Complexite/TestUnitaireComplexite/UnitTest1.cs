using System;
using Xunit;
using System.Collections.Generic;
using Exercice03Complexite;

namespace TestUnitaireComplexite
{
    public class UnitTest1
    {
        [Fact]
        public void TriRapide_AvecInt_Succes()
        {
            //Arranger

            List<int> listeInitial = new List<int>() { 200, 4, 1, 90, 46, 20 };
            List<int> listeCopiee = new List<int>();
            List<int> listeAttendu = new List<int>() { 1, 4, 20, 46, 90, 200 };

            //Agir
            listeCopiee = Fonction.TriRapide1<int>(listeInitial);

            //Auditer
            Assert.Equal(listeAttendu, listeCopiee);
        }
        [Fact]
        public void TriRapide_AvecString_Succes()
        {
            //Arranger

            List<string> listeInitial = new List<string>() { "gaga", "aba", "aga", "mama", "aka" };
            List<string> listeCopiee = new List<string>();
            List<string> listeAttendu = new List<string>() { "aba", "aga", "aka", "gaga", "mama"};

            //Agir
            listeCopiee = Fonction.TriRapide1<string>(listeInitial);

            //Auditer
            Assert.Equal(listeAttendu, listeCopiee);
        }
        [Fact]
        public void RechercheMinimum_AvecValeurPositive_Succes()
        {
            //Arranger
            List<int> listeInitial = new List<int>() { 200, 4, 1, 90, 46, 20 };
            int valeurAttendu = 1;
            int valeurTrouvee = 0;

            //Agir
            valeurTrouvee = Fonction.CalculMinimum(listeInitial);

            //Auditer
            Assert.Equal(valeurAttendu, valeurTrouvee);
        }
        [Fact]
        public void CalculMinimum_AvecValeurPositive_Succes()
        {
            //Arranger
            List<int> listeInitial = new List<int>() { 200, 4, 1, 90, 46, 20 };
            int valeurAttendu = 1;
            int valeurTrouvee = 0;

            //Agir
            valeurTrouvee = Fonction.CalculMinimum(listeInitial);

            //Auditer
            Assert.Equal(valeurAttendu, valeurTrouvee);
        }
    }
}

using System;
using Xunit;
using Module2_Exercice3;
using System.Collections.Generic;

namespace TestsModule2_Exercice3
{
    public class TestsFonctions
    {
        // Num�ro 1
        [Fact]
        public void CalculerValeurMinimaleV1_ListeElementsNull_RenvoyerNullException()
        {
            // Arranger
            List<int> listeEntiers = null;

            // Agir & Auditer
            Assert.Throws<ArgumentNullException>(() => {
                int valeurMinimaleAttendue = Fonctions.CalculerValeurMinimaleV1(listeEntiers);
            });
        }

        [Fact]
        public void CalculerValeurMinimaleV1_ValeurMinimalePremierIndice_RenvoyerValeurMinimale()
        {
            // Arranger
            List<int> listeEntiers = new List<int>() { 1, 6, 2, 8, 10, 7, 3 };
            int valeurMinimaleAttendue = 1;

            // Agir
            int valeurMinimaleTest = Fonctions.CalculerValeurMinimaleV1(listeEntiers);

            // Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurMinimaleTest);
        }

        [Fact]
        public void CalculerValeurMinimaleV1_ValeurMinimaleIndiceMilieu_RenvoyerValeurMinimale()
        {
            // Arranger
            List<int> listeEntiers = new List<int>() { 2, 6, 8, 1, 10, 7, 3 };
            int valeurMinimaleAttendue = 1;

            // Agir
            int valeurMinimaleTest = Fonctions.CalculerValeurMinimaleV1(listeEntiers);

            // Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurMinimaleTest);
        }

        [Fact]
        public void CalculerValeurMinimaleV1_ValeurMinimaleDernierIndice_RenvoyerValeurMinimale()
        {
            // Arranger
            List<int> listeEntiers = new List<int>() { 2, 6, 7, 8, 10, 3, 1 };
            int valeurMinimaleAttendue = 1;

            // Agir
            int valeurMinimaleTest = Fonctions.CalculerValeurMinimaleV1(listeEntiers);

            // Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurMinimaleTest);
        }

        [Fact]
        public void CalculerValeurMinimaleV1_ValeurMinimaleDoublee_RenvoyerValeurMinimale()
        {
            // Arranger
            List<int> listeEntiers = new List<int>() { 1, 6, 7, 1, 10, 3, 2 };
            int valeurMinimaleAttendue = 1;

            // Agir
            int valeurMinimaleTest = Fonctions.CalculerValeurMinimaleV1(listeEntiers);

            // Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurMinimaleTest);
        }

        // --------------------------------------------------------------------------------
        // Num�ro 2

        [Fact]
        public void CalculerValeurMinimaleV2_ListeElementsNull_RenvoyerNullException()
        {
            // Arranger
            List<int> listeEntiers = null;

            // Agir & Auditer
            Assert.Throws<ArgumentNullException>(() => {
                int valeurMinimaleAttendue = Fonctions.CalculerValeurMinimaleV2(listeEntiers);
            });
        }

        [Fact]
        public void CalculerValeurMinimaleV2_ValeurMinimalePremierIndice_RenvoyerValeurMinimale()
        {
            // Arranger
            List<int> listeEntiers = new List<int>() { 1, 6, 2, 8, 10, 7, 3 };
            int valeurMinimaleAttendue = 1;

            // Agir
            int valeurMinimaleTest = Fonctions.CalculerValeurMinimaleV2(listeEntiers);

            // Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurMinimaleTest);
        }

        [Fact]
        public void CalculerValeurMinimaleV2_ValeurMinimaleIndiceMilieu_RenvoyerValeurMinimale()
        {
            // Arranger
            List<int> listeEntiers = new List<int>() { 8, 6, 2, 1, 10, 7, 3 };
            int valeurMinimaleAttendue = 1;

            // Agir
            int valeurMinimaleTest = Fonctions.CalculerValeurMinimaleV2(listeEntiers);

            // Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurMinimaleTest);
        }

        [Fact]
        public void CalculerValeurMinimaleV2_ValeurMinimaleDernierIndice_RenvoyerValeurMinimale()
        {
            // Arranger
            List<int> listeEntiers = new List<int>() { 8, 6, 2, 3, 10, 7, 1 };
            int valeurMinimaleAttendue = 1;

            // Agir
            int valeurMinimaleTest = Fonctions.CalculerValeurMinimaleV2(listeEntiers);

            // Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurMinimaleTest);
        }

        [Fact]
        public void CalculerValeurMinimaleV2_ValeurMinimaleDoublee_RenvoyerValeurMinimale()
        {
            // Arranger
            List<int> listeEntiers = new List<int>() { 1, 6, 2, 1, 10, 7, 3 };
            int valeurMinimaleAttendue = 1;

            // Agir
            int valeurMinimaleTest = Fonctions.CalculerValeurMinimaleV2(listeEntiers);

            // Auditer
            Assert.Equal(valeurMinimaleAttendue, valeurMinimaleTest);
        }
    }
}

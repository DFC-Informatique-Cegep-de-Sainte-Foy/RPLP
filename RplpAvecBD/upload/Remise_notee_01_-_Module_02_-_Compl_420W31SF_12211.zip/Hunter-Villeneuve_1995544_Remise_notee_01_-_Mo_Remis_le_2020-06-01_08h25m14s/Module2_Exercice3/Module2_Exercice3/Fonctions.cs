﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Module2_Exercice3
{
    public static class Fonctions
    {
        // Numéro 1
        public static TypeElement CalculerValeurMinimaleV1<TypeElement>(this List<TypeElement> p_listeGenerique) where TypeElement : IComparable<TypeElement>
        {
            if (p_listeGenerique == null)
            {
                throw new ArgumentNullException(nameof(p_listeGenerique));
            }

            TypeElement plusPetitElement = p_listeGenerique[0];

            foreach (TypeElement element in p_listeGenerique)
            {
                if (plusPetitElement.CompareTo(element) > 0)
                {
                    plusPetitElement = element;
                }
            }

            return plusPetitElement;
        }

        // Numéro 2
        public static TypeElement CalculerValeurMinimaleV2<TypeElement>(this List<TypeElement> p_listeGenerique) where TypeElement : IComparable<TypeElement>
        {
            if (p_listeGenerique == null)
            {
                throw new ArgumentNullException(nameof(p_listeGenerique));
            }

            List<TypeElement> p_listeTriee = TriBulles(p_listeGenerique);

            return p_listeTriee[0];
        }

        // ----------------------------------------------------------------------------------------------------------------------------------------------

        public static List<TypeElement> CopierCollection<TypeElement>(this List<TypeElement> p_valeurs)
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException(nameof(p_valeurs));
            }

            return p_valeurs.Select(e => e).ToList();
        }

        public static List<TypeElement> TriBulles<TypeElement>(this List<TypeElement> p_listeValeurs) where TypeElement : IComparable<TypeElement>
        {
            if (p_listeValeurs == null)
            {
                throw new ArgumentNullException(nameof(p_listeValeurs));
            }

            TypeElement ancienneValeur = default(TypeElement);
            bool permutationDernierTour = true;
            int indiceMax = p_listeValeurs.Count - 1;
            List<TypeElement> valeursCopiees = CopierCollection(p_listeValeurs);

            while (permutationDernierTour)
            {
                permutationDernierTour = false;

                for (int indiceCourant = 0; indiceCourant <= indiceMax - 1; ++indiceCourant) // Pourquoi le ++ à gauche ou à droite ?
                {
                    // -1 = plus petit
                    // 0 = pareil
                    // 1 = plus grand
                    if (valeursCopiees[indiceCourant + 1].CompareTo(valeursCopiees[indiceCourant]) < 0)
                    {
                        ancienneValeur = valeursCopiees[indiceCourant + 1];
                        valeursCopiees[indiceCourant + 1] = valeursCopiees[indiceCourant];
                        valeursCopiees[indiceCourant] = ancienneValeur;
                        permutationDernierTour = true;
                    }
                }

                indiceMax = indiceMax - 1;
            }

            return valeursCopiees;
        }

        public static bool EstTrie<TypeElement>(this List<TypeElement> p_valeurs) where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException(nameof(p_valeurs));
            }

            bool estTrie = true;
            for (int indiceValeur = 0; estTrie && indiceValeur < p_valeurs.Count - 1; ++indiceValeur)
            {
                if (p_valeurs[indiceValeur].CompareTo(p_valeurs[indiceValeur + 1]) > 0)
                {
                    estTrie = false;
                }
            }

            return estTrie;
        }
    }
}

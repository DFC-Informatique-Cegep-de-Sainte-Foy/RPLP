﻿using System;
using System.Collections.Generic;

namespace Module2_Exercice3
{
    class Program
    {
        static void Main(string[] args)
        {
            // Listes à tester
            List<int> listeEntiers = new List<int>() { 2, 6, 1, 8, 10, 7 };
            List<string> listeNoms = new List<string>() {"Raoul", "Charles", "Caroline", "Andre"};

            // Numéro 1
            Console.WriteLine("\n Numéro 1\n");
            int valeurMinimale = Fonctions.CalculerValeurMinimaleV1(listeEntiers);
            string nomMinimale = Fonctions.CalculerValeurMinimaleV1(listeNoms);
            Console.WriteLine($" Nombre trouvé: {valeurMinimale}\n Nom trouvé: {nomMinimale}");

            // Réinitialiser
            valeurMinimale = 0;
            nomMinimale = "";

            // Numéro 2
            Console.WriteLine("\n Numéro 2\n");
            valeurMinimale = Fonctions.CalculerValeurMinimaleV2(listeEntiers);
            nomMinimale = Fonctions.CalculerValeurMinimaleV2(listeNoms);
            Console.WriteLine($" Nombre trouvé: {valeurMinimale}\n Nom trouvé: {nomMinimale}");

            // Numéro 3

            // SANS TRI: temps linéaire = O(n)
            // L'algorithme a une seule boucle

            // AVEC TRI A BULLES: temps quadratique = O(n^2) 
            // L'algorithme a deux boucles imbriquées

            // La recherche de valeur minimale dans une liste serait donc plus efficace sans un tri au préalable.
        }
    }
}

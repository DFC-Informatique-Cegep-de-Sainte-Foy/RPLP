using Recherche_Minimum;
using System;
using System.Collections.Generic;
using Xunit;

namespace Test_Recherche_Minimum
{
    public class Test_FonctionsUtiles_Tri
    {
        //Tests Copier_Liste
        [Fact]
        public void CopierListe_Liste_Null_Exception()
        {
            //Arranger
            List<int> ListeInitiale = null;
            //Agir & auditer
            Assert.Throws<ArgumentNullException>(() => { FonctionsUtiles.CopierListe(ListeInitiale); });
        }
        [Fact]
        public void CopierListe_Liste_vide()
        {
            //Arranger
            List<int> ListeInitiale = new List<int>() { };
            List<int> ListeAttendue = new List<int>() { };
            //Agir
            List<int> ListeCalculee = FonctionsUtiles.CopierListe(ListeInitiale);
            //Auditer
            Assert.Equal(ListeInitiale, ListeAttendue);
        }
        [Fact]
        public void CopierListe_Liste_Une_valeur()
        {
            List<int> ListeInitiale = new List<int>() { 3 };
            List<int> ListeAttendue = new List<int>() { 3 };

            List<int> ListeCalculee = FonctionsUtiles.CopierListe(ListeInitiale);
            Assert.Equal(ListeInitiale, ListeAttendue);
        }
        [Fact]
        public void CopierListe_Liste_Plusieurs_valeurs()
        {
            List<int> ListeInitiale = new List<int>() { 3, -5, 9 };
            List<int> ListeAttendue = new List<int>() { 3, -5, 9 };

            List<int> ListeCalculee = FonctionsUtiles.CopierListe(ListeInitiale);
            Assert.Equal(ListeInitiale, ListeAttendue);
            Assert.NotSame(ListeInitiale, ListeAttendue);
        }

        //Tests Trouver_Minimum_Liste_Non_Triee
        [Fact]
        public void TrouverMinimiumListeNonTriee_Liste_Null_Exception()
        {
            List<int> ListeInitiale = null;

            Assert.Throws<ArgumentNullException>(() => { FonctionsUtiles.TrouverMinimumListeNonTriee(ListeInitiale); });
        }
        [Fact]
        public void TrouverMinimiumListeNonTriee_Trouver_Minimum_Liste_vide()
        {
            List<int> ListeInitiale = new List<int>();

            Assert.Throws<ArgumentOutOfRangeException>(() => { FonctionsUtiles.TrouverMinimumListeNonTriee(ListeInitiale); });
        }
        [Fact]
        public void TrouverMinimiumListeNonTriee_Trouver_Minimum_Liste_Une_valeur()
        {
            List<int> ListeInitiale = new List<int>() { 0 };
            int minimumAttendu = 0;

            int minimumCalcule = FonctionsUtiles.TrouverMinimumListeNonTriee(ListeInitiale);

            Assert.Equal(minimumAttendu, minimumCalcule);
        }

        [Fact]
        public void TrouverMinimiumListeNonTriee_Trouver_Minimum_Liste_Deux_valeurs()
        {
            List<int> ListeInitiale = new List<int>() { 9, -8 };
            int minimumAttendu = -8;

            int minimumCalcule = FonctionsUtiles.TrouverMinimumListeNonTriee(ListeInitiale);

            Assert.Equal(minimumAttendu, minimumCalcule);
        }
        [Fact]
        public void TrouverMinimiumListeNonTriee_Trouver_Minimum_Liste_Plusieurs_valeurs()
        {
            List<int> ListeInitiale = new List<int>() { 5, -12, 0, 6, -7 };
            int minimumAttendu = -12;

            int minimumCalcule = FonctionsUtiles.TrouverMinimumListeNonTriee(ListeInitiale);

            Assert.Equal(minimumAttendu, minimumCalcule);
        }

        //Tests Trouver_Minimum_Liste_Triee
        [Fact]
        public void TrouverMinimumListeTriee_Liste_Null_Exception()
        {
            List<int> ListeInitiale = null;

            Assert.Throws<ArgumentNullException>(() => { FonctionsUtiles.TrouverMinimumListeTriee(ListeInitiale); });
        }
        [Fact]
        public void TrouverMinimumListeTriee_Trouver_Minimum_Liste_vide()
        {
            List<int> ListeInitiale = new List<int>();

            Assert.Throws<ArgumentOutOfRangeException>(() => { FonctionsUtiles.TrouverMinimumListeTriee(ListeInitiale); });
        }
        [Fact]
        public void TrouverMinimumListeTriee_Trouver_Minimum_Liste_Une_valeur()
        {
            List<int> ListeInitiale = new List<int>() { 8 };
            int minimumAttendu = 8;

            int minimumCalcule = FonctionsUtiles.TrouverMinimumListeTriee(ListeInitiale);

            Assert.Equal(minimumAttendu, minimumCalcule);
        }
        [Fact]
        public void TrouverMinimumListeTriee_Trouver_Minimum_Liste_Deux_valeurs()
        {
            List<int> ListeInitiale = new List<int>() { -6,15 };
            int minimumAttendu = -6;

            int minimumCalcule = FonctionsUtiles.TrouverMinimumListeTriee(ListeInitiale);

            Assert.Equal(minimumAttendu, minimumCalcule);
        }
        [Fact]
        public void TrouverMinimumListeTriee_Trouver_Minimum_Liste_Plusieurs_valeurs()
        {
            List<int> ListeInitiale = new List<int>() { -20, 0, 56 };
            int minimumAttendu = -20;

            int minimumCalcule = FonctionsUtiles.TrouverMinimumListeTriee(ListeInitiale);

            Assert.Equal(minimumAttendu, minimumCalcule);
        }

        //Tests Choix_Pivot
        [Fact]
        public void ChoixPivot_Liste_Null_Exception()
        {
            int indicePremier = 0;
            int indiceDernier = 0;
            List<int> ListeInitiale = null;

            Assert.Throws<ArgumentNullException>(() => { FonctionsUtiles.ChoixPivot(ListeInitiale, indicePremier, indiceDernier); });
        }
        [Fact]
        public void ChoixPivot_IndicePremier()
        {
            List<int> ListeInitiale = new List<int>() { -12, 1, 6 };
            int indicePremierAttendu = 0;

            int indicePremierCalcule = FonctionsUtiles.ChoixPivot(ListeInitiale, indicePremierAttendu,2);

            Assert.Equal(indicePremierAttendu, indicePremierCalcule);
        }

        //Test_Partitionner
        [Fact]
        public void Partitionner_Liste_Null_Exception()
        {
            int indicePremier = 0;
            int indiceDernier = 0;
            int indicePivot = 0;
            List<int> ListeInitiale = null;

            Assert.Throws<ArgumentNullException>(() => { FonctionsUtiles.Partitionner(ListeInitiale, indicePremier, indiceDernier, indicePivot); });
        }
        [Fact]
        public void Partitionner_Liste_Pair_Indice_Pivot()
        {
            List<int> ListeInitiale = new List<int>() { -5, 9, 10, 23 };
            int indicePivotAttendu = 1;
            int indicePivotCalcule = FonctionsUtiles.Partitionner(ListeInitiale, 0, 2, indicePivotAttendu);

            Assert.Equal(indicePivotCalcule, indicePivotAttendu);
        }
        [Fact]
        public void Partitionner_Liste_Impair_Indice_Pivot()
        {
            List<int> ListeInitiale = new List<int>() { -8, 2, 30, 253, 630 };
            int indicePivotAttendu = 1;
            int indicePivotCalcule = FonctionsUtiles.Partitionner(ListeInitiale, 0, 2, indicePivotAttendu);

            Assert.Equal(indicePivotCalcule, indicePivotAttendu);
        }

        //Testes Tri Bulles
        [Fact]
        public void TrierBulles_Liste_Null_Exception()
        {
            List<int> ListeInitiale = null;

            Assert.Throws<ArgumentNullException>(() => { Tri.TrierBulles(ListeInitiale); });
        }
        [Fact]
        public void TrierBulles_Liste_Vide()
        {
            List<int> ListeInitiale = new List<int>() { };
            List<int> ListeAttendue = new List<int>() { };

            List<int> ListeCalculee = Tri.TrierBulles(ListeInitiale);
            Assert.Equal(ListeInitiale, ListeAttendue);
        }
        [Fact]
        public void TrierBulles_Liste_Liste_Une_valeur()
        {
            List<int> ListeInitiale = new List<int>() { -8 };
            List<int> ListeAttendue = new List<int>() { -8 };

            List<int> ListeCalculee = Tri.TrierBulles(ListeInitiale);
            Assert.Equal(ListeInitiale, ListeAttendue);
        }
        [Fact]
        public void TrierBulles_Liste_Liste_Plusieurs_valeurs()
        {
            List<int> ListeInitiale = new List<int>() { 22,17,-47 };
            List<int> ListeAttendue = new List<int>() { -47,17,22 };

            List<int> ListeCalculee = Tri.TrierBulles(ListeInitiale);
            Assert.Equal(ListeCalculee, ListeAttendue);
        }

        //Testes Tri Rapide
        [Fact]
        public void TriRapide_Liste_Null_Exception()
        {
            List<int> ListeInitiale = null;

            Assert.Throws<ArgumentNullException>(() => { Tri.TriRapide(ListeInitiale); });
        }
        [Fact]
        public void TriRapide_Liste_Liste_Vide()
        {
            List<int> ListeInitiale = new List<int>() { };
            List<int> ListeAttendue = new List<int>() { };

            List<int> ListeCalculee = Tri.TriRapide(ListeInitiale);
            Assert.Equal(ListeInitiale, ListeAttendue);
        }
        [Fact]
        public void TriRapide_Liste_Liste_Une_valeur()
        {
            List<int> ListeInitiale = new List<int>() { 5 };
            List<int> ListeAttendue = new List<int>() { 5 };

            List<int> ListeCalculee = Tri.TriRapide(ListeInitiale);
            Assert.Equal(ListeInitiale, ListeAttendue);
        }
        [Fact]
        public void TriRapide_Liste_Liste_Deux_valeurs()
        {
            List<int> ListeInitiale = new List<int>() { 5, -13 };
            List<int> ListeAttendue = new List<int>() { -13, 5 };

            List<int> ListeCalculee = Tri.TriRapide(ListeInitiale);
            Assert.Equal(ListeCalculee, ListeAttendue);
        }
        [Fact]
        public void TriRapide_Liste_Liste_Plusieurs_valeurs()
        {
            List<int> ListeInitiale = new List<int>() { 6,-9,0 };
            List<int> ListeAttendue = new List<int>() {-9,0, 6 };

            List<int> ListeCalculee = Tri.TriRapide(ListeInitiale);
            Assert.Equal(ListeCalculee, ListeAttendue);
        }
        //Testes Tri Rec
        [Fact]
        public void TriRapide_Rec_Liste_Null_Exception()
        {
            int indicePremier = 0;
            int indiceDernier = 0;
            List<int> ListeInitiale = null;

            Assert.Throws<ArgumentNullException>(() => { Tri.TriRapide_rec(ListeInitiale, indicePremier, indiceDernier); });
        }       
    }
}

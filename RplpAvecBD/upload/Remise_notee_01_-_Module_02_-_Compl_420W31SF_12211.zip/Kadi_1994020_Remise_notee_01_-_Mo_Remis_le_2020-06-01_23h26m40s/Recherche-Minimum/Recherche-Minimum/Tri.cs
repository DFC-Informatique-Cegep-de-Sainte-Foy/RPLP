﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Recherche_Minimum
{
    public class Tri
    {
        public static List<TypeElement> TrierBulles<TypeElement>(List<TypeElement> p_valeurs)
            where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException("La liste ne doit pas être nulle", "p_valeurs");
            }
            bool permutationAuDernierTour = true;
            int indicemax = p_valeurs.Count - 1;
            List<TypeElement> valeursCopiees = FonctionsUtiles.CopierListe(p_valeurs);
            while (permutationAuDernierTour)
            {
                permutationAuDernierTour = false;
                for (int indiceCourant = 0; indiceCourant < indicemax; indiceCourant++)
                {
                    if (valeursCopiees[indiceCourant + 1].CompareTo(valeursCopiees[indiceCourant]) < 0)
                    {
                        TypeElement ancienneValeur = valeursCopiees[indiceCourant + 1];
                        valeursCopiees[indiceCourant + 1] = valeursCopiees[indiceCourant];
                        valeursCopiees[indiceCourant] = ancienneValeur;
                        permutationAuDernierTour = true;
                    }
                }
            }
            return valeursCopiees;
        }
        public static List<TypeElement> TriRapide<TypeElement>(List<TypeElement> p_valeurs)
        where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException("La liste ne doit pas être nulle", "p_valeurs");
            }
            List<TypeElement> valeursCopiees = FonctionsUtiles.CopierListe(p_valeurs);
            TriRapide_rec(valeursCopiees, 0, valeursCopiees.Count - 1);

            return valeursCopiees;
        }
        public static void TriRapide_rec<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier)
       where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException("La liste ne doit pas être nulle", "p_valeurs");
            }
            int indicePivot = 0;
            if (p_indicePremier < p_indiceDernier)
            {
                indicePivot = FonctionsUtiles.ChoixPivot(p_valeurs, p_indicePremier, p_indiceDernier);
                indicePivot = FonctionsUtiles.Partitionner(p_valeurs, p_indicePremier, p_indiceDernier, indicePivot);
                TriRapide_rec(p_valeurs, p_indicePremier, indicePivot - 1);
                TriRapide_rec(p_valeurs, indicePivot + 1, p_indiceDernier);
            }
        }        
    }
}

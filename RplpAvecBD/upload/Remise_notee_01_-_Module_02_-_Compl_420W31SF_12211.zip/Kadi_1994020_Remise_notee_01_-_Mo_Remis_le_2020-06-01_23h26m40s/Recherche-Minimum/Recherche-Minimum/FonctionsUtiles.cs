﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Recherche_Minimum
{
    public class FonctionsUtiles
    {
        public static List<TypeElement> CopierListe<TypeElement>(List<TypeElement> p_liste_initiale)
        {
            if (p_liste_initiale == null)
            {
                throw new ArgumentNullException("La liste ne doit pas être nulle", "p_liste_initiale");
            }
            return p_liste_initiale.Select(e => e).ToList();
        }
        public static TypeElement TrouverMinimumListeNonTriee<TypeElement>(List<TypeElement> p_liste)
        where TypeElement : IComparable<TypeElement>
        {
            if (p_liste == null)
            {
                throw new ArgumentNullException("La liste ne doit pas être nulle", "p_liste");
            }
            if (p_liste.Count == 0)
            {
                throw new ArgumentOutOfRangeException("La liste ne doit pas être vide", "p_liste");
            }
            TypeElement minimum = p_liste[0];
            for (int i = 1; i < p_liste.Count; i++)
                if (p_liste[i].CompareTo(minimum) < 0)
                {
                    minimum = p_liste[i];
                }
            Console.WriteLine("Le minimum de la liste est : " + minimum);
            return minimum;
        }
        public static TypeElement TrouverMinimumListeTriee<TypeElement>(List<TypeElement> p_listeTriee)
        {
            if (p_listeTriee == null)
            {
                throw new ArgumentNullException("La liste ne doit pas être nulle", "p_listeTriee");
            }
            if (p_listeTriee.Count == 0)
            {
                throw new ArgumentOutOfRangeException("La liste ne doit pas être vide", "p_listeTriee");
            }
            Console.WriteLine("Le minimum de la liste triée est : " + p_listeTriee[0]);
            return p_listeTriee[0];
        }
        public static int ChoixPivot<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier)
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException("La liste ne doit pas être nulle", "p_valeurs");
            }
            return p_indicePremier;
        }
        public static int Partitionner<TypeElement>(List<TypeElement> p_valeurs, int p_indicePremier, int p_indiceDernier, int p_indicePivot)
        where TypeElement : IComparable<TypeElement>
        {
            if (p_valeurs == null)
            {
                throw new ArgumentNullException("La liste ne doit pas être nulle", "p_valeurs");
            }
            int futureIndicePivot = p_indicePremier;
            TypeElement ancienneValeur = p_valeurs[p_indicePivot];
            p_valeurs[p_indicePivot] = p_valeurs[p_indiceDernier];
            p_valeurs[p_indiceDernier] = ancienneValeur;

            for (int indiceValeurARanger = p_indicePremier; indiceValeurARanger < p_indiceDernier; indiceValeurARanger++)
            {
                if (p_valeurs[indiceValeurARanger].CompareTo(p_valeurs[p_indiceDernier]) <= 0)
                {
                    ancienneValeur = p_valeurs[futureIndicePivot];
                    p_valeurs[futureIndicePivot] = p_valeurs[indiceValeurARanger];
                    p_valeurs[indiceValeurARanger] = ancienneValeur;
                    futureIndicePivot = futureIndicePivot + 1;
                }
            }
            ancienneValeur = p_valeurs[futureIndicePivot];
            p_valeurs[futureIndicePivot] = p_valeurs[p_indiceDernier];
            p_valeurs[p_indiceDernier] = ancienneValeur;

            return futureIndicePivot;
        }
    }
}

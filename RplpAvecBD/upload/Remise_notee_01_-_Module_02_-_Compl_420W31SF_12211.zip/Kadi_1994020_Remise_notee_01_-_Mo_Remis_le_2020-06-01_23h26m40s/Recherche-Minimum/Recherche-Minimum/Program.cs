﻿using System;
using System.Collections.Generic;

namespace Recherche_Minimum
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> liste = new List<int> {5,-6,9,-2,10,5,-3,0,25,-7 };
            Console.WriteLine(string.Join(" ", liste));
  
            //Trouver minimum sans trier
            int minimum = FonctionsUtiles.TrouverMinimumListeNonTriee(liste);

            //Trouver minimum tri à bulles
            List<int> listeTrieeBulles = Tri.TrierBulles(liste);
            Console.WriteLine(string.Join(" ", listeTrieeBulles));
            FonctionsUtiles.TrouverMinimumListeTriee(listeTrieeBulles);

            //Trouver minimum tri rapide
            List<int> listeTrieeRapide = Tri.TriRapide(liste);
            Console.WriteLine(string.Join(" ", listeTrieeRapide));
            FonctionsUtiles.TrouverMinimumListeTriee(listeTrieeRapide);

            /*Réponse question 3:
                 * Pour trouver le minimum sans trier , on parcoure la boucle n fois, donc la complexité est de O(n)
                 * Pour la recherche du minimum avec le tri rapide,comme on a choisi le premier indice pour le choix du pivot,la complexité dans le cas le pire est O(n*n) 
                 * Pour la recherche en utilisant le tri à bulle, le pire des cas est qu'on parcoure toute la liste à chaque  fois donc ça sera O(n*n)
                 
            En comparant les résultats on trouve que la recherche du minimum dans une liste non triée est la plus rapide
            */
        }
    }
}

﻿using System;
using System.Collections.Generic;

namespace Complexite_Exercice3
{
    class Program
    {
        static void Main(string[] args)
        {
            List<double> valeurs = new List<double>() { 9, 2, 5, 6, 3, 65, 23, 55, 69 };

            Console.Out.WriteLine(RechercheMinimum.RechercheClassique(valeurs));
        }
    }
}

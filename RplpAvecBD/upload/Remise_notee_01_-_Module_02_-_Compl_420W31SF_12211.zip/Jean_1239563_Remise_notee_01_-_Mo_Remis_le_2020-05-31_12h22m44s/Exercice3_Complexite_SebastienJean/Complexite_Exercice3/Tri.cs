﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Complexite_Exercice3
{
    public class Tri
    {
        public static List<TypeElement> TriRapide<TypeElement>(List<TypeElement> p_ListeATrier)
            where TypeElement : IComparable<TypeElement>
        {
            if (p_ListeATrier == null)
            {
                throw new ArgumentNullException("p_ListeATrier", "Impossible de trier une liste nulle");
            }
            if(p_ListeATrier.Count == 0)
            {
                throw new ArgumentException("p_ListeATrier", "Impossible de trier une liste vide");
            }

            List<TypeElement> listeCopiee = CopierListe(p_ListeATrier);
            TriRapide_Rec(listeCopiee, 0, listeCopiee.Count - 1);

            return listeCopiee;
        }
        private static void TriRapide_Rec<TypeElement>(List<TypeElement> p_ListeATrier, int p_IndicePremier, int p_IndiceDernier)
            where TypeElement : IComparable<TypeElement>
        {
            int indicePivot = 0;

            if (p_IndicePremier < p_IndiceDernier)
            {
                indicePivot = ChoixPivot(p_ListeATrier, p_IndicePremier, p_IndiceDernier);
                indicePivot = Partitionner(p_ListeATrier, p_IndicePremier, p_IndiceDernier, indicePivot);
                TriRapide_Rec(p_ListeATrier, p_IndicePremier, indicePivot - 1);
                TriRapide_Rec(p_ListeATrier, indicePivot + 1, p_IndiceDernier);
            }
        }
        private static int ChoixPivot<TypeElement>(List<TypeElement> p_Liste, int p_IndicePremier, int p_IndiceDernier)
        {
            return p_IndicePremier;
        }
        private static int Partitionner<TypeElement>(List<TypeElement> p_ListeAPartitionner, int p_IndicePremier, int p_IndiceDernier, int p_IndicePivot)
            where TypeElement : IComparable<TypeElement>
        {
            TypeElement ancienneValeur;
            int futurIndicePivot = p_IndicePremier;

            ancienneValeur = p_ListeAPartitionner[p_IndicePivot];
            p_ListeAPartitionner[p_IndicePivot] = p_ListeAPartitionner[p_IndiceDernier];
            p_ListeAPartitionner[p_IndiceDernier] = ancienneValeur;

            for (int indiceValeurARanger = p_IndicePremier;
                indiceValeurARanger < p_IndiceDernier;
                indiceValeurARanger++)
            {
                if (p_ListeAPartitionner[indiceValeurARanger].CompareTo(p_ListeAPartitionner[p_IndiceDernier]) <= 0)
                {
                    ancienneValeur = p_ListeAPartitionner[futurIndicePivot];
                    p_ListeAPartitionner[futurIndicePivot] = p_ListeAPartitionner[indiceValeurARanger];
                    p_ListeAPartitionner[indiceValeurARanger] = ancienneValeur;
                    ++futurIndicePivot;
                }
            }

            ancienneValeur = p_ListeAPartitionner[futurIndicePivot];
            p_ListeAPartitionner[futurIndicePivot] = p_ListeAPartitionner[p_IndiceDernier];
            p_ListeAPartitionner[p_IndiceDernier] = ancienneValeur;

            return futurIndicePivot;
        }
        private static List<TypeElement> CopierListe<TypeElement>(List<TypeElement> p_ListeCopiee)
        {
            List<TypeElement> listeCopiee = new List<TypeElement>();

            foreach (TypeElement element in p_ListeCopiee)
            {
                listeCopiee.Add(element);
            }
            return listeCopiee;
        }
    }
}

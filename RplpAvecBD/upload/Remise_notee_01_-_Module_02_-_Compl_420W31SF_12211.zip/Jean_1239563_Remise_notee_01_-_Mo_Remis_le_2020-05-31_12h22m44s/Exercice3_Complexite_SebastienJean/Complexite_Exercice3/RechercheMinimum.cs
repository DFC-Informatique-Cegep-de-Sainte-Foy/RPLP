﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Complexite_Exercice3
{
    public class RechercheMinimum
    {
        // Question 1
        public static TypeElement RechercheClassique<TypeElement>(List<TypeElement> p_Valeurs)
            where TypeElement : IComparable<TypeElement>
        {
            if (p_Valeurs == null)
            {
                throw new ArgumentNullException("p_Valeurs", "Impossible de trouver le minimum dans une liste vide ou nulle");
            }
            if (p_Valeurs.Count == 0)
            {
                throw new ArgumentException("p_Valeurs", "Impossible de trouver le minimum d'une liste vide");
            }

            TypeElement minimum = p_Valeurs[0];

            p_Valeurs.ForEach(element =>
            {
                if (element.CompareTo(minimum) < 0)
                {
                    minimum = element;
                }
            });

            return minimum;
        }

        //Question 2
        public static TypeElement RechercheTrie<TypeElement>(List<TypeElement> p_Valeurs)
            where TypeElement : IComparable<TypeElement>
        {
            if (p_Valeurs == null)
            {
                throw new ArgumentNullException("p_Valeurs", "Impossible de trouver le minimum dans une liste nulle");
            }
            if(p_Valeurs.Count == 0)
            {
                throw new ArgumentException("p_Valeurs", "Impossible de trouver le minimum dans une liste vide");
            }

            List<TypeElement> valeursTriees = Tri.TriRapide(p_Valeurs);

            return valeursTriees[0];
        }


        /* Question 3

        Pour ce qui est de la recherche du minimum classique, nous passerons chaque valeur de la liste une seule fois
        peu importe la liste dans laquelle nous recherchons le minimum, ce qui nous donne une complexité de O(n).

        Pour la recherche du minimum avec tri rapide, dans le meilleur des cas nous aurons O(n log n) car on passe toutes les valeurs
        une fois puis dans le deuxième passage on divise chaque fois le nombre de données par deux. Dans le pire des cas nous aurons 
        une complexité de O(n^2), car si la liste traitée est dans un ordre qui n'est pas optimal nous passerons chaque valeur deux fois.

         Donc, dans tous les cas, la méthode la moins complexe pour trouver le minimum dans une liste est celle sans tri.
        */
    }
}

using Complexite_Exercice3;
using System;
using System.Collections.Generic;
using Xunit;

namespace Tests_Complexite_Exercice3
{
    public class Tests_RechercheMinimum
    {
        //Recherche classique tests pr�conditions
        [Fact]
        public void TestRechercheClassique_ListeNulle_NullException()
        {
            //Arranger
            List<int> listeDepart = null;
            int minimumObtenu;

            //Agir & Auditer
            Assert.Throws<ArgumentNullException>(() => { minimumObtenu = RechercheMinimum.RechercheClassique(listeDepart); });
        }
        [Fact]
        public void TestRechercheClassique_ListeVide_Exception()
        {
            //Arranger
            List<int> listeDepart = new List<int>();
            int minimumObtenu;

            //Agir & Auditer
            Assert.Throws<ArgumentException>(() => { minimumObtenu = RechercheMinimum.RechercheClassique(listeDepart); });
        }

        //Recherche classique tests avec entiers(type valeur)
        [Fact]
        public void TestRechercheClassique_ListeEntiers_ValeurCentrale()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { 45, 33, 0, -1111, -12, -66, 99 };
            int resultatAttendu = -1111;
            int resultatObtenu = 0;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheClassique(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheClassique_ListeEntiers_DerniereValeur()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { 45, 33, 0, -12, -66, 99, -1111 };
            int resultatAttendu = -1111;
            int resultatObtenu = 0;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheClassique(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheClassique_ListeEntiers_PremiereValeur()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { -1111, 45, 33, 0, -12, -66, 99 };
            int resultatAttendu = -1111;
            int resultatObtenu = 0;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheClassique(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheClassique_ListeEntiersDoublons_Succes()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { -1111, 45, 33, 0, -1111, -12, -66, 99 };
            int resultatAttendu = -1111;
            int resultatObtenu = 0;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheClassique(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }

        //Recherche classique tests avec string(type r�f�rence)
        [Fact]
        public void TestRechercheClassique_ListeString_ValeurCentrale()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "guacamole", "velo", "crayon", "albatros", "clavier", "flatulence" };
            string resultatAttendu = "albatros";
            string resultatObtenu = string.Empty;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheClassique(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheClassique_ListeString_DerniereValeur()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "guacamole", "velo", "crayon", "clavier", "flatulence", "albatros" };
            string resultatAttendu = "albatros";
            string resultatObtenu = string.Empty;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheClassique(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheClassique_ListeString_PremiereValeur()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "albatros", "guacamole", "velo", "crayon", "clavier", "flatulence" };
            string resultatAttendu = "albatros";
            string resultatObtenu = string.Empty;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheClassique(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheClassique_ListeStringDoublons_Succes()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "albatros", "guacamole", "velo", "crayon", "clavier", "albatros", "flatulence" };
            string resultatAttendu = "albatros";
            string resultatObtenu = string.Empty;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheClassique(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheClassique_ListeStringSimilaires_Succes()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "Libert�", "Librairie", "velo", "wagon", "prison", "Z�bre", "Libido" };
            string resultatAttendu = "Libert�";
            string resultatObtenu = string.Empty;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheClassique(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }

        //Recherche trie test pr�conditions
        [Fact]
        public void TestRechercheTrie_ListeNulle_NullException()
        {
            //Arranger
            List<int> listeDepart = null;
            int minimumObtenu;

            //Agir & Auditer
            Assert.Throws<ArgumentNullException>(() => { minimumObtenu = RechercheMinimum.RechercheTrie(listeDepart); });
        }
        [Fact]
        public void TestRechercheTrie_ListeVide_Exception()
        {
            //Arranger
            List<int> listeDepart = new List<int>();
            int minimumObtenu;

            //Agir & Auditer
            Assert.Throws<ArgumentException>(() => { minimumObtenu = RechercheMinimum.RechercheTrie(listeDepart); });
        }

        //Recherche trie avec entiers(type valeur)
        [Fact]
        public void TestRecherchetrie_ListeEntiers_ValeurCentrale()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { 45, 33, 0, -1111, -12, -66, 99 };
            int resultatAttendu = -1111;
            int resultatObtenu = 0;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheTrie(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRecherchetrie_ListeEntiers_DerniereValeur()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { 45, 33, 0, -12, -66, 99, -1111 };
            int resultatAttendu = -1111;
            int resultatObtenu = 0;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheTrie(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheTrie_ListeEntiers_PremiereValeur()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { -1111, 45, 33, 0, -12, -66, 99 };
            int resultatAttendu = -1111;
            int resultatObtenu = 0;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheTrie(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheTrie_ListeEntiersDoublons_Succes()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { -1111, 45, 33, 0, -1111, -12, -66, 99 };
            int resultatAttendu = -1111;
            int resultatObtenu = 0;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheTrie(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }

        //Recherche trie tests avec string(type r�f�rence)
        [Fact]
        public void TestRechercheTrie_ListeString_ValeurCentrale()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "guacamole", "velo", "crayon", "albatros", "clavier", "flatulence" };
            string resultatAttendu = "albatros";
            string resultatObtenu = string.Empty;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheTrie(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheTrie_ListeString_DerniereValeur()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "guacamole", "velo", "crayon", "clavier", "flatulence", "albatros" };
            string resultatAttendu = "albatros";
            string resultatObtenu = string.Empty;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheTrie(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheTrie_ListeString_PremiereValeur()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "albatros", "guacamole", "velo", "crayon", "clavier", "flatulence" };
            string resultatAttendu = "albatros";
            string resultatObtenu = string.Empty;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheTrie(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheTrie_ListeStringDoublons_Succes()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "albatros", "guacamole", "velo", "crayon", "clavier", "albatros", "flatulence" };
            string resultatAttendu = "albatros";
            string resultatObtenu = string.Empty;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheTrie(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }
        [Fact]
        public void TestRechercheTrie_ListeStringSimilaires_Succes()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "Libert�", "Librairie", "velo", "wagon", "prison", "Z�bre", "Libido" };
            string resultatAttendu = "Libert�";
            string resultatObtenu = string.Empty;

            //Agir
            resultatObtenu = RechercheMinimum.RechercheTrie(listeDepart);

            //Auditer
            Assert.Equal(resultatAttendu, resultatObtenu);
        }


    }
}


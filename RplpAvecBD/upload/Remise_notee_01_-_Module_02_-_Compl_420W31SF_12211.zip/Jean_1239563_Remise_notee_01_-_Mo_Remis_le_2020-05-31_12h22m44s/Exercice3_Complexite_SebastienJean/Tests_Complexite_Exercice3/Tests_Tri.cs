﻿using Complexite_Exercice3;
using System;
using System.Collections.Generic;
using Xunit;

namespace Tests_Complexite_Exercice3
{
    public class Tests_Tri
    {
        //Tests préconditions Tri Rapide
        [Fact]
        public void TestTriRapide_ListeVide_Exception()
        {
            //Arranger
            List<int> listeDepart = new List<int>();
            List<int> listeAttendue = new List<int>();

            //Agir & Auditer
            Assert.Throws<ArgumentException>(() => { listeAttendue = Tri.TriRapide(listeDepart); });
        }
        [Fact]
        public void TestTriRapide_ListeNulle_NullException()
        {
            //Arranger
            List<int> listeDepart = null;
            List<int> listeAttendue = new List<int>();

            //Agir & Auditer
            Assert.Throws<ArgumentNullException>(() => { listeAttendue = Tri.TriRapide(listeDepart); });
        }

        //Tests type valeur
        [Fact]
        public void TestTriRapide_ListeEntiers_Succes()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { 45, 33, 0, -1111, -12, -66, 99 };
            List<int> listeAttendue = new List<int>() { -1111, -66, -12, 0, 33, 45, 99 };
            List<int> listeObtenue = new List<int>();

            //Agir
            listeObtenue = Tri.TriRapide(listeDepart);

            //Auditer
            Assert.Equal(listeAttendue, listeObtenue);
            Assert.Equal(listeAttendue.Count, listeObtenue.Count);
            Assert.NotSame(listeAttendue, listeObtenue);
        }
        [Fact]
        public void TestTriRapide_ListeEntiersDejaTries_Succes()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { -1111, -66, -12, 0, 33, 45, 99 };
            List<int> listeAttendue = new List<int>() { -1111, -66, -12, 0, 33, 45, 99 };
            List<int> listeObtenue = new List<int>();

            //Agir
            listeObtenue = Tri.TriRapide(listeDepart);

            //Auditer
            Assert.Equal(listeAttendue, listeObtenue);
            Assert.Equal(listeAttendue.Count, listeObtenue.Count);
            Assert.NotSame(listeAttendue, listeObtenue);
        }
        [Fact]
        public void TestTriRapide_ListeEntiersDecroissante_Succes()
        {
            //Arranger
            List<int> listeDepart = new List<int>() { 99, 45, 33, 0, -12, -66, -1111 };
            List<int> listeAttendue = new List<int>() { -1111, -66, -12, 0, 33, 45, 99 };
            List<int> listeObtenue = new List<int>();

            //Agir
            listeObtenue = Tri.TriRapide(listeDepart);

            //Auditer
            Assert.Equal(listeAttendue, listeObtenue);
            Assert.Equal(listeAttendue.Count, listeObtenue.Count);
            Assert.NotSame(listeAttendue, listeObtenue);
        }
        [Fact]
        public void TestTriRapide_ListeDoubles_Succes()
        {
            //Arranger
            List<double> listeDepart = new List<double>() { 45.66, 33.33, 0, -12.36, -66.964, 99.33, -1111.33 };
            List<double> listeAttendue = new List<double>() { -1111.33, -66.964, -12.36, 0, 33.33, 45.66, 99.33 };
            List<double> listeObtenue = new List<double>();

            //Agir
            listeObtenue = Tri.TriRapide(listeDepart);

            //Auditer
            Assert.Equal(listeAttendue, listeObtenue);
            Assert.Equal(listeAttendue.Count, listeObtenue.Count);
            Assert.NotSame(listeAttendue, listeObtenue);
        }
        [Fact]
        public void TestTriRapide_ListeDecimal_Succes()
        {
            //Arranger
            List<decimal> listeDepart = new List<decimal>() { 45.66m, 33.33m, 0m, -12.36m, -66.964m, 99.33m, -1111.33m };
            List<decimal> listeAttendue = new List<decimal>() { -1111.33m, -66.964m, -12.36m, 0, 33.33m, 45.66m, 99.33m };
            List<decimal> listeObtenue = new List<decimal>();

            //Agir
            listeObtenue = Tri.TriRapide(listeDepart);

            //Auditer
            Assert.Equal(listeAttendue, listeObtenue);
            Assert.Equal(listeAttendue.Count, listeObtenue.Count);
            Assert.NotSame(listeAttendue, listeObtenue);
        }
        [Fact]
        public void TestTriRapide_ListeFlotantes_Succes()
        {
            //Arranger
            List<float> listeDepart = new List<float>() { 45.66f, 33.33f, 0f, -12.36f, -66.964f, 99.33f, -1111.33f };
            List<float> listeAttendue = new List<float>() { -1111.33f, -66.964f, -12.36f, 0, 33.33f, 45.66f, 99.33f };
            List<float> listeObtenue = new List<float>();

            //Agir
            listeObtenue = Tri.TriRapide(listeDepart);

            //Auditer
            Assert.Equal(listeAttendue, listeObtenue);
            Assert.Equal(listeAttendue.Count, listeObtenue.Count);
            Assert.NotSame(listeAttendue, listeObtenue);
        }

        //Test type référence
        [Fact]
        public void TestTriRapide_ListeChaines_Succes()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "Toupie", "Jambon", "Bleu", "Crabe", "Anticonstitutionnellement", "Cravate" };
            List<string> listeAttendue = new List<string>() { "Anticonstitutionnellement", "Bleu", "Crabe", "Cravate", "Jambon", "Toupie" };
            List<string> listeObtenue = new List<string>();

            //Agir
            listeObtenue = Tri.TriRapide(listeDepart);

            //Auditer
            Assert.Equal(listeAttendue, listeObtenue);
            Assert.Equal(listeAttendue.Count, listeObtenue.Count);
            Assert.NotSame(listeAttendue, listeObtenue);
        }
        [Fact]
        public void TestTriRapide_ListeChainesDejaTries_Succes()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "Anticonstitutionnellement", "Bleu", "Crabe", "Cravate", "Jambon", "Toupie" };
            List<string> listeAttendue = new List<string>() { "Anticonstitutionnellement", "Bleu", "Crabe", "Cravate", "Jambon", "Toupie" };
            List<string> listeObtenue = new List<string>();

            //Agir
            listeObtenue = Tri.TriRapide(listeDepart);

            //Auditer
            Assert.Equal(listeAttendue, listeObtenue);
            Assert.Equal(listeAttendue.Count, listeObtenue.Count);
            Assert.NotSame(listeAttendue, listeObtenue);
        }
        [Fact]
        public void TestTriRapide_ListeChainesDecroissante_Succes()
        {
            //Arranger
            List<string> listeDepart = new List<string>() { "Toupie", "Jambon", "Cravate", "Crabe", "Bleu", "Anticonstitutionnellement" };
            List<string> listeAttendue = new List<string>() { "Anticonstitutionnellement", "Bleu", "Crabe", "Cravate", "Jambon", "Toupie" };
            List<string> listeObtenue = new List<string>();

            //Agir
            listeObtenue = Tri.TriRapide(listeDepart);

            //Auditer
            Assert.Equal(listeAttendue, listeObtenue);
            Assert.Equal(listeAttendue.Count, listeObtenue.Count);
            Assert.NotSame(listeAttendue, listeObtenue);
        }
    }
}

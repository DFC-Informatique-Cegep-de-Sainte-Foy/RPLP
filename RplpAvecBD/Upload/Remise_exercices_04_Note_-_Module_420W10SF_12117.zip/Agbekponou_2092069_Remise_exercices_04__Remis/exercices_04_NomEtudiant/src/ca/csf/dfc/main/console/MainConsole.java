package ca.csf.dfc.main.console;

import ca.csf.dfc.classes.Duree;
import ca.csf.dfc.classes.Personne;

public class MainConsole {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		// Création et affichage d'une personne
		Personne p = new Personne("Pereira", "Thiago", 34);
		System.out.println(p);
		
		// Création de durées
		Duree d1 = new Duree(0,43,18);
		Duree d2 = new Duree(0,33,17);
		
		// Addition de deux durées et affichage du résultat
		Duree d3 = Duree.AdditionnerDurees(d1, d2);
		System.out.println(d3);
		
		
		
	}

}

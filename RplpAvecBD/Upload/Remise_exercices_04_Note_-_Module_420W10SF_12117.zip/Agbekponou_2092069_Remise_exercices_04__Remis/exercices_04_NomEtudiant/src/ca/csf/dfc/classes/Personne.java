package ca.csf.dfc.classes;

/**
 * Classe représentant une personne, avec son nom, prénom et âge.
 * Nous n'acceptons pas de nom à nul. Mettez une chaîne vide à la place.
 * <br>
 * <quote><code>
 * Personne p = new Personne("Martin", "Jean", 34);
 * </code></quote>
 *
 */

public class Personne {
	
	// Constante
	
	public static final int AGE_MIN = 0;
	
	// Données membres
	
	/**
	 * Le nom de la personne
	 */
	private String m_Nom;
	
	
	/**
	 * Le prénom de la personne
	 */
	private String m_Prenom;
	
	
	/**
	 * L'âge de la personne
	 */
	private int m_Age;
	
	
	// Constructeur par initialisation
	
	/**
	 * Constructeur par initialisation
	 * @param p_nom		le nom de la personne.
	 * @param p_prenom	Le prénom de la personne.
	 * @param p_age		l'âge de la personne.
	 */
	public Personne(String p_nom, String p_prenom, int p_age) 
	{
		this.setNom(p_nom);
		this.setPrenom(p_prenom);
		this.setAge(p_age);
	}

	
	// Méthodes get

	/**
	 * Retourne le nom.
	 * @return le nom
	 */
	public String getNom() {
		return this.m_Nom;
	}


	/**
	 * Retourne le prénom.
	 * @return le prénom
	 */
	public String getPrenom() {
		return this.m_Prenom;
	}


	/**
	 * Retourne l'âge.
	 * @return l'âge
	 */
	public int getAge() {
		return this.m_Age;
	}

	
	// Méthodes set
	
	/**
	 * Pour modifier le nom.
	 * @param p_nom Nouvelle valeur
	 */
	public void setNom(String p_nom) {
		
		if (p_nom == null)
		{
			throw new IllegalArgumentException("Le nom est null !");
		}
		
		this.m_Nom = p_nom;
	}

	
	/**
	 * Pour modifier le prénom.
	 * @param p_prenom Nouvelle valeur
	 */
	public void setPrenom(String p_prenom) {
		
		if (p_prenom == null)
		{
			throw new IllegalArgumentException("Le prénom est null !");
		}
		
		this.m_Prenom = p_prenom;
	}


	/**
	 * Pour modifier l'âge.
	 * @param p_age Nouvelle valeur
	 */
	public void setAge(int p_age) {
		
		if (p_age < AGE_MIN)
		{
			throw new IllegalArgumentException("L'âge fourni " + p_age + " est < " + AGE_MIN);
		}
		
		this.m_Age = p_age;
	}
	
	
	// Redéfinitions
	
	/**
	 * Redéfinition du return de la méthode toString()
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
		return "Personne [Nom: " + this.getNom() + ", Prénom: " + this.getPrenom() + ", Âge: " + this.getAge() + "]";
	}
	
}

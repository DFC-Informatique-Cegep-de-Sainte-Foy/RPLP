package ca.csf.dfc.classes;

/**
 * Classe représentant une durée de temps, avec heures, minutes et secondes.
 * <br>
 * <quote><code>
 * Duree d = new Duree(12,32,4);
 * </code></quote>
 * 
 */
public class Duree {
	
	// Constantes
	
	/**
	 * L'heures minimales d'une durée
	 */
	public final static int HEURES_MIN = 0;
	
	
	/**
	 * Minutes minimales d'une durée
	 */
	public final static int MINUTES_MIN = 0;
	
	
	/**
	 * Minutes maximales d'une durée
	 */
	public final static int MINUTES_MAX = 59;
	
	
	/**
	 * Secondes minimales d'une durée
	 */
	public final static int SECONDES_MIN = 0;

	
	/**
	 * Secondes maximales d'une durée
	 */
	public final static int SECONDES_MAX = 59;
	
	
	// Données membres
	
	/**
	 *  La quantité de heures de la durée
	 */
	private int m_Heures;
	
	
	/**
	 *  La quantité de minutes de la durée
	 */
	private int m_Minutes;
	
	
	/**
	 *  La quantité de secondes de la durée
	 */
	private int m_Secondes;

	
	// Constructeurs
	
	/**
	 * Constructeur par défaut
	 * 
	 */
	public Duree() {
		
		this(HEURES_MIN, MINUTES_MIN, SECONDES_MIN);
	}
	
	
	/**
	 * Constructeur par initialisation avec 1 paramètre
	 * 
	 * @param p_secondes La quantité de secondes.
	 */
	public Duree(int p_secondes) {
		
		this.setHeures(HEURES_MIN);
		this.setMinutes(MINUTES_MIN);
		this.setSecondes(p_secondes);
	}
	
	
	/**
	 * Constructeur par initialisation avec 2 paramètres
	 * 
	 * @param p_minutes	 La quantité de minutes.
	 * @param p_secondes La quantité de secondes.
	 */
	public Duree(int p_minutes, int p_secondes) {
		
		this.setHeures(HEURES_MIN);
		this.setMinutes(p_minutes);
		this.setSecondes(p_secondes);
	}
	
	
	/**
	 * Constructeur par initialisation avec 3 paramètres
	 * 
	 * @param p_heures   La quantité de heures.
	 * @param p_minutes	 La quantité de minutes.
	 * @param p_secondes La quantité de secondes.
	 */
	public Duree(int p_heures, int p_minutes, int p_secondes) {
		
		this.setHeures(p_heures);
		this.setMinutes(p_minutes);
		this.setSecondes(p_secondes);
	}


	// Méthodes get
	
	/**
	 * Retourne les heures.
	 * @return les heures
	 */
	public int getHeures() {
		return this.m_Heures;
	}


	/**
	 * Retourne les minutes.
	 * @return les minutes
	 */
	public int getMinutes() {
		return this.m_Minutes;
	}


	/**
	 * Retourne les secondes.
	 * @return les secondes
	 */
	public int getSecondes() {
		return this.m_Secondes;
	}


	
	// Méthodes set
	
	/**
	 * Pour modifier les heures.
	 * @param p_heures Nouvelle valeur
	 */
	public void setHeures(int p_heures) {
		
		if (p_heures < HEURES_MIN)
		{
			throw new IllegalArgumentException("L'heure fourni " + p_heures + " est < " + HEURES_MIN);
		}
		
		this.m_Heures = p_heures;
	}


	/**
	 * Pour modifier les minutes.
	 * @param p_minutes Nouvelle valeur
	 */
	public void setMinutes(int p_minutes) {
		
		if (p_minutes < MINUTES_MIN || p_minutes > MINUTES_MAX)
		{
			throw new IllegalArgumentException("Les minutes ne respectent pas la valeur minimale " + MINUTES_MIN + 
					                           " ou la valeur maximale " + MINUTES_MAX);
		}
		
		this.m_Minutes = p_minutes;
	}


	/**
	 * Pour modifier les secondes.
	 * @param p_secondes Nouvelle valeur
	 */
	public void setSecondes(int p_secondes) {
		
		if (p_secondes < SECONDES_MIN || p_secondes > SECONDES_MAX)
		{
			throw new IllegalArgumentException("Les secondes ne respectent pas la valeur minimale " + SECONDES_MIN + 
                    						   " ou la valeur maximale " + SECONDES_MAX);
		}
		
		this.m_Secondes = p_secondes;
	}
		
	
	// Redéfinitions
	
	/**
	 * Redéfinition
	 * 
	 * @see java.lang.Object#toString()
	 */
	public String toString()
	{
		String duree = String.format("%d:%02d:%02d", this.getHeures(), this.getMinutes(), this.getSecondes());
				
		return duree;
	}
	
	// Méthodes 
	
	/**
	 * Additionner deux durées
	 * 
	 * @param p_duree1 La première durée
	 * @param p_duree2 La deuxième durée
	 * 
	 * @return La somme des deux durées données en paramètre
	 */
	public static Duree AdditionnerDurees(Duree p_duree1, Duree p_duree2)
	{
		
		int secondesCalculees = p_duree1.getSecondes() + p_duree2.getSecondes();
		int minutesCalculees = p_duree1.getMinutes() + p_duree2.getMinutes();
		int heuresCalculees = p_duree1.getHeures() + p_duree2.getHeures();
		
		while (secondesCalculees / 60 > 1)
		{
			secondesCalculees -= 60;
			minutesCalculees += 1;
		}
		
		while (minutesCalculees > 60)
		{
			minutesCalculees -= 60;
			heuresCalculees += 1;
		}
		
		Duree resultat = new Duree();
		
		resultat.setHeures(heuresCalculees);
		resultat.setMinutes(minutesCalculees);
		resultat.setSecondes(secondesCalculees);
		
		return resultat;
	}
}
